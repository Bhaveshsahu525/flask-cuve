from flask import Flask, render_template, request, session
import pandas as pd

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

# Define the path to the local file
LOCAL_FILE_PATH = 'C:/Users/Bhavesh/PycharmProjects/pythonProject1/imp3.xlsx'

@app.route('/', methods=['GET', 'POST'])
def test():
    if request.method == 'POST':
        if 'value_column' in request.form:
            df = pd.read_excel(LOCAL_FILE_PATH, engine='openpyxl')

            # Normalize column names
            df.columns = [str(col).strip() for col in df.columns]

            # Store the DataFrame and columns in the session
            session['dataframe'] = df.to_dict()
            session['columns'] = df.columns.tolist()

            emp_id_column = request.form['emp_id_column']
            relation_column = request.form['relation_column']
            value_column = request.form['value_column']

            try:
                # Create pivot table
                df = pd.DataFrame(session.get('dataframe'))
                df.columns = [str(col).strip() for col in df.columns]

                pivot_table = pd.pivot_table(
                    df,
                    values=value_column,
                    index=emp_id_column,
                    columns=relation_column,
                    aggfunc='first',
                    fill_value=''
                )
                html_table = pivot_table.to_html(classes='table table-striped')
                return render_template('test.html', table=html_table, columns=session['columns'])
            except KeyError as e:
                return f"KeyError: {e}. Please ensure the column names are correct."

    # Load the DataFrame when rendering the page
    df = pd.read_excel(LOCAL_FILE_PATH, engine='openpyxl')
    df.columns = [str(col).strip() for col in df.columns]

    session['dataframe'] = df.to_dict()
    session['columns'] = df.columns.tolist()

    html_table = df.to_html(classes='table table-striped', index=False)
    return render_template('test.html', table=html_table, columns=session['columns'])


if __name__ == '__main__':
    app.run(debug=True)
