from waitress import serve
from login import app  # Replace 'myapp' with your application module

if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=5002)
