# Import required libraries and modules
import re
import random
import string
import pandas as pd
import io
import requests
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, make_response, abort, jsonify, render_template_string
from validation_data import validation_patterns, validation_patterns_for_e, validation_patterns_vendor, validation_patterns_for_i, validation_rules, validation_rules_for_e, validation_rules_vendor, validation_rules_vendor_i, fixed_values, fixed_values_e, fixed_values_vendor, fixed_values_vendor_i
import mysql.connector
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import ssl
import traceback
import os
import uuid
from datetime import datetime
import base64
import logging

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Configure logging to capture debug and higher levels of messages
logging.basicConfig(filename='app.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')
# Connect to the "sangamcustomer" database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sangamcustomer"
)
def generate_unique_code():
    """Generate a unique 6-character alphanumeric code."""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

def send_email(sender_email, sender_password, recipient_email, subject, body):
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = recipient_email
    message['Subject'] = subject

    message.attach(MIMEText(body, 'plain'))

    smtp_server = 'mail.sangamgroup.com'
    port = 465
    context = ssl.create_default_context()

    try:
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient_email, message.as_string())
        return True, None  # Email sent successfully
    except Exception as e:
        error_message = f"Failed to send email: {e}"
        traceback.print_exc()
        return False, error_message  # Failed to send email

# Function to generate a unique request number
def generate_request_number():
    return str(uuid.uuid4())

# Function to handle email task and database insertion
def send_email_task(sender_email, sender_password, recipient_email, subject, body, conn_requests,
                    company_name, email, category, logged_in_user_email, request_number):
    try:
        # Check if the email exists in the formsbyc table
        existing_emails = check_email(recipient_email)

        if existing_emails:
            flash(f"Email {recipient_email} is already present in the database.", "danger")
            return False, "Email already exists in database"

        # Select form link based on category
        if category == "Domestic (ZDOM)" or category == "Ship to Party (ZDSH)":
            form_link = url_for('formds', request_number=request_number, _external=True)
        elif category == "Export (ZEXP)":
            form_link = url_for('forme', request_number=request_number, _external=True)
        else:
            form_link = "No form link available for this category"

        # Include form link in the email body
        body += f"\n\nForm Link: {form_link}"

        # Send the email
        success, error_message = send_email(sender_email, sender_password, recipient_email, subject, body)

        if success:
            cursor = conn_requests.cursor()
            cursor.execute(
                "INSERT INTO customerrequested (request_number, company_name, email, category, logged_in_user_email) VALUES (%s, %s, %s, %s, %s)",
                (request_number, company_name, email, category, logged_in_user_email))
            conn_requests.commit()
            cursor.close()
            return True, None  # Success
        else:
            flash(f"Failed to send email: {error_message}", "danger")
            return False, error_message  # Failure

    except Exception as e:
        traceback.print_exc()
        return False, str(e)  # Failure with exception message

# Function to handle email task and database insertion
def send_email_task_vendor(sender_email, sender_password, recipient_email, subject, body, conn_requests,
                    company_name, email, category, logged_in_user_email, request_number):
    try:
        # Check if the email exists in the formsbyc table
        existing_emails = check_email_vendor(recipient_email)

        if existing_emails:
            flash(f"Email {recipient_email} is already present in the database.", "danger")
            return False, "Email already exists in database"

        # Select form link based on category
        if category == "Domestic (ZDOM)":
            form_link = url_for('formvds', request_number=request_number, _external=True)
        elif category == "Import (VIMP)":
            form_link = url_for('formve', request_number=request_number, _external=True)
        else:
            form_link = "No form link available for this category"

        # Include form link in the email body
        body += f"\n\nForm Link: {form_link}"

        # Send the email
        success, error_message = send_email(sender_email, sender_password, recipient_email, subject, body)

        if success:
            cursor = conn_requests.cursor()
            cursor.execute(
                "INSERT INTO vendorrequested (request_number, company_name, email, category, logged_in_user_email) VALUES (%s, %s, %s, %s, %s)",
                (request_number, company_name, email, category, logged_in_user_email))
            conn_requests.commit()
            cursor.close()
            return True, None  # Success
        else:
            flash(f"Failed to send email: {error_message}", "danger")
            return False, error_message  # Failure

    except Exception as e:
        traceback.print_exc()
        return False, str(e)  # Failure with exception message

# Function to fetch joined data from the database
def joined_data():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT 
                cr.request_number,
                cr.company_name,
                cr.email,
                cr.category AS customer_category,
                cr.logged_in_user_email AS customer_logged_in_user_email,
                f.titles,
                f.name,
                f.email,
                f.company_name AS form_company_name,
                f.country,
                f.state,
                f.city,
                f.street_address,
                f.street_address_2,
                f.street_address_3,
                f.postal_code,
                f.phone_number,
                f.mobile_number,
                f.gst_number,
                f.pan_number,
                f.region,
                f.submission_date AS form_submission_date,
                f.form_number
            FROM 
                customerrequested cr
            JOIN 
                formsbyc f ON cr.request_number = f.request_number
            """

        cursor.execute(query)
        joined_data = cursor.fetchall()
        cursor.close()

        return joined_data

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return None

    except Exception as e:
        print("Error:", e)
        return None

# Function to fetch joined data from the database
def joined_data_vendor():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT 
                vr.request_number,
                vr.company_name,
                vr.email,
                vr.category AS customer_category,
                vr.logged_in_user_email AS customer_logged_in_user_email,
                fv.titles,
                fv.name,
                fv.email,
                fv.company_name AS form_company_name,
                fv.country,
                fv.state,
                fv.city,
                fv.street_address,
                fv.street_address_2,
                fv.street_address_3,
                fv.postal_code,
                fv.phone_number,
                fv.mobile_number,
                fv.gst_number,
                fv.pan_number,
                fv.region,
                fv.submission_date AS form_submission_date,
                fv.form_number
            FROM 
                vendorrequested vr
            JOIN 
                formsbyv fv ON vr.request_number = fv.request_number
            """

        cursor.execute(query)
        joined_data_vendor = cursor.fetchall()
        cursor.close()

        return joined_data_vendor

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return None

    except Exception as e:
        print("Error:", e)
        return None

@app.route('/', methods=['GET', 'POST'])
def index():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Checking in users table
        try:
            cursor = db.cursor()
            cursor.execute("SELECT * FROM users_mr WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()
            cursor.close()

            if user:
                session['username'] = username
                return redirect(url_for('autoemailsending'))

            # Checking in users_ar table
            cursor = db.cursor()
            cursor.execute("SELECT * FROM users_ar WHERE username = %s AND password = %s", (username, password))
            user_ar = cursor.fetchone()
            cursor.close()

            if user_ar:
                session['username'] = username
                return redirect(url_for('marketcheckbyar'))

            # Checking in users_it table
            cursor = db.cursor()
            cursor.execute("SELECT * FROM users_it WHERE username = %s AND password = %s", (username, password))
            user_it = cursor.fetchone()
            cursor.close()

            if user_it:
                session['username'] = username
                return redirect(url_for('choose'))

            cursor = db.cursor()
            cursor.execute("SELECT * FROM users_pr WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()
            cursor.close()

            if user:
                session['username'] = username
                return redirect(url_for('autoemailsendingvendor'))

            cursor = db.cursor()
            cursor.execute("SELECT * FROM users_ap WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()
            cursor.close()

            if user:
                session['username'] = username
                return redirect(url_for('vendorcheckbyap'))

            error = "Invalid username or password"

        except mysql.connector.Error as e:
            print("MySQL Error:", e)
            error = "An error occurred while trying to log in."

        except Exception as e:
            print("Error:", e)
            error = "An unexpected error occurred."

    # If the request method is GET or if there's an error, render the login form
    return render_template('index.html', error=error)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

# Function to check if email exists in the database
def check_email(email):
    try:
        cursor = db.cursor()
        query = "SELECT * FROM formsbyc WHERE email = %s"
        cursor.execute(query, (email,))
        result = cursor.fetchall()  # Fetch all records related to the email
        cursor.close()
        return result

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return []

    except Exception as e:
        print("Error:", e)
        return []

def check_email_vendor(email):
    try:
        cursor = db.cursor()
        query = "SELECT * FROM formsbyv WHERE email = %s"
        cursor.execute(query, (email,))
        result = cursor.fetchall()  # Fetch all records related to the email
        cursor.close()
        return result

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return []

    except Exception as e:
        print("Error:", e)
        return []

@app.route('/autoemailsending', methods=['GET', 'POST'])
def autoemailsending():
    if 'username' not in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        company_name = request.form['company_name']
        email_address = request.form['email']
        category = request.form['category']

        # Validate email
        if not re.match(validation_patterns['email'], email_address):
            flash("Invalid email address format.", "info")
            return redirect(url_for('autoemailsending'))

        # Validate company name
        if not re.match(validation_patterns['company_name'], company_name):
            flash("Invalid company name format. Only letters, numbers, and spaces, are allowed.",
                  "info")
            return redirect(url_for('autoemailsending'))

        # Check if the email address already exists in the formsbyc table
        existing_emails = check_email(email_address)

        if existing_emails:
            flash(f"Email {email_address} is already present in the database.", "warning")
            return redirect(url_for('autoemailsending'))

        # Generate unique request number
        request_number = generate_request_number()

        # Email details
        sender_email = 'testit@sangamgroup.com'
        sender_password = 'Krishna@123'
        subject = 'Welcome to {}'.format(company_name)
        body = 'Thank you for joining {}. We welcome you to Sangam group' .format(company_name)

        # Perform the email task and database insertion
        success, error_message = send_email_task(sender_email, sender_password, email_address, subject, body, db,
                                                 company_name, email_address, category, session.get('username'),
                                                 request_number)

        if success:
            flash("Email sent successfully!", "success")
        else:
            flash(f"Failed to send email: {error_message}", "danger")

        # Redirect to prevent form resubmission
        return redirect(url_for('autoemailsending'))

    # Get total rows from customerrequested table
    try:
        cursor = db.cursor()
        cursor.execute("SELECT COUNT(*) FROM customerrequested")
        total_rows = cursor.fetchone()[0]

        # Get total rows for logged-in user
        total_rows_logged_in_user = 0
        if 'username' in session:
            cursor.execute("SELECT COUNT(*) FROM customerrequested WHERE logged_in_user_email = %s",
                           (session['username'],))
            total_rows_logged_in_user = cursor.fetchone()[0]

        # Fetch data for the particular email address
        email_address = request.args.get('email')  # Get email address from the request parameters

        forms_data = []
        if email_address:
            forms_data = check_email(email_address)

        cursor.close()

        return render_template('autoemailsending.html', total_rows=total_rows,
                               total_rows_logged_in_user=total_rows_logged_in_user, forms_data=forms_data)

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while processing the request."

    except Exception as e:
        print("Error:", e)
        return "An unexpected error occurred."

@app.route('/autoemailsendingvendor', methods=['GET', 'POST'])
def autoemailsendingvendor():
    if 'username' not in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        company_name = request.form['company_name']
        email_address = request.form['email']
        category = request.form['category']

        # Validate email
        if not re.match(validation_patterns_vendor['email'], email_address):
            flash("Invalid email address format.", "info")
            return redirect(url_for('autoemailsendingvendor'))

        # Validate company name
        if not re.match(validation_patterns_vendor['company_name'], company_name):
            flash("Invalid company name format. Only letters, numbers, and spaces, are allowed.",
                  "info")
            return redirect(url_for('autoemailsendingvendor'))

        # Check if the email address already exists in the formsbyc table
        existing_emails = check_email_vendor(email_address)

        if existing_emails:
            flash(f"Email {email_address} is already present in the database.", "warning")
            return redirect(url_for('autoemailsendingvendor'))

        # Generate unique request number
        request_number = generate_request_number()

        # Email details
        sender_email = 'testit@sangamgroup.com'
        sender_password = 'Krishna@123'
        subject = 'Welcome to {}'.format(company_name)
        body = '{} Thank you for joining. We welcome you to Sangam group' .format(company_name)

        # Perform the email task and database insertion
        success, error_message = send_email_task_vendor(sender_email, sender_password, email_address, subject, body, db,
                                                 company_name, email_address, category, session.get('username'),
                                                 request_number)

        if success:
            flash("Email sent successfully!", "success")
        else:
            flash(f"Failed to send email: {error_message}", "danger")

        # Redirect to prevent form resubmission
        return redirect(url_for('autoemailsendingvendor'))

    # Get total rows from customerrequested table
    try:
        cursor = db.cursor()
        cursor.execute("SELECT COUNT(*) FROM vendorrequested")
        total_rows = cursor.fetchone()[0]

        # Get total rows for logged-in user
        total_rows_logged_in_user = 0
        if 'username' in session:
            cursor.execute("SELECT COUNT(*) FROM vendorrequested WHERE logged_in_user_email = %s",
                           (session['username'],))
            total_rows_logged_in_user = cursor.fetchone()[0]

        # Fetch data for the particular email address
        email_address = request.args.get('email')  # Get email address from the request parameters

        forms_data = []
        if email_address:
            forms_data = check_email_vendor(email_address)

        cursor.close()

        return render_template('autoemailsendingvendor.html', total_rows=total_rows,
                               total_rows_logged_in_user=total_rows_logged_in_user, forms_data=forms_data)

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while processing the request."

    except Exception as e:
        print("Error:", e)
        return "An unexpected error occurred."

def get_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT cr.request_number, cr.company_name AS customer_company_name, cr.email,
                   cr.category AS customer_category,
                   cr.logged_in_user_email AS customer_logged_in_user_email,
                   fb.titles AS form_titles, fb.name AS form_name, fb.email AS form_email,
                   fb.company_name AS form_company_name, fb.country, fb.state, fb.city,
                   fb.street_address, fb.street_address_2, fb.street_address_3,
                   fb.postal_code, fb.phone_number, fb.mobile_number, fb.gst_number,
                   fb.pan_number, fb.region AS form_region, fb.category AS form_category,
                   fb.form_number AS form_number, fb.request_number,
                   fb.submission_date AS form_submission_date,
                   ms.customer_account_group, ms.company_code, ms.sales_org,
                   ms.distribution_channel, ms.division, ms.name_1, ms.name_2, ms.search_1,
                   ms.search_2_old_customer_code, ms.street_3, ms.street_house_number,
                   ms.street_2, ms.street, ms.street_4,
                   ms.street_5, ms.district, ms.different_city, ms.pin_code, ms.city,
                   ms.country, ms.region, ms.language,
                   ms.telephone_number_1, ms.mobile_number_1, ms.contact_person_1_comments_of_mobile_number,
                   ms.fax, ms.extension, ms.email_1, ms.department_1_notes_of_email,
                   ms.mobile_phone_2, ms.contact_person_2_comments_of_mobile_number, ms.email_2,
                   ms.department_2_notes_of_email, ms.mobile_phone_3, ms.contact_person_3_comments_of_mobile_number,
                   ms.email_3, ms.department_3_notes_of_email, ms.legal_form, ms.bp_type,
                   ms.pan_card, ms.gst_category, ms.gstin_no, ms.annual_sales,
                   ms.currency, ms.sales_year, ms.sales_district, ms.sales_office,
                   ms.sales_group, ms.currency_2, ms.price_group, ms.cust_pric_procedure,
                   ms.order_combination_indicator, ms.delivering_plant, ms.shipping_conditions,
                   ms.underdel_tolerance, ms.overdeliv_tolerance, ms.indicator_customer_is_rebate_relevant,
                   ms.relevant_for_price_determination_id, ms.incoterms, ms.incoterms_location,
                   ms.payment_terms, ms.credit_control_area, ms.acct_assmt_grp_cust,
                   ms.tax_category, ms.tax_category_2, ms.tax_category_3, ms.tax_category_4,
                   ms.agent, ms.agent_code, ms.broker_agent, ms.broker_agent_code,
                   ms.forwarding_agent, ms.forwarding_agent_code, ms.sales_person,
                   ms.sales_person_code, ms.recon_account, ms.sort_key, ms.planning_group,
                   ms.payment_terms_2, ms.payment_methods, ms.dunning_procedure,
                   ms.relationship_category,  
                   ms.form_number AS ms_form_number,
                   ms.request_number AS ms_request_number, ms.submission_date AS ms_submission_date,
                   ms.submit_timestamp AS ms_submit_timestamp,
                   cmd.form_number AS changes_done_form_number, cmd.date_changed AS changes_done_date,
                   crf.details AS changes_requested_details,
                   crf.form_number AS changes_requested_form_number,
                   cad.form_number AS changes_done_it_form_number, cad.date_changed AS changes_done_it_date,
                   crt.details AS changes_requested_it_details,
                   crt.form_number AS changes_requested_it_form_number,
                   af.form_number AS changes_done_accounts_form_number,
                   itf.form_number AS changes_done_itf_form_number
            FROM customerrequested cr
            LEFT JOIN formsbyc fb ON cr.request_number = fb.request_number
            LEFT JOIN marketing_submission ms ON fb.form_number = ms.form_number
            LEFT JOIN changesdoneby_marketing cmd ON fb.form_number = cmd.form_number
            LEFT JOIN changesrequestedfromar crf ON fb.form_number = crf.form_number
            LEFT JOIN changesdoneby_ar cad ON fb.form_number = cad.form_number
            LEFT JOIN changes_requestedtoar crt ON fb.form_number = crt.form_number
            LEFT JOIN account_final af ON fb.form_number = af.form_number
            LEFT JOIN it_final itf ON fb.form_number = itf.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

# Function to check if form_number exists in changesdoneby_marketing
def form_number_exists_in_changesdoneby_marketing(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM changesdoneby_marketing WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_marketing
def form_number_exists_in_changesdoneby_purchase(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM changesdoneby_purchase WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_changesdoneby_ar(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM changesdoneby_ar WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_changesdoneby_ap(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM changesdoneby_ap WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_account_final(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM account_final WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_accountp_final(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM accountp_final WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_it_final(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM it_final WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_itv_final(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM itv_final WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

# Function to check if form_number exists in changesdoneby_ar
def form_number_exists_in_ite_final(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM it_excel_export WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

def form_number_exists_in_itve_final(cursor, form_number):
    try:
        query = "SELECT COUNT(*) FROM itv_excel_export WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        result = cursor.fetchone()[0]

        return result > 0

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return False

    except Exception as e:
        logging.error("Error: %s", e)
        return False

@app.route('/totalnewrowsinserted')
def totalnewrowsinserted():
    if 'username' not in session:
        return redirect(url_for('index'))
    try:
        email = session.get('username')  # Fetch email from session
        cursor = db.cursor(dictionary=True)

        # Fetch joined data from the database
        query = """
            SELECT 
                cr.company_name AS customer_company_name,
                cr.category AS customer_category,
                f.submission_date AS form_submission_date,
                f.form_number
            FROM 
                customerrequested cr
            JOIN 
                formsbyc f ON cr.request_number = f.request_number
            WHERE
                cr.logged_in_user_email = %s
        """
        cursor.execute(query, (email,))
        joined_data = cursor.fetchall()

        # Check if form_number exists in marketing_submission
        for data in joined_data:
            form_number = data['form_number']
            if form_number:
                cursor.execute("SELECT 1 FROM marketing_submission WHERE form_number = %s", (form_number,))
                form_exists = cursor.fetchone() is not None
                data['form_filled'] = form_exists

                if form_exists:
                    if data['customer_category'] == "Export (ZEXP)":
                        data['form_link'] = f"/arteamformeseear/{form_number}"
                    elif data['customer_category'] in ["Domestic (ZDOM)", "Ship to Party (ZDSH)"]:
                        data['form_link'] = f"/arteamformdsseear/{form_number}"
                    else:
                        data['form_link'] = "Unknown Category"
                else:
                    if data['customer_category'] == "Export (ZEXP)":
                        data['form_link'] = f"/marketingteame/{form_number}"
                    elif data['customer_category'] in ["Domestic (ZDOM)", "Ship to Party (ZDSH)"]:
                        data['form_link'] = f"/marketingteamds/{form_number}"
                    else:
                        data['form_link'] = "Unknown Category"
            else:
                data['form_link'] = None
                data['form_filled'] = False

        cursor.close()

        return render_template('totalnewrowsinserted.html', logged_in_user_email=email, form_details=joined_data)

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while fetching data from the database."

    except Exception as e:
        print("Error:", e)
        return "An unexpected error occurred."

@app.route('/totalnewrowsinsertedv')
def totalnewrowsinsertedv():
    if 'username' not in session:
        return redirect(url_for('index'))
    try:
        email = session.get('username')  # Fetch email from session
        cursor = db.cursor(dictionary=True)

        # Fetch joined data from the database
        query = """
            SELECT 
                vr.company_name AS customer_company_name,
                vr.category AS customer_category,
                fv.submission_date AS form_submission_date,
                fv.form_number
            FROM 
                vendorrequested vr
            JOIN 
                formsbyv fv ON vr.request_number = fv.request_number
            WHERE
                vr.logged_in_user_email = %s
        """
        cursor.execute(query, (email,))
        joined_data_vendor = cursor.fetchall()

        # Check if form_number exists in marketing_submission
        for data in joined_data_vendor:
            form_number = data['form_number']
            if form_number:
                cursor.execute("SELECT 1 FROM purchase_submission WHERE form_number = %s", (form_number,))
                form_exists = cursor.fetchone() is not None
                data['form_filled'] = form_exists

                if form_exists:
                    if data['customer_category'] == "Import (VIMP)":
                        data['form_link'] = f"/arteamformeseeap/{form_number}"
                    elif data['customer_category'] in ["Domestic (ZDOM)"]:
                        data['form_link'] = f"/arteamformdsseeap/{form_number}"
                    else:
                        data['form_link'] = "Unknown Category"
                else:
                    if data['customer_category'] == "Import (VIMP)":
                        data['form_link'] = f"/marketingteamve/{form_number}"
                    elif data['customer_category'] in ["Domestic (ZDOM)"]:
                        data['form_link'] = f"/marketingteamvds/{form_number}"
                    else:
                        data['form_link'] = "Unknown Category"
            else:
                data['form_link'] = None
                data['form_filled'] = False

        cursor.close()

        return render_template('totalnewrowsinsertedv.html', logged_in_user_email=email, form_details=joined_data_vendor)

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while fetching data from the database."

    except Exception as e:
        print("Error:", e)
        return "An unexpected error occurred."
def get_ar_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT cr.request_number, cr.company_name AS customer_company_name, cr.email,
                   cr.category AS customer_category,
                   cr.logged_in_user_email AS customer_logged_in_user_email,
                   fb.titles AS form_titles, fb.name AS form_name, fb.email AS form_email,
                   fb.company_name AS form_company_name, fb.country, fb.state, fb.city,
                   fb.street_address, fb.street_address_2, fb.street_address_3,
                   fb.postal_code, fb.phone_number, fb.mobile_number, fb.gst_number,
                   fb.pan_number, fb.region AS form_region, fb.category AS form_category,
                   fb.form_number AS form_number, fb.request_number,
                   fb.submission_date AS form_submission_date,
                   ms.customer_account_group, ms.company_code, ms.sales_org,
                   ms.distribution_channel, ms.division, ms.name_1, ms.name_2, ms.search_1,
                   ms.search_2_old_customer_code, ms.street_3, ms.street_house_number,
                   ms.street_2, ms.street, ms.street_4,
                   ms.street_5, ms.district, ms.different_city, ms.pin_code, ms.city,
                   ms.country, ms.region, ms.language,
                   ms.telephone_number_1, ms.mobile_number_1, ms.contact_person_1_comments_of_mobile_number,
                   ms.fax, ms.extension, ms.email_1, ms.department_1_notes_of_email,
                   ms.mobile_phone_2, ms.contact_person_2_comments_of_mobile_number, ms.email_2,
                   ms.department_2_notes_of_email, ms.mobile_phone_3, ms.contact_person_3_comments_of_mobile_number,
                   ms.email_3, ms.department_3_notes_of_email, ms.legal_form, ms.bp_type,
                   ms.pan_card, ms.gst_category, ms.gstin_no, ms.annual_sales,
                   ms.currency, ms.sales_year, ms.sales_district, ms.sales_office,
                   ms.sales_group, ms.currency_2, ms.price_group, ms.cust_pric_procedure,
                   ms.order_combination_indicator, ms.delivering_plant, ms.shipping_conditions,
                   ms.underdel_tolerance, ms.overdeliv_tolerance, ms.indicator_customer_is_rebate_relevant,
                   ms.relevant_for_price_determination_id, ms.incoterms, ms.incoterms_location,
                   ms.payment_terms, ms.credit_control_area, ms.acct_assmt_grp_cust,
                   ms.tax_category, ms.tax_category_2, ms.tax_category_3, ms.tax_category_4,
                   ms.agent, ms.agent_code, ms.broker_agent, ms.broker_agent_code,
                   ms.forwarding_agent, ms.forwarding_agent_code, ms.sales_person,
                   ms.sales_person_code, ms.recon_account, ms.sort_key, ms.planning_group,
                   ms.payment_terms_2, ms.payment_methods, ms.dunning_procedure,
                   ms.relationship_category,  
                   ms.form_number AS ms_form_number,
                   ms.request_number AS ms_request_number, ms.submission_date AS ms_submission_date,
                   ms.submit_timestamp AS ms_submit_timestamp,
                   cmd.form_number AS changes_done_form_number, cmd.date_changed AS changes_done_date,
                   crf.details AS changes_requested_details,
                   crf.form_number AS changes_requested_form_number,
                   cad.form_number AS changes_done_it_form_number, cad.date_changed AS changes_done_it_date,
                   crt.details AS changes_requested_it_details,
                   crt.form_number AS changes_requested_it_form_number,
                   af.form_number AS changes_done_accounts_form_number,
                   itf.form_number AS changes_done_itf_form_number
            FROM customerrequested cr
            LEFT JOIN formsbyc fb ON cr.request_number = fb.request_number
            LEFT JOIN marketing_submission ms ON fb.form_number = ms.form_number
            LEFT JOIN changesdoneby_marketing cmd ON fb.form_number = cmd.form_number
            LEFT JOIN changesrequestedfromar crf ON fb.form_number = crf.form_number
            LEFT JOIN changesdoneby_ar cad ON fb.form_number = cad.form_number
            LEFT JOIN changes_requestedtoar crt ON fb.form_number = crt.form_number
            LEFT JOIN account_final af ON fb.form_number = af.form_number
            LEFT JOIN it_final itf ON fb.form_number = itf.form_number
            WHERE crf.form_number = ms.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

def get_ap_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT vr.request_number, vr.company_name AS customer_company_name, vr.email,
                   vr.category AS customer_category,
                   vr.logged_in_user_email AS customer_logged_in_user_email,
                   fv.titles AS form_titles, fv.name AS form_name, fv.email AS form_email,
                   fv.company_name AS form_company_name, fv.country, fv.state, fv.city,
                   fv.street_address, fv.street_address_2, fv.street_address_3,
                   fv.postal_code, fv.phone_number, fv.mobile_number, fv.gst_number,
                   fv.pan_number, fv.region AS form_region, fv.category AS form_category,
                   fv.form_number AS form_number, fv.request_number,
                   fv.submission_date AS form_submission_date,
                   ps.partner_role, ps.creation_group, ps.titles, ps.name_org1, ps.name_org2, ps.postal_code, 
                   ps.city, ps.city_2, ps.country, ps.region, ps.timezone, ps.house_number, ps.saluation, 
                   ps.sort_text1, ps.sort_text2, ps.street_2, ps.street_3, ps.street, ps.telephoneno, 
                   ps.mobileno, ps.fax_no, ps.email_id, ps.legal_entity, ps.tax_type, ps.tax_number, 
                   ps.bp_type, ps.social_insurance, ps.company_code, ps.recon_account, ps.sort_key, 
                   ps.mmse_type, ps.certificate_date, ps.payment_term, ps.check_double_invoice, ps.payment_method, 
                   ps.p_org, ps.payment_terms, ps.incoterm, ps.incoterm_location, ps.g_r_iv_verification, 
                   ps.sr_based_iv_verificvcation, ps.purchase_group, ps.schema_group, ps.type_of_business, 
                   ps.pan_no, ps.vendor_class, ps.order_currency, ps.bank_country_key, ps.bank_key, ps.bank_acc_no, 
                   ps.account_holder_name,
                   ps.form_number AS ps_form_number,
                   ps.request_number AS ps_request_number, ps.submission_date AS ps_submission_date,
                   ps.submit_timestamp AS ps_submit_timestamp,
                   cmp.form_number AS changes_done_form_number, cmp.date_changed AS changes_done_date,
                   crfp.details AS changes_requested_details,
                   crfp.form_number AS changes_requested_form_number,
                   cap.form_number AS changes_done_it_form_number, cap.date_changed AS changes_done_it_date,
                   crp.details AS changes_requested_it_details,
                   crp.form_number AS changes_requested_it_form_number,
                   apf.form_number AS changes_done_accounts_form_number,
                   itv.form_number AS changes_done_itv_form_number
            FROM vendorrequested vr
            LEFT JOIN formsbyv fv ON vr.request_number = fv.request_number
            LEFT JOIN purchase_submission ps ON fv.form_number = ps.form_number
            LEFT JOIN changesdoneby_purchase cmp ON fv.form_number = cmp.form_number
            LEFT JOIN changesrequestedfromap crfp ON fv.form_number = crfp.form_number
            LEFT JOIN changesdoneby_ap cap ON fv.form_number = cap.form_number
            LEFT JOIN changes_requestedtoap crp ON fv.form_number = crp.form_number
            LEFT JOIN accountp_final apf ON fv.form_number = apf.form_number
            LEFT JOIN itv_final itv ON fv.form_number = itv.form_number
            WHERE crfp.form_number = ps.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

@app.route('/changesrequestedfromar')
def changesrequestedfromar():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_ar_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        for form_detail in form_details:
            form_number = form_detail.get('ms_form_number')

            # Check if the form_number exists in changesdoneby_marketing
            cursor = db.cursor(dictionary=True)
            query = "SELECT * FROM changesdoneby_marketing WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            exists = cursor.fetchone() is not None
            cursor.close()

            # Set form_number_exists_in_changesdoneby_marketing based on existence
            form_detail['form_number_exists_in_changesdoneby_marketing'] = exists

            # changes_done_form_number = form_detail.get('changes_done_form_number')
            changes_requested_form_number = form_detail.get('changes_requested_form_number')
            changes_requested_details = form_detail.get('changes_requested_details')

            if form_number is None:
                logging.error("Missing 'ms_form_number' in form_detail: %s", form_detail)
                continue

            if changes_requested_form_number:
                form_detail['marketing_changes'] = changes_requested_details
            else:
                form_detail['marketing_changes'] = ''

        return render_template('changesrequestedfromar.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in changesrequestedfromar(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/changesrequestedfromap')
def changesrequestedfromap():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_ap_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        for form_detail in form_details:
            form_number = form_detail.get('ps_form_number')

            # Check if the form_number exists in changesdoneby_marketing
            cursor = db.cursor(dictionary=True)
            query = "SELECT * FROM changesdoneby_purchase WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            exists = cursor.fetchone() is not None
            cursor.close()

            # Set form_number_exists_in_changesdoneby_marketing based on existence
            form_detail['form_number_exists_in_changesdoneby_purchase'] = exists

            # changes_done_form_number = form_detail.get('changes_done_form_number')
            changes_requested_form_number = form_detail.get('changes_requested_form_number')
            changes_requested_details = form_detail.get('changes_requested_details')

            if form_number is None:
                logging.error("Missing 'ps_form_number' in form_detail: %s", form_detail)
                continue

            if changes_requested_form_number:
                form_detail['marketing_changes'] = changes_requested_details
            else:
                form_detail['marketing_changes'] = ''

        return render_template('changesrequestedfromap.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in changesrequestedfromap(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/updateformds/<form_number>')
def updateformds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyc WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        cursor.close()

        initial_option = form_details['company_code']
        initial_option_2 = form_details['sales_org']
        initial_option_3 = form_details['division']
        initial_option_4 = form_details['legal_form']
        initial_option_5 = form_details['bp_type']
        initial_option_6 = form_details['currency']
        initial_option_7 = form_details['sales_year']
        initial_option_8 = form_details['sales_office']
        initial_option_9 = form_details['sales_group']
        initial_option_10 = form_details['currency_2']
        initial_option_11 = form_details['delivering_plant']
        initial_option_12 = form_details['incoterms']
        initial_option_13 = form_details['credit_control_area']
        initial_option_14 = form_details['payment_terms']
        initial_option_15 = form_details['recon_account']
        initial_option_16 = form_details['sort_key']
        initial_option_17 = form_details['planning_group']
        initial_option_18 = form_details['payment_terms_2']
        initial_option_19 = form_details['payment_methods']

        return render_template('updateformds.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12, initial_option_13=initial_option_13, initial_option_14=initial_option_14, initial_option_15=initial_option_15, initial_option_16=initial_option_16, initial_option_17=initial_option_17, initial_option_18=initial_option_18, initial_option_19=initial_option_19)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/updateformvds/<form_number>')
def updateformvds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyv WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        cursor.close()

        initial_option = form_details['p_org']
        initial_option_2 = form_details['legal_entity']
        initial_option_3 = form_details['bp_type']
        initial_option_4 = form_details['social_insurance2']
        initial_option_5 = form_details['purchase_group']
        initial_option_6 = form_details['type_of_business']
        initial_option_7 = form_details['order_currency']
        initial_option_8 = form_details['incoterm']
        initial_option_9 = form_details['payment_terms']
        initial_option_10 = form_details['recon_account']
        initial_option_11 = form_details['sort_key']
        initial_option_12 = form_details['payment_method']

        return render_template('updateformvds.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_mr_form_details', methods=['POST'])
def submit_mr_form_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromar'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_marketing
        query = "INSERT INTO changesdoneby_marketing (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromar if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromar (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Check if GST and PAN documents are viewed
        if not request.form.get('gst_viewed') or not request.form.get('pan_viewed'):
            flash('Please view both GST and PAN documents before submitting.', 'warning')
            return redirect(url_for('updateformds', form_number=form_number))

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromar'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformds', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformds', form_number=form_number))
            updated_data[field] = request.form[field]

        # Fetch new agent codes from the form
        agent_code = request.form.get('agent_code', '').strip()
        broker_agent_code = request.form.get('broker_agent_code', '').strip()
        forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()

        # Update agent, broker agent, and forwarding agent based on new values
        updated_data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
        updated_data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
        updated_data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''

        # # Fetch new sales_org and division values from the form
        # new_sales_org = request.form.get('sales_org', existing_data.get('sales_org', ''))
        # new_division = request.form.get('division', existing_data.get('division', ''))
        #
        # # Update sales_org and division in updated_data
        # updated_data['sales_org'] = new_sales_org
        # updated_data['division'] = new_division
        #
        # # Update credit_control_area based on new values
        # sales_org_numeric = int(re.search(r'\d+', new_sales_org).group())
        # division_numeric = int(re.search(r'\d+', new_division).group())
        # updated_data['credit_control_area'] = sales_org_numeric + division_numeric

        # Validate annual sales, currency, and sales year
        annual_sales = request.form.get('annual_sales', '').strip()
        currency = request.form.get('currency', '').strip()
        sales_year = request.form.get('sales_year', '').strip()

        if (annual_sales and (not currency or not sales_year)) or (
            currency and (not annual_sales or not sales_year)) or (
            sales_year and (not annual_sales or not currency)):
            cursor.close()
            flash('Please fill all fields: Annual Sales, Currency, and Sales Year, or leave them all empty.', 'error')
            return redirect(url_for('updateformds', form_number=form_number))
        elif not annual_sales and not currency and not sales_year:
            updated_data['annual_sales'] = ''
            updated_data['currency'] = ''
            updated_data['sales_year'] = ''
        else:
            updated_data['annual_sales'] = annual_sales
            updated_data['currency'] = currency
            updated_data['sales_year'] = sales_year

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE marketing_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromar'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformds', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformds', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/submit_pr_form_details', methods=['POST'])
def submit_pr_form_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromap'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_marketing
        query = "INSERT INTO changesdoneby_purchase (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromar if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromap (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Check if GST and PAN documents are viewed
        if not request.form.get('gst_viewed') or not request.form.get('pan_viewed'):
            flash('Please view both GST and PAN documents before submitting.', 'warning')
            return redirect(url_for('updateformvds', form_number=form_number))

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromap'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules_vendor.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformvds', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformvds', form_number=form_number))
            updated_data[field] = request.form[field]

        # Specifically map p_org to company_code and payment_terms to payment_term
        updated_data['company_code'] = request.form.get('p_org', '')
        updated_data['payment_term'] = request.form.get('payment_terms', '')

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE purchase_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromap'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformvds', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformvds', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/updateforme/<form_number>')
def updateforme(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        initial_option = form_details['company_code']
        initial_option_2 = form_details['sales_org']
        initial_option_3 = form_details['division']
        initial_option_4 = form_details['legal_form']
        initial_option_5 = form_details['bp_type']
        initial_option_6 = form_details['currency']
        initial_option_7 = form_details['sales_year']
        initial_option_8 = form_details['sales_office']
        initial_option_9 = form_details['sales_group']
        initial_option_10 = form_details['currency_2']
        initial_option_11 = form_details['delivering_plant']
        initial_option_12 = form_details['incoterms']
        initial_option_13 = form_details['credit_control_area']
        initial_option_14 = form_details['payment_terms']
        initial_option_15 = form_details['recon_account']
        initial_option_16 = form_details['sort_key']
        initial_option_17 = form_details['planning_group']
        initial_option_18 = form_details['payment_terms_2']
        initial_option_19 = form_details['payment_methods']

        return render_template('updateforme.html', form_number=form_number, form_details=form_details, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12, initial_option_13=initial_option_13, initial_option_14=initial_option_14, initial_option_15=initial_option_15, initial_option_16=initial_option_16, initial_option_17=initial_option_17, initial_option_18=initial_option_18, initial_option_19=initial_option_19)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/updateformve/<form_number>')
def updateformve(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        initial_option = form_details['p_org']
        initial_option_2 = form_details['legal_entity']
        initial_option_3 = form_details['bp_type']
        initial_option_4 = form_details['social_insurance2']
        initial_option_5 = form_details['purchase_group']
        initial_option_6 = form_details['type_of_business']
        initial_option_7 = form_details['order_currency']
        initial_option_8 = form_details['incoterm']
        initial_option_9 = form_details['payment_terms']
        initial_option_10 = form_details['recon_account']
        initial_option_11 = form_details['sort_key']
        initial_option_12 = form_details['payment_method']

        return render_template('updateformvds.html', form_number=form_number, form_details=form_details, initial_option=initial_option,
                               initial_option_2=initial_option_2, initial_option_3=initial_option_3,
                               initial_option_4=initial_option_4, initial_option_5=initial_option_5,
                               initial_option_6=initial_option_6, initial_option_7=initial_option_7,
                               initial_option_8=initial_option_8, initial_option_9=initial_option_9,
                               initial_option_10=initial_option_10, initial_option_11=initial_option_11,
                               initial_option_12=initial_option_12)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_mre_form_details', methods=['POST'])
def submit_mre_form_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromar'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_marketing
        query = "INSERT INTO changesdoneby_marketing (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromar if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromar (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromar'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules_for_e.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateforme', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateforme', form_number=form_number))
            updated_data[field] = request.form[field]

        # Fetch new agent codes from the form
        agent_code = request.form.get('agent_code', '').strip()
        broker_agent_code = request.form.get('broker_agent_code', '').strip()
        forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()

        # Update agent, broker agent, and forwarding agent based on new values
        updated_data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
        updated_data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
        updated_data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''

        # # Fetch new sales_org and division values from the form
        # new_sales_org = request.form.get('sales_org', existing_data.get('sales_org', ''))
        # new_division = request.form.get('division', existing_data.get('division', ''))
        #
        # # Update sales_org and division in updated_data
        # updated_data['sales_org'] = new_sales_org
        # updated_data['division'] = new_division
        #
        # # Update credit_control_area based on new values
        # sales_org_numeric = int(re.search(r'\d+', new_sales_org).group())
        # division_numeric = int(re.search(r'\d+', new_division).group())
        # updated_data['credit_control_area'] = sales_org_numeric + division_numeric

        # Validate annual sales, currency, and sales year
        annual_sales = request.form.get('annual_sales', '').strip()
        currency = request.form.get('currency', '').strip()
        sales_year = request.form.get('sales_year', '').strip()

        if (annual_sales and (not currency or not sales_year)) or (
            currency and (not annual_sales or not sales_year)) or (
            sales_year and (not annual_sales or not currency)):
            cursor.close()
            flash('Please fill all fields: Annual Sales, Currency, and Sales Year, or leave them all empty.', 'error')
            return redirect(url_for('updateformds', form_number=form_number))
        elif not annual_sales and not currency and not sales_year:
            updated_data['annual_sales'] = ''
            updated_data['currency'] = ''
            updated_data['sales_year'] = ''
        else:
            updated_data['annual_sales'] = annual_sales
            updated_data['currency'] = currency
            updated_data['sales_year'] = sales_year

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE marketing_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromar'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateforme', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateforme', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/submit_pre_form_details', methods=['POST'])
def submit_pre_form_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromap'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_marketing
        query = "INSERT INTO changesdoneby_purchase (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromar if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromap (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromap'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules_vendor_i.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformve', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformve', form_number=form_number))
            updated_data[field] = request.form[field]

        # Specifically map p_org to company_code and payment_terms to payment_term
        updated_data['company_code'] = request.form.get('p_org', '')
        updated_data['payment_term'] = request.form.get('payment_terms', '')

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE marketing_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromap'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformve', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformve', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()
def get_it_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT cr.request_number, cr.company_name AS customer_company_name, cr.email,
                   cr.category AS customer_category,
                   cr.logged_in_user_email AS customer_logged_in_user_email,
                   fb.titles AS form_titles, fb.name AS form_name, fb.email AS form_email,
                   fb.company_name AS form_company_name, fb.country, fb.state, fb.city,
                   fb.street_address, fb.street_address_2, fb.street_address_3,
                   fb.postal_code, fb.phone_number, fb.mobile_number, fb.gst_number,
                   fb.pan_number, fb.region AS form_region, fb.category AS form_category,
                   fb.form_number AS form_number, fb.request_number,
                   fb.submission_date AS form_submission_date,
                   ms.customer_account_group, ms.company_code, ms.sales_org,
                   ms.distribution_channel, ms.division, ms.name_1, ms.name_2, ms.search_1,
                   ms.search_2_old_customer_code, ms.street_3, ms.street_house_number,
                   ms.street_2, ms.street, ms.street_4,
                   ms.street_5, ms.district, ms.different_city, ms.pin_code, ms.city,
                   ms.country, ms.region, ms.language,
                   ms.telephone_number_1, ms.mobile_number_1, ms.contact_person_1_comments_of_mobile_number,
                   ms.fax, ms.extension, ms.email_1, ms.department_1_notes_of_email,
                   ms.mobile_phone_2, ms.contact_person_2_comments_of_mobile_number, ms.email_2,
                   ms.department_2_notes_of_email, ms.mobile_phone_3, ms.contact_person_3_comments_of_mobile_number,
                   ms.email_3, ms.department_3_notes_of_email, ms.legal_form, ms.bp_type,
                   ms.pan_card, ms.gst_category, ms.gstin_no, ms.annual_sales,
                   ms.currency, ms.sales_year, ms.sales_district, ms.sales_office,
                   ms.sales_group, ms.currency_2, ms.price_group, ms.cust_pric_procedure,
                   ms.order_combination_indicator, ms.delivering_plant, ms.shipping_conditions,
                   ms.underdel_tolerance, ms.overdeliv_tolerance, ms.indicator_customer_is_rebate_relevant,
                   ms.relevant_for_price_determination_id, ms.incoterms, ms.incoterms_location,
                   ms.payment_terms, ms.credit_control_area, ms.acct_assmt_grp_cust,
                   ms.tax_category, ms.tax_category_2, ms.tax_category_3, ms.tax_category_4,
                   ms.agent, ms.agent_code, ms.broker_agent, ms.broker_agent_code,
                   ms.forwarding_agent, ms.forwarding_agent_code, ms.sales_person,
                   ms.sales_person_code, ms.recon_account, ms.sort_key, ms.planning_group,
                   ms.payment_terms_2, ms.payment_methods, ms.dunning_procedure,
                   ms.relationship_category,  
                   ms.form_number AS ms_form_number,
                   ms.request_number AS ms_request_number, ms.submission_date AS ms_submission_date,
                   ms.submit_timestamp AS ms_submit_timestamp,
                   cmd.form_number AS changes_done_form_number, cmd.date_changed AS changes_done_date,
                   crf.details AS changes_requested_details,
                   crf.form_number AS changes_requested_form_number,
                   cad.form_number AS changes_done_it_form_number, cad.date_changed AS changes_done_it_date,
                   crt.details AS changes_requested_it_details,
                   crt.form_number AS changes_requested_it_form_number,
                   af.form_number AS changes_done_accounts_form_number,
                   itf.form_number AS changes_done_itf_form_number
            FROM customerrequested cr
            LEFT JOIN formsbyc fb ON cr.request_number = fb.request_number
            LEFT JOIN marketing_submission ms ON fb.form_number = ms.form_number
            LEFT JOIN changesdoneby_marketing cmd ON fb.form_number = cmd.form_number
            LEFT JOIN changesrequestedfromar crf ON fb.form_number = crf.form_number
            LEFT JOIN changesdoneby_ar cad ON fb.form_number = cad.form_number
            LEFT JOIN changes_requestedtoar crt ON fb.form_number = crt.form_number
            LEFT JOIN account_final af ON fb.form_number = af.form_number
            LEFT JOIN it_final itf ON fb.form_number = itf.form_number
            WHERE crt.form_number = ms.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

def get_itv_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT vr.request_number, vr.company_name AS customer_company_name, vr.email,
                   vr.category AS customer_category,
                   vr.logged_in_user_email AS customer_logged_in_user_email,
                   fv.titles AS form_titles, fv.name AS form_name, fv.email AS form_email,
                   fv.company_name AS form_company_name, fv.country, fv.state, fv.city,
                   fv.street_address, fv.street_address_2, fv.street_address_3,
                   fv.postal_code, fv.phone_number, fv.mobile_number, fv.gst_number,
                   fv.pan_number, fv.region AS form_region, fv.category AS form_category,
                   fv.form_number AS form_number, fv.request_number,
                   fv.submission_date AS form_submission_date,
                   ps.partner_role, ps.creation_group, ps.titles, ps.name_org1, ps.name_org2, ps.postal_code, 
                   ps.city, ps.city_2, ps.country, ps.region, ps.timezone, ps.house_number, ps.saluation, 
                   ps.sort_text1, ps.sort_text2, ps.street_2, ps.street_3, ps.street, ps.telephoneno, 
                   ps.mobileno, ps.fax_no, ps.email_id, ps.legal_entity, ps.tax_type, ps.tax_number, 
                   ps.bp_type, ps.social_insurance, ps.company_code, ps.recon_account, ps.sort_key, 
                   ps.mmse_type, ps.certificate_date, ps.payment_term, ps.check_double_invoice, ps.payment_method, 
                   ps.p_org, ps.payment_terms, ps.incoterm, ps.incoterm_location, ps.g_r_iv_verification, 
                   ps.sr_based_iv_verificvcation, ps.purchase_group, ps.schema_group, ps.type_of_business, 
                   ps.pan_no, ps.vendor_class, ps.order_currency, ps.bank_country_key, ps.bank_key, ps.bank_acc_no, 
                   ps.account_holder_name,
                   ps.form_number AS ps_form_number,
                   ps.request_number AS ps_request_number, ps.submission_date AS ps_submission_date,
                   ps.submit_timestamp AS ps_submit_timestamp,
                   cmp.form_number AS changes_done_form_number, cmp.date_changed AS changes_done_date,
                   crfp.details AS changes_requested_details,
                   crfp.form_number AS changes_requested_form_number,
                   cap.form_number AS changes_done_it_form_number, cap.date_changed AS changes_done_it_date,
                   crp.details AS changes_requested_it_details,
                   crp.form_number AS changes_requested_it_form_number,
                   apf.form_number AS changes_done_accounts_form_number,
                   itv.form_number AS changes_done_itv_form_number
            FROM vendorrequested vr
            LEFT JOIN formsbyv fv ON vr.request_number = fv.request_number
            LEFT JOIN purchase_submission ps ON fv.form_number = ps.form_number
            LEFT JOIN changesdoneby_purchase cmp ON fv.form_number = cmp.form_number
            LEFT JOIN changesrequestedfromap crfp ON fv.form_number = crfp.form_number
            LEFT JOIN changesdoneby_ap cap ON fv.form_number = cap.form_number
            LEFT JOIN changes_requestedtoap crp ON fv.form_number = crp.form_number
            LEFT JOIN accountp_final apf ON fv.form_number = apf.form_number
            LEFT JOIN itv_final itv ON fv.form_number = itv.form_number
            WHERE crp.form_number = ps.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

@app.route('/changesrequestedfromit')
def changesrequestedfromit():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_it_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ms_form_number')
            # changes_done_it_form_number = form_detail.get('changes_done_it_form_number')
            changes_requested_it_form_number = form_detail.get('changes_requested_it_form_number')
            changes_requested_it_details = form_detail.get('changes_requested_it_details')

            if form_number is None:
                logging.error("Missing 'ms_form_number' in form_detail: %s", form_detail)
                continue

            # Check if the form_number exists in changesdoneby_ar
            cursor = db.cursor(dictionary=True)
            query = "SELECT * FROM changesdoneby_ar WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            exists = cursor.fetchone() is not None
            cursor.close()

            # Set form_number_exists_in_changesdoneby_ar based on existence
            form_detail['form_number_exists_in_changesdoneby_ar'] = exists

            if changes_requested_it_form_number:
                form_detail['marketing_changes'] = changes_requested_it_details
            else:
                form_detail['marketing_changes'] = ''

        # Render the page after processing all form details
        return render_template('changesrequestedfromit.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in changesrequestedfromit(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/changesrequestedfromitv')
def changesrequestedfromitv():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_itv_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ps_form_number')
            # changes_done_it_form_number = form_detail.get('changes_done_it_form_number')
            changes_requested_it_form_number = form_detail.get('changes_requested_it_form_number')
            changes_requested_it_details = form_detail.get('changes_requested_it_details')

            if form_number is None:
                logging.error("Missing 'ps_form_number' in form_detail: %s", form_detail)
                continue

            # Check if the form_number exists in changesdoneby_ar
            cursor = db.cursor(dictionary=True)
            query = "SELECT * FROM changesdoneby_ap WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            exists = cursor.fetchone() is not None
            cursor.close()

            # Set form_number_exists_in_changesdoneby_ar based on existence
            form_detail['form_number_exists_in_changesdoneby_ap'] = exists

            if changes_requested_it_form_number:
                form_detail['marketing_changes'] = changes_requested_it_details
            else:
                form_detail['marketing_changes'] = ''

        # Render the page after processing all form details
        return render_template('changesrequestedfromitv.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in changesrequestedfromitv(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/updateformitds/<form_number>')
def updateformitds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyc WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        cursor.close()

        initial_option = form_details['company_code']
        initial_option_2 = form_details['sales_org']
        initial_option_3 = form_details['division']
        initial_option_4 = form_details['legal_form']
        initial_option_5 = form_details['bp_type']
        initial_option_6 = form_details['currency']
        initial_option_7 = form_details['sales_year']
        initial_option_8 = form_details['sales_office']
        initial_option_9 = form_details['sales_group']
        initial_option_10 = form_details['currency_2']
        initial_option_11 = form_details['delivering_plant']
        initial_option_12 = form_details['incoterms']
        initial_option_13 = form_details['credit_control_area']
        initial_option_14 = form_details['payment_terms']
        initial_option_15 = form_details['recon_account']
        initial_option_16 = form_details['sort_key']
        initial_option_17 = form_details['planning_group']
        initial_option_18 = form_details['payment_terms_2']
        initial_option_19 = form_details['payment_methods']

        return render_template('updateformitds.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12, initial_option_13=initial_option_13, initial_option_14=initial_option_14, initial_option_15=initial_option_15, initial_option_16=initial_option_16, initial_option_17=initial_option_17, initial_option_18=initial_option_18, initial_option_19=initial_option_19)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_ar_form_details', methods=['POST'])
def submit_ar_form_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromit'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_ar
        query = "INSERT INTO changesdoneby_ar (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromit if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromit (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Check if GST and PAN documents are viewed
        if not request.form.get('gst_viewed') or not request.form.get('pan_viewed'):
            flash('Please view both GST and PAN documents before submitting.', 'warning')
            return redirect(url_for('updateformitds', form_number=form_number))

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromit'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformitds', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformitds', form_number=form_number))
            updated_data[field] = request.form[field]

        # Fetch new agent codes from the form
        agent_code = request.form.get('agent_code', '').strip()
        broker_agent_code = request.form.get('broker_agent_code', '').strip()
        forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()

        # Update agent, broker agent, and forwarding agent based on new values
        updated_data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
        updated_data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
        updated_data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''

        # # Fetch new sales_org and division values from the form
        # new_sales_org = request.form.get('sales_org', existing_data.get('sales_org', ''))
        # new_division = request.form.get('division', existing_data.get('division', ''))
        #
        # # Update sales_org and division in updated_data
        # updated_data['sales_org'] = new_sales_org
        # updated_data['division'] = new_division
        #
        # # Update credit_control_area based on new values
        # sales_org_numeric = int(re.search(r'\d+', new_sales_org).group())
        # division_numeric = int(re.search(r'\d+', new_division).group())
        # updated_data['credit_control_area'] = sales_org_numeric + division_numeric

        # Validate annual sales, currency, and sales year
        annual_sales = request.form.get('annual_sales', '').strip()
        currency = request.form.get('currency', '').strip()
        sales_year = request.form.get('sales_year', '').strip()

        if (annual_sales and (not currency or not sales_year)) or (
            currency and (not annual_sales or not sales_year)) or (
            sales_year and (not annual_sales or not currency)):
            cursor.close()
            flash('Please fill all fields: Annual Sales, Currency, and Sales Year, or leave them all empty.', 'error')
            return redirect(url_for('updateformitds', form_number=form_number))
        elif not annual_sales and not currency and not sales_year:
            updated_data['annual_sales'] = ''
            updated_data['currency'] = ''
            updated_data['sales_year'] = ''
        else:
            updated_data['annual_sales'] = annual_sales
            updated_data['currency'] = currency
            updated_data['sales_year'] = sales_year

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE marketing_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromit'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformitds', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformitds', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/updateformitvds/<form_number>')
def updateformitvds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyv WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        cursor.close()

        initial_option = form_details['p_org']
        initial_option_2 = form_details['legal_entity']
        initial_option_3 = form_details['bp_type']
        initial_option_4 = form_details['social_insurance2']
        initial_option_5 = form_details['purchase_group']
        initial_option_6 = form_details['type_of_business']
        initial_option_7 = form_details['order_currency']
        initial_option_8 = form_details['incoterm']
        initial_option_9 = form_details['payment_terms']
        initial_option_10 = form_details['recon_account']
        initial_option_11 = form_details['sort_key']
        initial_option_12 = form_details['payment_method']

        return render_template('updateformitvds.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_ap_form_details', methods=['POST'])
def submit_ap_form_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromitv'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_ar
        query = "INSERT INTO changesdoneby_ap (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromit if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromitv (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Check if GST and PAN documents are viewed
        if not request.form.get('gst_viewed') or not request.form.get('pan_viewed'):
            flash('Please view both GST and PAN documents before submitting.', 'warning')
            return redirect(url_for('updateformitvds', form_number=form_number))

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromitv'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules_vendor.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformitvds', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformitvds', form_number=form_number))
            updated_data[field] = request.form[field]

        # Specifically map p_org to company_code and payment_terms to payment_term
        updated_data['company_code'] = request.form.get('p_org', '')
        updated_data['payment_term'] = request.form.get('payment_terms', '')

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE purchase_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromitv'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformitvds', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformitvds', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/updateformite/<form_number>')
def updateformite(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        initial_option = form_details['company_code']
        initial_option_2 = form_details['sales_org']
        initial_option_3 = form_details['division']
        initial_option_4 = form_details['legal_form']
        initial_option_5 = form_details['bp_type']
        initial_option_6 = form_details['currency']
        initial_option_7 = form_details['sales_year']
        initial_option_8 = form_details['sales_office']
        initial_option_9 = form_details['sales_group']
        initial_option_10 = form_details['currency_2']
        initial_option_11 = form_details['delivering_plant']
        initial_option_12 = form_details['incoterms']
        initial_option_13 = form_details['credit_control_area']
        initial_option_14 = form_details['payment_terms']
        initial_option_15 = form_details['recon_account']
        initial_option_16 = form_details['sort_key']
        initial_option_17 = form_details['planning_group']
        initial_option_18 = form_details['payment_terms_2']
        initial_option_19 = form_details['payment_methods']

        return render_template('updateformite.html', form_number=form_number, form_details=form_details, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12, initial_option_13=initial_option_13, initial_option_14=initial_option_14, initial_option_15=initial_option_15, initial_option_16=initial_option_16, initial_option_17=initial_option_17, initial_option_18=initial_option_18, initial_option_19=initial_option_19)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_ar_forme_details', methods=['POST'])
def submit_ar_forme_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromit'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_ar
        query = "INSERT INTO changesdoneby_ar (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromit if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromit (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromit'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules_for_e.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformite', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformite', form_number=form_number))
            updated_data[field] = request.form[field]

        # Fetch new agent codes from the form
        agent_code = request.form.get('agent_code', '').strip()
        broker_agent_code = request.form.get('broker_agent_code', '').strip()
        forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()

        # Update agent, broker agent, and forwarding agent based on new values
        updated_data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
        updated_data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
        updated_data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''

        # # Fetch new sales_org and division values from the form
        # new_sales_org = request.form.get('sales_org', existing_data.get('sales_org', ''))
        # new_division = request.form.get('division', existing_data.get('division', ''))
        #
        # # Update sales_org and division in updated_data
        # updated_data['sales_org'] = new_sales_org
        # updated_data['division'] = new_division
        #
        # # Update credit_control_area based on new values
        # sales_org_numeric = int(re.search(r'\d+', new_sales_org).group())
        # division_numeric = int(re.search(r'\d+', new_division).group())
        # updated_data['credit_control_area'] = sales_org_numeric + division_numeric

        # Validate annual sales, currency, and sales year
        annual_sales = request.form.get('annual_sales', '').strip()
        currency = request.form.get('currency', '').strip()
        sales_year = request.form.get('sales_year', '').strip()

        if (annual_sales and (not currency or not sales_year)) or (
            currency and (not annual_sales or not sales_year)) or (
            sales_year and (not annual_sales or not currency)):
            cursor.close()
            flash('Please fill all fields: Annual Sales, Currency, and Sales Year, or leave them all empty.', 'error')
            return redirect(url_for('updateformite', form_number=form_number))
        elif not annual_sales and not currency and not sales_year:
            updated_data['annual_sales'] = ''
            updated_data['currency'] = ''
            updated_data['sales_year'] = ''
        else:
            updated_data['annual_sales'] = annual_sales
            updated_data['currency'] = currency
            updated_data['sales_year'] = sales_year

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE marketing_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromit'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformite', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformite', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/updateformitve/<form_number>')
def updateformitve(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        initial_option = form_details['p_org']
        initial_option_2 = form_details['legal_entity']
        initial_option_3 = form_details['bp_type']
        initial_option_4 = form_details['social_insurance2']
        initial_option_5 = form_details['purchase_group']
        initial_option_6 = form_details['type_of_business']
        initial_option_7 = form_details['order_currency']
        initial_option_8 = form_details['incoterm']
        initial_option_9 = form_details['payment_terms']
        initial_option_10 = form_details['recon_account']
        initial_option_11 = form_details['sort_key']
        initial_option_12 = form_details['payment_method']

        return render_template('updateformitve.html', form_number=form_number, form_details=form_details, initial_option=initial_option, initial_option_2=initial_option_2, initial_option_3=initial_option_3, initial_option_4=initial_option_4, initial_option_5=initial_option_5, initial_option_6=initial_option_6, initial_option_7=initial_option_7, initial_option_8=initial_option_8, initial_option_9=initial_option_9, initial_option_10=initial_option_10, initial_option_11=initial_option_11, initial_option_12=initial_option_12)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_ap_forme_details', methods=['POST'])
def submit_ap_forme_details():
    form_number = request.form.get('form_number')
    if not form_number:
        # flash('Form number is missing.', 'error')
        return redirect(url_for('changesrequestedfromitv'))

    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')

    try:
        cursor = db.cursor(dictionary=True)

        # Insert into changesdoneby_ar
        query = "INSERT INTO changesdoneby_ap (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(query, (form_number, date_changed))
        db.commit()

        # Insert into changesrequestedfromit if changes_required is present
        if changes_required:
            query = "INSERT INTO changesrequestedfromitv (form_number, details) VALUES (%s, %s)"
            cursor.execute(query, (form_number, changes_required))
            db.commit()

        # Fetch existing data from marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        existing_data = cursor.fetchone()

        if not existing_data:
            cursor.close()
            # flash('Form not found in marketing_submission table.', 'error')
            return redirect(url_for('changesrequestedfromitv'))

        updated_data = existing_data.copy()  # Make a copy of existing data

        # Update the existing data with new values from the form
        for field, pattern in validation_rules_vendor_i.items():
            if field not in request.form:
                cursor.close()
                flash(f'Missing form field: {field}', 'error')
                return redirect(url_for('updateformitve', form_number=form_number))
            if not re.match(pattern, request.form[field]):
                cursor.close()
                flash(f'Invalid value for {field.replace("_", " ").title()}', 'error')
                return redirect(url_for('updateformitve', form_number=form_number))
            updated_data[field] = request.form[field]

        # Specifically map p_org to company_code and payment_terms to payment_term
        updated_data['company_code'] = request.form.get('p_org', '')
        updated_data['payment_term'] = request.form.get('payment_terms', '')

        update_fields = ', '.join([f"{key} = %({key})s" for key in updated_data.keys() if key != 'form_number'])
        sql = f"UPDATE purchase_submission SET {update_fields} WHERE form_number = %(form_number)s"

        # Execute update
        cursor.execute(sql, updated_data)
        db.commit()
        cursor.close()

        # flash('Data successfully updated', 'success')
        return redirect(url_for('changesrequestedfromitv'))

    except KeyError as e:
        logging.error(f"Missing key: {e}")
        traceback.print_exc()
        flash(f'Missing form field: {e}', 'error')
        return redirect(url_for('updateformitve', form_number=form_number))

    except Exception as e:
        logging.error(f"Error: {e}")
        traceback.print_exc()
        flash(f'Form not Submitted. Error: {e}', 'error')
        return redirect(url_for('updateformitve', form_number=form_number))

    finally:
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'db' in locals() and db is not None and db.is_connected():
            db.close()

@app.route('/formds/<request_number>')
def formds(request_number):
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT company_name, email, category FROM customerrequested WHERE request_number = %s", (request_number,))
    result = cursor.fetchone()
    cursor.close()
    if result:
        company_name = result['company_name']
        email = result['email']
        category = result['category']
    else:
        company_name = ""
        email = ""
        category = ""
    return render_template('formds.html', request_number=request_number, category=category, company_name=company_name, email=email)

@app.route('/formvds/<request_number>')
def formvds(request_number):
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT company_name, email, category FROM vendorrequested WHERE request_number = %s", (request_number,))
    result = cursor.fetchone()
    cursor.close()
    if result:
        company_name = result['company_name']
        email = result['email']
        category = result['category']
    else:
        company_name = ""
        email = ""
        category = ""
    return render_template('formvds.html', request_number=request_number, category=category, company_name=company_name, email=email)


@app.route('/submit_request/<request_number>', methods=['POST'])
def submit_request(request_number):
    if request.method == 'POST':
        try:
            # Check if the request_number already exists in the submitted forms table
            cursor = db.cursor()
            cursor.execute("SELECT * FROM formsbyc WHERE request_number = %s", (request_number,))
            existing_form = cursor.fetchone()
            cursor.close()

            if existing_form:
                return "Form has already been submitted for this request number."

            # Fetch the category from the database based on the request_number
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT category FROM customerrequested WHERE request_number = %s", (request_number,))
            result = cursor.fetchone()
            cursor.close()

            if not result:
                return "Request number not found."

            category = result['category']

            # Extract form data
            titles = request.form.get('titles')
            name = request.form.get('name')
            email = request.form.get('email')
            company_name = request.form.get('company_name')
            country = request.form.get('country')
            state = request.form.get('state')
            city = request.form.get('city')
            street_address = request.form.get('street_address')
            street_address_2 = request.form.get('street_address_2')
            street_address_3 = request.form.get('street_address_3')
            postal_code = request.form.get('postal_code')
            phone_number = request.form.get('phone_number')
            mobile_number = request.form.get('mobile_number')
            gst_number = request.form.get('gst_number')
            gst_document = request.files.get('gst_document')
            pan_number = request.form.get('pan_number')
            pan_document = request.files.get('pan_document')

            # Map titles to their corresponding codes
            title_mapping = {
                "Ms.": "0001",
                "Mr.": "0002",
                "Company": "3000",
                "Mr. and Mrs": "4000",
                "M/S": "5000"
            }
            titles = title_mapping.get(titles, titles)  # Default to the original value if not found

            # Generate a unique form number
            form_number = generate_unique_code()

            # Get the current timestamp
            submission_date = datetime.now().strftime('%Y-%m-%d')
            submit_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Check for empty values in mandatory fields
            mandatory_fields = {
                'titles': titles,
                'name': name,
                'email': email,
                'company_name': company_name,
                'country': country,
                'state': state,
                'city': city,
                'street_address': street_address,
                'street_address_2': street_address_2,
                'postal_code': postal_code,
                'phone_number': phone_number,
                'mobile_number': mobile_number,
                'gst_number': gst_number,
                'pan_number': pan_number
            }

            empty_fields = [field for field, value in mandatory_fields.items() if not value]
            if empty_fields:
                return f"The following fields are required: {', '.join(empty_fields)}"

            # Validate each field
            errors = []
            for field, pattern in validation_patterns.items():
                value = request.form.get(field)
                if not re.match(pattern, value):
                    errors.append(f"Invalid value for {field}")

            # Validate GST and PAN linkage
            extracted_pan = gst_number[2:12]
            if extracted_pan != pan_number:
                errors.append("GST and PAN number are not linked.")
                return render_template('formds.html', request_number=request_number, category=category, company_name=company_name, email=email, gst_number_error="GST and PAN number are not linked.")

            # Validate GST and PAN documents
            errors = []
            gst_document_error = ""
            pan_document_error = ""

            if not gst_document or not pan_document:
                if not gst_document:
                    gst_document_error = "GST document is required."
                    errors.append(gst_document_error)
                if not pan_document:
                    pan_document_error = "PAN document is required."
                    errors.append(pan_document_error)
            else:
                if gst_document.mimetype != 'application/pdf' or pan_document.mimetype != 'application/pdf':
                    if gst_document.mimetype != 'application/pdf':
                        gst_document_error = "GST document must be in PDF format."
                        errors.append(gst_document_error)
                    if pan_document.mimetype != 'application/pdf':
                        pan_document_error = "PAN document must be in PDF format."
                        errors.append(pan_document_error)
                if len(gst_document.read()) > 2 * 1024 * 1024 or len(pan_document.read()) > 2 * 1024 * 1024:
                    if len(gst_document.read()) > 2 * 1024 * 1024:
                        gst_document_error = "GST document must be less than 2MB in size."
                        errors.append(gst_document_error)
                    if len(pan_document.read()) > 2 * 1024 * 1024:
                        pan_document_error = "PAN document must be less than 2MB in size."
                        errors.append(pan_document_error)
                gst_document.seek(0)  # Reset file pointer after reading
                pan_document.seek(0)  # Reset file pointer after reading

            if errors:
                return render_template('formds.html', request_number=request_number, category=category, company_name=company_name, email=email, gst_document_error=gst_document_error, pan_document_error=pan_document_error)

            if errors:
                return ", ".join(errors)

            if country.upper() == "INDIA":
                country = "IN"

            # Map state to region code
            state_region_mapping = {
                "JAMMU AND KASHMIR": "01",
                "HIMACHAL PRADESH": "02",
                "PUNJAB": "03",
                "CHANDIGARH": "04",
                "UTTARAKHAND": "05",
                "HARYANA": "06",
                "DELHI": "07",
                "RAJASTHAN": "08",
                "UTTAR PRADESH": "09",
                "BIHAR": "10",
                "SIKKIM": "11",
                "ARUNACHAL PRADESH": "12",
                "NAGALAND": "13",
                "MANIPUR": "14",
                "MIZORAM": "15",
                "TRIPURA": "16",
                "MEGHALAYA": "17",
                "ASSAM": "18",
                "WEST BENGAL": "19",
                "JHARKHAND": "20",
                "ODISHA": "21",
                "CHHATTISGARH": "22",
                "MADHYA PRADESH": "23",
                "GUJARAT": "24",
                "DAMAN AND DIU": "25",
                "DADRA AND NAGAR HAV.": "26",
                "MAHARASHTRA": "27",
                "ANDHRA PRADESH": "28",
                "KARNATAKA": "29",
                "GOA": "30",
                "LAKSHADWEEP": "31",
                "KERALA": "32",
                "TAMIL NADU": "33",
                "PUDUCHERRY": "34",
                "ANDAMAN AND NICO.IN.": "35",
                "TELANGANA": "36",
                "ANDRAPRADESH": "37"
            }
            if category == "Export (ZEXP)":
                region = "00"
            else:
                region = state_region_mapping.get(state, '')

            # Email details
            sender_email = 'testit@sangamgroup.com'
            sender_password = 'Krishna@123'
            subject = 'Your Form Submission'
            body = f'Thank you for filling the details. Your form number is {form_number}.'

            print("Form Data Extracted Successfully")  # Debugging print statement

            # Attempt to send the email
            if send_email(sender_email, sender_password, email, subject, body):
                # If email is sent successfully, insert data into the database
                cursor = db.cursor()
                cursor.execute("""
                        INSERT INTO formsbyc (
                            titles, name, email, company_name, country,
                            state, city, street_address, street_address_2, street_address_3,
                            postal_code, phone_number, mobile_number, gst_number,
                            pan_number, region, category, form_number, request_number, submission_date, gst_document, pan_document, submit_timestamp
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                    titles, name, email, company_name, country,
                    state, city, street_address, street_address_2, street_address_3,
                    postal_code, phone_number, mobile_number, gst_number,
                    pan_number, region, category, form_number, request_number, submission_date, gst_document.read(),
                    pan_document.read(), submit_timestamp
                ))
                db.commit()
                cursor.close()

                print("Email Sent Successfully! Form Submitted.")  # Debugging print statement

                # flash("Email sent successfully! Form submitted.", "success")
                # Display the form number on the screen
                return f"Form submitted successfully. This is your form number: {form_number}"
            else:
                print("Failed to send email. Form not submitted.")  # Debugging print statement
                # flash("Failed to send email. Form not submitted.", "danger")
                return "Failed to send email. Form not submitted."

        except Exception as e:
            print("Error:", e)  # Debugging print statement
            traceback.print_exc()  # Print traceback for detailed error analysis
            return "An error occurred while processing form submission."
    else:
        return "Method not allowed"

@app.route('/submit_requestv/<request_number>', methods=['POST'])
def submit_requestv(request_number):
    if request.method == 'POST':
        try:
            # Check if the request_number already exists in the submitted forms table
            cursor = db.cursor()
            cursor.execute("SELECT * FROM formsbyv WHERE request_number = %s", (request_number,))
            existing_form = cursor.fetchone()
            cursor.close()

            if existing_form:
                return "Form has already been submitted for this request number."

            # Fetch the category from the database based on the request_number
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT category FROM vendorrequested WHERE request_number = %s", (request_number,))
            result = cursor.fetchone()
            cursor.close()

            if not result:
                return "Request number not found."

            category = result['category']

            # Extract form data
            titles = request.form.get('titles')
            name = request.form.get('name')
            email = request.form.get('email')
            company_name = request.form.get('company_name')
            country = request.form.get('country')
            state = request.form.get('state')
            city = request.form.get('city')
            street_address = request.form.get('street_address')
            street_address_2 = request.form.get('street_address_2')
            street_address_3 = request.form.get('street_address_3')
            postal_code = request.form.get('postal_code')
            phone_number = request.form.get('phone_number')
            mobile_number = request.form.get('mobile_number')
            mmse_type = request.form.get('mmse_type')
            certificate_date = request.form.get('certificate_date')
            bank_key = request.form.get('bank_key')
            bank_acc_no = request.form.get('bank_acc_no')
            account_holder_name = request.form.get('account_holder_name')
            gst_number = request.form.get('gst_number')
            gst_document = request.files.get('gst_document')
            pan_number = request.form.get('pan_number')
            pan_document = request.files.get('pan_document')

            # Map titles to their corresponding codes
            title_mapping = {
                "Ms.": "0001",
                "Mr.": "0002",
                "Company": "3000",
                "Mr. and Mrs": "4000",
                "M/S": "5000"
            }
            titles = title_mapping.get(titles, titles)  # Default to the original value if not found

            # Map titles to their corresponding codes
            mmse_mapping = {
                "Micro-Manufacturing": "A",
                "Small-Manufacturing": "B",
                "Medium-Manufacturing": "C",
                "Micro-Services": "D",
                "Small-Services": "E",
                "Medium-Services": "F",
                "Not Registered under MSMED": "NOR"
            }
            mmse_type = mmse_mapping.get(mmse_type, mmse_type)

            # Generate a unique form number
            form_number = generate_unique_code()

            # Get the current timestamp
            submission_date = datetime.now().strftime('%Y-%m-%d')
            submit_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Check for empty values in mandatory fields
            mandatory_fields = {
                'titles': titles,
                'name': name,
                'email': email,
                'company_name': company_name,
                'country': country,
                'state': state,
                'city': city,
                'street_address': street_address,
                'street_address_2': street_address_2,
                'postal_code': postal_code,
                'phone_number': phone_number,
                'mobile_number': mobile_number,
                'mmse_type': mmse_type,
                'certificate_date': certificate_date,
                'bank_key': bank_key,
                'bank_acc_no': bank_acc_no,
                'account_holder_name': account_holder_name,
                'pan_number': pan_number
            }

            empty_fields = [field for field, value in mandatory_fields.items() if not value]
            if empty_fields:
                return f"The following fields are required: {', '.join(empty_fields)}"

            # Validate each field
            errors = []
            for field, pattern in validation_patterns_vendor.items():
                value = request.form.get(field)
                if not re.match(pattern, value):
                    errors.append(f"Invalid value for {field}")

            # Validate GST and PAN linkage
            if gst_number:  # Only validate if GST number is provided
                extracted_pan = gst_number[2:12]
                if extracted_pan != pan_number:
                    errors.append("GST and PAN number are not linked.")
                    return render_template('formvds.html', request_number=request_number, category=category,
                                           company_name=company_name, email=email,
                                           gst_number_error="GST and PAN number are not linked.")

            # Validate GST and PAN documents
            errors = []
            gst_document_error = ""
            pan_document_error = ""

            if not pan_document:
                pan_document_error = "PAN document is required."
                errors.append(pan_document_error)

            if gst_number:  # Only validate GST document if GST number is provided
                if not gst_document:
                    gst_document_error = "GST document is required."
                    errors.append(gst_document_error)
                else:
                    if gst_document.mimetype != 'application/pdf':
                        gst_document_error = "GST document must be in PDF format."
                        errors.append(gst_document_error)
                    if len(gst_document.read()) > 2 * 1024 * 1024:
                        gst_document_error = "GST document must be less than 2MB in size."
                        errors.append(gst_document_error)
                    gst_document.seek(0)  # Reset file pointer after reading

            if pan_document:
                if pan_document.mimetype != 'application/pdf':
                    pan_document_error = "PAN document must be in PDF format."
                    errors.append(pan_document_error)
                if len(pan_document.read()) > 2 * 1024 * 1024:
                    pan_document_error = "PAN document must be less than 2MB in size."
                    errors.append(pan_document_error)
                pan_document.seek(0)  # Reset file pointer after reading

            if errors:
                return render_template('formvds.html', request_number=request_number, category=category, company_name=company_name, email=email, gst_document_error=gst_document_error, pan_document_error=pan_document_error)

            if errors:
                return ", ".join(errors)

            if country.upper() == "INDIA":
                country = "IN"

            # Map state to region code
            state_region_mapping = {
                "JAMMU AND KASHMIR": "01",
                "HIMACHAL PRADESH": "02",
                "PUNJAB": "03",
                "CHANDIGARH": "04",
                "UTTARAKHAND": "05",
                "HARYANA": "06",
                "DELHI": "07",
                "RAJASTHAN": "08",
                "UTTAR PRADESH": "09",
                "BIHAR": "10",
                "SIKKIM": "11",
                "ARUNACHAL PRADESH": "12",
                "NAGALAND": "13",
                "MANIPUR": "14",
                "MIZORAM": "15",
                "TRIPURA": "16",
                "MEGHALAYA": "17",
                "ASSAM": "18",
                "WEST BENGAL": "19",
                "JHARKHAND": "20",
                "ODISHA": "21",
                "CHHATTISGARH": "22",
                "MADHYA PRADESH": "23",
                "GUJARAT": "24",
                "DAMAN AND DIU": "25",
                "DADRA AND NAGAR HAV.": "26",
                "MAHARASHTRA": "27",
                "ANDHRA PRADESH": "28",
                "KARNATAKA": "29",
                "GOA": "30",
                "LAKSHADWEEP": "31",
                "KERALA": "32",
                "TAMIL NADU": "33",
                "PUDUCHERRY": "34",
                "ANDAMAN AND NICO.IN.": "35",
                "TELANGANA": "36",
                "ANDRAPRADESH": "37"
            }
            if category == "Import (VIMP)":
                region = "00"
            else:
                region = state_region_mapping.get(state, '')

            # Email details
            sender_email = 'testit@sangamgroup.com'
            sender_password = 'Krishna@123'
            subject = 'Your Form Submission'
            body = f'Thank you for filling the details. Your form number is {form_number}.'

            print("Form Data Extracted Successfully")  # Debugging print statement

            # Attempt to send the email
            if send_email(sender_email, sender_password, email, subject, body):
                # If email is sent successfully, insert data into the database
                cursor = db.cursor()
                cursor.execute("""
                        INSERT INTO formsbyv (
                            titles, name, email, company_name, country,
                            state, city, street_address, street_address_2, street_address_3,
                            postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name, gst_number,
                            pan_number, region, category, form_number, request_number, submission_date, gst_document, pan_document, submit_timestamp
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                    titles, name, email, company_name, country,
                    state, city, street_address, street_address_2, street_address_3,
                    postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name, gst_number,
                    pan_number, region, category, form_number, request_number, submission_date, gst_document.read(),
                    pan_document.read(), submit_timestamp
                ))
                db.commit()
                cursor.close()

                print("Email Sent Successfully! Form Submitted.")  # Debugging print statement

                # flash("Email sent successfully! Form submitted.", "success")
                # Display the form number on the screen
                return f"Form submitted successfully. This is your form number: {form_number}"
            else:
                print("Failed to send email. Form not submitted.")  # Debugging print statement
                # flash("Failed to send email. Form not submitted.", "danger")
                return "Failed to send email. Form not submitted."

        except Exception as e:
            print("Error:", e)  # Debugging print statement
            traceback.print_exc()  # Print traceback for detailed error analysis
            return "An error occurred while processing form submission."
    else:
        return "Method not allowed"

@app.route('/forme/<request_number>')
def forme(request_number):
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT company_name, email, category FROM customerrequested WHERE request_number = %s", (request_number,))
    result = cursor.fetchone()
    cursor.close()
    if result:
        company_name = result['company_name']
        email = result['email']
        category = result['category']
    else:
        company_name = ""
        email = ""
        category = ""
    return render_template('forme.html', request_number=request_number, category=category, company_name=company_name, email=email)


@app.route('/formve/<request_number>')
def formve(request_number):
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT company_name, email, category FROM vendorrequested WHERE request_number = %s", (request_number,))
    result = cursor.fetchone()
    cursor.close()
    if result:
        company_name = result['company_name']
        email = result['email']
        category = result['category']
    else:
        company_name = ""
        email = ""
        category = ""
    return render_template('formve.html', request_number=request_number, category=category, company_name=company_name, email=email)

@app.route('/submit_requeste/<request_number>', methods=['POST'])
def submit_requeste(request_number):
    if request.method == 'POST':
        try:
            # Check if the request_number already exists in the submitted forms table
            cursor = db.cursor()
            cursor.execute("SELECT * FROM formsbyc WHERE request_number = %s", (request_number,))
            existing_form = cursor.fetchone()
            cursor.close()

            if existing_form:
                return "Form has already been submitted for this request number."

            # Fetch the category from the database based on the request_number
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT category FROM customerrequested WHERE request_number = %s", (request_number,))
            result = cursor.fetchone()
            cursor.close()

            if not result:
                return "Request number not found."

            category = result['category']

            # Extract form data
            titles = request.form.get('titles')
            name = request.form.get('name')
            email = request.form.get('email')
            company_name = request.form.get('company_name')
            country = request.form.get('country')
            state = request.form.get('state')
            city = request.form.get('city')
            street_address = request.form.get('street_address')
            street_address_2 = request.form.get('street_address_2')
            street_address_3 = request.form.get('street_address_3')
            postal_code = request.form.get('postal_code')
            phone_number = request.form.get('phone_number')
            mobile_number = request.form.get('mobile_number')

            # Map titles to their corresponding codes
            title_mapping = {
                "Ms.": "0001",
                "Mr.": "0002",
                "Company": "3000",
                "Mr. and Mrs": "4000",
                "M/S": "5000"
            }
            titles = title_mapping.get(titles, titles)  # Default to the original value if not found

            country_mapping = {
                "ANDORRA": "AD",
                "UTD.ARAB EMIR.": "AE",
                "AFGHANISTAN": "AF",
                "ANTIGUA/BARBUDA": "AG",
                "ANGUILLA": "AI",
                "ALBANIA": "AL",
                "ARMENIA": "AM",
                "ANGOLA": "AO",
                "ANTARCTICA": "AQ",
                "ARGENTINA": "AR",
                "SAMOA, AMERICA": "AS",
                "AUSTRIA": "AT",
                "AUSTRALIA": "AU",
                "ARUBA": "AW",
                "ALAND ISLANDS": "AX",
                "AZERBAIJAN": "AZ",
                "BOSNIA-HERZ.": "BA",
                "BARBADOS": "BB",
                "BANGLADESH": "BD",
                "BELGIUM": "BE",
                "BURKINA FASO": "BF",
                "BULGARIA": "BG",
                "BAHRAIN": "BH",
                "BURUNDI": "BI",
                "BENIN": "BJ",
                "BLUE": "BL",
                "BERMUDA": "BM",
                "BRUNEI DARUSS.": "BN",
                "BOLIVIA": "BO",
                "BONAIRE, SABA": "BQ",
                "BRAZIL": "BR",
                "BAHAMAS": "BS",
                "BHUTAN": "BT",
                "BOUVET ISLANDS": "BV",
                "BOTSWANA": "BW",
                "BELARUS": "BY",
                "BELIZE": "BZ",
                "CANADA": "CA",
                "KEELING ISLANDS": "CC",
                "DEM. REP. CONGO": "CD",
                "CAR": "CF",
                "REP.OF CONGO": "CG",
                "SWITZERLAND": "CH",
                "COTE D'IVOIRE": "CI",
                "COOK ISLANDS": "CK",
                "CHILE": "CL",
                "CAMEROON": "CM",
                "CHINA": "CN",
                "COLOMBIA": "CO",
                "COSTA RICA": "CR",
                "CUBA": "CU",
                "CAPE VERDE": "CV",
                "CURACAO": "CW",
                "CHRISTMAS ISLND": "CX",
                "CYPRUS": "CY",
                "CZECH REPUBLIC": "CZ",
                "GERMANY": "DE",
                "DJIBOUTI": "DJ",
                "DENMARK": "DK",
                "DOMINICA": "DM",
                "DOMINICAN REP.": "DO",
                "ALGERIA": "DZ",
                "ECUADOR": "EC",
                "ESTONIA": "EE",
                "EGYPT": "EG",
                "WEST SAHARA": "EH",
                "ERITREA": "ER",
                "SPAIN": "ES",
                "ETHIOPIA": "ET",
                "EUROPEAN UNION": "EU",
                "FINLAND": "FI",
                "FIJI": "FJ",
                "FALKLAND ISLNDS": "FK",
                "MICRONESIA": "FM",
                "FAROE ISLANDS": "FO",
                "FRANCE": "FR",
                "GABON": "GA",
                "UNITED KINGDOM": "GB",
                "GRENADA": "GD",
                "GEORGIA": "GE",
                "FRENCH GUAYANA": "GF",
                "GUERNSEY": "GG",
                "GHANA": "GH",
                "GIBRALTAR": "GI",
                "GREENLAND": "GL",
                "GAMBIA": "GM",
                "GUINEA": "GN",
                "GUADELOUPE": "GP",
                "EQUATORIAL GUIN": "GQ",
                "GREECE": "GR",
                "S. SANDWICH INS": "GS",
                "GUATEMALA": "GT",
                "GUAM": "GU",
                "GUINEA-BISSAU": "GW",
                "GUYANA": "GY",
                "HONG KONG": "HK",
                "HEARD/MCDON.ISL": "HM",
                "HONDURAS": "HN",
                "CROATIA": "HR",
                "HAITI": "HT",
                "HUNGARY": "HU",
                "INDONESIA": "ID",
                "IRELAND": "IE",
                "ISRAEL": "IL",
                "ISLE OF MAN": "IM",
                "INDIA": "IN",
                "BRIT.IND.OC.TER": "IO",
                "IRAQ": "IQ",
                "IRAN": "IR",
                "ICELAND": "IS",
                "ITALY": "IT",
                "JERSEY": "JE",
                "JAMAICA": "JM",
                "JORDAN": "JO",
                "JAPAN": "JP",
                "KENYA": "KE",
                "KYRGYZSTAN": "KG",
                "CAMBODIA": "KH",
                "KIRIBATI": "KI",
                "COMOROS": "KM",
                "ST KITTS&NEVIS": "KN",
                "NORTH KOREA": "KP",
                "SOUTH KOREA": "KR",
                "KUWAIT": "KW",
                "CAYMAN ISLANDS": "KY",
                "KAZAKHSTAN": "KZ",
                "LAOS": "LA",
                "LEBANON": "LB",
                "ST. LUCIA": "LC",
                "LIECHTENSTEIN": "LI",
                "SRI LANKA": "LK",
                "LIBERIA": "LR",
                "LESOTHO": "LS",
                "LITHUANIA": "LT",
                "LUXEMBOURG": "LU",
                "LATVIA": "LV",
                "LIBYA": "LY",
                "MOROCCO": "MA",
                "MONACO": "MC",
                "MOLDOVA": "MD",
                "MADAGASCAR": "MG",
                "MARSHALL ISLNDS": "MH",
                "MACEDONIA": "MK",
                "MALI": "ML",
                "BURMA": "MM",
                "MONGOLIA": "MN",
                "MACAU": "MO",
                "N.MARIANA ISLND": "MP",
                "MARTINIQUE": "MQ",
                "MAURITANIA": "MR",
                "MONTSERRAT": "MS",
                "MALTA": "MT",
                "MAURITIUS": "MU",
                "MALDIVES": "MV",
                "MALAWI": "MW",
                "MEXICO": "MX",
                "MALAYSIA": "MY",
                "MOZAMBIQUE": "MZ",
                "NAMIBIA": "NA",
                "NEW CALEDONIA": "NC",
                "NIGER": "NE",
                "NORFOLK ISLANDS": "NF",
                "NIGERIA": "NG",
                "NICARAGUA": "NI",
                "NETHERLANDS": "NL",
                "NORWAY": "NO",
                "NEPAL": "NP",
                "NAURU": "NR",
                "NATO": "NT",
                "NIUE": "NU",
                "NEW ZEALAND": "NZ",
                "OMAN": "OM",
                "ORANGE": "OR",
                "PANAMA": "PA",
                "PERU": "PE",
                "FRENC.POLYNESIA": "PF",
                "PAP. NEW GUINEA": "PG",
                "PHILIPPINES": "PH",
                "PAKISTAN": "PK",
                "POLAND": "PL",
                "ST.PIER,MIQUEL.": "PM",
                "PITCAIRN ISLNDS": "PN",
                "PUERTO RICO": "PR",
                "PALESTINE": "PS",
                "PORTUGAL": "PT",
                "PALAU": "PW",
                "PARAGUAY": "PY",
                "QATAR": "QA",
                "REUNION": "RE",
                "ROMANIA": "RO",
                "RUSSIAN FED.": "RU",
                "RWANDA": "RW",
                "SAUDI ARABIA": "SA",
                "SOLOMON ISLANDS": "SB",
                "SEYCHELLES": "SC",
                "SUDAN": "SD",
                "SWEDEN": "SE",
                "SINGAPORE": "SG",
                "SAINT HELENA": "SH",
                "SLOVENIA": "SI",
                "SVALBARD": "SJ",
                "SLOVAKIA": "SK",
                "SIERRA LEONE": "SL",
                "SAN MARINO": "SM",
                "SENEGAL": "SN",
                "SOMALIA": "SO",
                "SURINAME": "SR",
                "SOUTH SUDAN": "SS",
                "S.TOME,PRINCIPE": "ST",
                "EL SALVADOR": "SV",
                "SINT MAARTEN": "SX",
                "SYRIA": "SY",
                "SWAZILAND": "SZ",
                "TURKSH CAICOSIN": "TC",
                "CHAD": "TD",
                "FRENCH S.TERRIT": "TF",
                "TOGO": "TG",
                "THAILAND": "TH",
                "TAJIKISTAN": "TJ",
                "TOKELAU ISLANDS": "TK",
                "EAST TIMOR": "TL",
                "TURKMENISTAN": "TM",
                "TUNISIA": "TN",
                "TONGA": "TO",
                "TURKEY": "TR",
                "TRINIDAD,TOBAGO": "TT",
                "TUVALU": "TV",
                "TAIWAN": "TW",
                "TANZANIA": "TZ",
                "UKRAINE": "UA",
                "UGANDA": "UG",
                "MINOR OUTL.ISL.": "UM",
                "UNITED NATIONS": "UN",
                "USA": "US",
                "URUGUAY": "UY",
                "UZBEKISTAN": "UZ",
                "VATICAN CITY": "VA",
                "ST. VINCENT": "VC",
                "VENEZUELA": "VE",
                "BRIT.VIRGIN IS.": "VG",
                "US VIRGIN ISL.": "VI",
                "VIETNAM": "VN",
                "VANUATU": "VU",
                "WALLIS,FUTUNA": "WF",
                "SAMOA": "WS",
                "YEMEN": "YE",
                "MAYOTTE": "YT",
                "SOUTH AFRICA": "ZA",
                "ZAMBIA": "ZM",
                "ZIMBABWE": "ZW"
            }

            # Map country to its corresponding code
            country_code = country_mapping.get(country, country)  # Default to the original value if not found

            # Generate a unique form number
            form_number = generate_unique_code()

            # Get the current timestamp
            submission_date = datetime.now().strftime('%Y-%m-%d')
            submit_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Check for empty values in mandatory fields
            mandatory_fields = {
                'titles': titles,
                'name': name,
                'email': email,
                'company_name': company_name,
                'country': country,
                'state': state,
                'city': city,
                'street_address': street_address,
                'street_address_2': street_address_2,
                'postal_code': postal_code,
                'phone_number': phone_number,
                'mobile_number': mobile_number
            }

            empty_fields = [field for field, value in mandatory_fields.items() if not value]
            if empty_fields:
                return f"The following fields are required: {', '.join(empty_fields)}"

            # Validate each field
            errors = []
            for field, pattern in validation_patterns_for_e.items():
                value = request.form.get(field)
                if not re.match(pattern, value):
                    errors.append(f"Invalid value for {field}")

            if errors:
                return ", ".join(errors)

            # Email details
            sender_email = 'testit@sangamgroup.com'
            sender_password = 'Krishna@123'
            subject = 'Your Form Submission'
            body = f'Thank you for your submission. Your form number is {form_number}.'

            print("Form Data Extracted Successfully")  # Debugging print statement

            # Attempt to send the email
            if send_email(sender_email, sender_password, email, subject, body):
                # If email is sent successfully, insert data into the database
                region = "00"  # Set region to "00"
                cursor = db.cursor()
                cursor.execute("""
                        INSERT INTO formsbyc (
                            titles, name, email, company_name, country,
                            state, city, street_address, street_address_2, street_address_3,
                            postal_code, phone_number, mobile_number,
                            region, category, form_number, request_number, submission_date, submit_timestamp
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                    titles, name, email, company_name, country_code,
                    state, city, street_address, street_address_2, street_address_3,
                    postal_code, phone_number, mobile_number, region, category, form_number, request_number, submission_date, submit_timestamp
                ))
                db.commit()
                cursor.close()

                print("Email Sent Successfully! Form Submitted.")  # Debugging print statement

                # flash("Email sent successfully! Form submitted.", "success")
                # Display the form number on the screen
                return f"Form submitted successfully. This is your form number: {form_number}"
            else:
                print("Failed to send email. Form not submitted.")  # Debugging print statement
                # flash("Failed to send email. Form not submitted.", "danger")
                return "Failed to send email. Form not submitted."

        except Exception as e:
            print("Error:", e)  # Debugging print statement
            traceback.print_exc()  # Print traceback for detailed error analysis
            return "An error occurred while processing form submission."
    else:
        return "Method not allowed"

@app.route('/submit_requestve/<request_number>', methods=['POST'])
def submit_requestve(request_number):
    if request.method == 'POST':
        try:
            # Check if the request_number already exists in the submitted forms table
            cursor = db.cursor()
            cursor.execute("SELECT * FROM formsbyv WHERE request_number = %s", (request_number,))
            existing_form = cursor.fetchone()
            cursor.close()

            if existing_form:
                return "Form has already been submitted for this request number."

            # Fetch the category from the database based on the request_number
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT category FROM vendorrequested WHERE request_number = %s", (request_number,))
            result = cursor.fetchone()
            cursor.close()

            if not result:
                return "Request number not found."

            category = result['category']

            # Extract form data
            titles = request.form.get('titles')
            name = request.form.get('name')
            email = request.form.get('email')
            company_name = request.form.get('company_name')
            country = request.form.get('country')
            state = request.form.get('state')
            city = request.form.get('city')
            street_address = request.form.get('street_address')
            street_address_2 = request.form.get('street_address_2')
            street_address_3 = request.form.get('street_address_3')
            postal_code = request.form.get('postal_code')
            phone_number = request.form.get('phone_number')
            mobile_number = request.form.get('mobile_number')
            mmse_type = request.form.get('mmse_type')
            certificate_date = request.form.get('certificate_date')
            bank_key = request.form.get('bank_key')
            bank_acc_no = request.form.get('bank_acc_no')
            account_holder_name = request.form.get('account_holder_name')

            # Map titles to their corresponding codes
            title_mapping = {
                "Ms.": "0001",
                "Mr.": "0002",
                "Company": "3000",
                "Mr. and Mrs": "4000",
                "M/S": "5000"
            }
            titles = title_mapping.get(titles, titles)  # Default to the original value if not found

            # Map titles to their corresponding codes
            mmse_mapping = {
                "A": "Micro-Manufacturing",
                "B": "Small-Manufacturing",
                "C": "Medium-Manufacturing",
                "D": "Micro-Services",
                "E": "Small-Services",
                "F": "Medium-Services",
                "NOR": "Not Registered under MSMED"
            }
            mmse_type = mmse_mapping.get(mmse_type, mmse_type)

            country_mapping = {
                "ANDORRA": "AD",
                "UTD.ARAB EMIR.": "AE",
                "AFGHANISTAN": "AF",
                "ANTIGUA/BARBUDA": "AG",
                "ANGUILLA": "AI",
                "ALBANIA": "AL",
                "ARMENIA": "AM",
                "ANGOLA": "AO",
                "ANTARCTICA": "AQ",
                "ARGENTINA": "AR",
                "SAMOA, AMERICA": "AS",
                "AUSTRIA": "AT",
                "AUSTRALIA": "AU",
                "ARUBA": "AW",
                "ALAND ISLANDS": "AX",
                "AZERBAIJAN": "AZ",
                "BOSNIA-HERZ.": "BA",
                "BARBADOS": "BB",
                "BANGLADESH": "BD",
                "BELGIUM": "BE",
                "BURKINA FASO": "BF",
                "BULGARIA": "BG",
                "BAHRAIN": "BH",
                "BURUNDI": "BI",
                "BENIN": "BJ",
                "BLUE": "BL",
                "BERMUDA": "BM",
                "BRUNEI DARUSS.": "BN",
                "BOLIVIA": "BO",
                "BONAIRE, SABA": "BQ",
                "BRAZIL": "BR",
                "BAHAMAS": "BS",
                "BHUTAN": "BT",
                "BOUVET ISLANDS": "BV",
                "BOTSWANA": "BW",
                "BELARUS": "BY",
                "BELIZE": "BZ",
                "CANADA": "CA",
                "KEELING ISLANDS": "CC",
                "DEM. REP. CONGO": "CD",
                "CAR": "CF",
                "REP.OF CONGO": "CG",
                "SWITZERLAND": "CH",
                "COTE D'IVOIRE": "CI",
                "COOK ISLANDS": "CK",
                "CHILE": "CL",
                "CAMEROON": "CM",
                "CHINA": "CN",
                "COLOMBIA": "CO",
                "COSTA RICA": "CR",
                "CUBA": "CU",
                "CAPE VERDE": "CV",
                "CURACAO": "CW",
                "CHRISTMAS ISLND": "CX",
                "CYPRUS": "CY",
                "CZECH REPUBLIC": "CZ",
                "GERMANY": "DE",
                "DJIBOUTI": "DJ",
                "DENMARK": "DK",
                "DOMINICA": "DM",
                "DOMINICAN REP.": "DO",
                "ALGERIA": "DZ",
                "ECUADOR": "EC",
                "ESTONIA": "EE",
                "EGYPT": "EG",
                "WEST SAHARA": "EH",
                "ERITREA": "ER",
                "SPAIN": "ES",
                "ETHIOPIA": "ET",
                "EUROPEAN UNION": "EU",
                "FINLAND": "FI",
                "FIJI": "FJ",
                "FALKLAND ISLNDS": "FK",
                "MICRONESIA": "FM",
                "FAROE ISLANDS": "FO",
                "FRANCE": "FR",
                "GABON": "GA",
                "UNITED KINGDOM": "GB",
                "GRENADA": "GD",
                "GEORGIA": "GE",
                "FRENCH GUAYANA": "GF",
                "GUERNSEY": "GG",
                "GHANA": "GH",
                "GIBRALTAR": "GI",
                "GREENLAND": "GL",
                "GAMBIA": "GM",
                "GUINEA": "GN",
                "GUADELOUPE": "GP",
                "EQUATORIAL GUIN": "GQ",
                "GREECE": "GR",
                "S. SANDWICH INS": "GS",
                "GUATEMALA": "GT",
                "GUAM": "GU",
                "GUINEA-BISSAU": "GW",
                "GUYANA": "GY",
                "HONG KONG": "HK",
                "HEARD/MCDON.ISL": "HM",
                "HONDURAS": "HN",
                "CROATIA": "HR",
                "HAITI": "HT",
                "HUNGARY": "HU",
                "INDONESIA": "ID",
                "IRELAND": "IE",
                "ISRAEL": "IL",
                "ISLE OF MAN": "IM",
                "INDIA": "IN",
                "BRIT.IND.OC.TER": "IO",
                "IRAQ": "IQ",
                "IRAN": "IR",
                "ICELAND": "IS",
                "ITALY": "IT",
                "JERSEY": "JE",
                "JAMAICA": "JM",
                "JORDAN": "JO",
                "JAPAN": "JP",
                "KENYA": "KE",
                "KYRGYZSTAN": "KG",
                "CAMBODIA": "KH",
                "KIRIBATI": "KI",
                "COMOROS": "KM",
                "ST KITTS&NEVIS": "KN",
                "NORTH KOREA": "KP",
                "SOUTH KOREA": "KR",
                "KUWAIT": "KW",
                "CAYMAN ISLANDS": "KY",
                "KAZAKHSTAN": "KZ",
                "LAOS": "LA",
                "LEBANON": "LB",
                "ST. LUCIA": "LC",
                "LIECHTENSTEIN": "LI",
                "SRI LANKA": "LK",
                "LIBERIA": "LR",
                "LESOTHO": "LS",
                "LITHUANIA": "LT",
                "LUXEMBOURG": "LU",
                "LATVIA": "LV",
                "LIBYA": "LY",
                "MOROCCO": "MA",
                "MONACO": "MC",
                "MOLDOVA": "MD",
                "MADAGASCAR": "MG",
                "MARSHALL ISLNDS": "MH",
                "MACEDONIA": "MK",
                "MALI": "ML",
                "BURMA": "MM",
                "MONGOLIA": "MN",
                "MACAU": "MO",
                "N.MARIANA ISLND": "MP",
                "MARTINIQUE": "MQ",
                "MAURITANIA": "MR",
                "MONTSERRAT": "MS",
                "MALTA": "MT",
                "MAURITIUS": "MU",
                "MALDIVES": "MV",
                "MALAWI": "MW",
                "MEXICO": "MX",
                "MALAYSIA": "MY",
                "MOZAMBIQUE": "MZ",
                "NAMIBIA": "NA",
                "NEW CALEDONIA": "NC",
                "NIGER": "NE",
                "NORFOLK ISLANDS": "NF",
                "NIGERIA": "NG",
                "NICARAGUA": "NI",
                "NETHERLANDS": "NL",
                "NORWAY": "NO",
                "NEPAL": "NP",
                "NAURU": "NR",
                "NATO": "NT",
                "NIUE": "NU",
                "NEW ZEALAND": "NZ",
                "OMAN": "OM",
                "ORANGE": "OR",
                "PANAMA": "PA",
                "PERU": "PE",
                "FRENC.POLYNESIA": "PF",
                "PAP. NEW GUINEA": "PG",
                "PHILIPPINES": "PH",
                "PAKISTAN": "PK",
                "POLAND": "PL",
                "ST.PIER,MIQUEL.": "PM",
                "PITCAIRN ISLNDS": "PN",
                "PUERTO RICO": "PR",
                "PALESTINE": "PS",
                "PORTUGAL": "PT",
                "PALAU": "PW",
                "PARAGUAY": "PY",
                "QATAR": "QA",
                "REUNION": "RE",
                "ROMANIA": "RO",
                "RUSSIAN FED.": "RU",
                "RWANDA": "RW",
                "SAUDI ARABIA": "SA",
                "SOLOMON ISLANDS": "SB",
                "SEYCHELLES": "SC",
                "SUDAN": "SD",
                "SWEDEN": "SE",
                "SINGAPORE": "SG",
                "SAINT HELENA": "SH",
                "SLOVENIA": "SI",
                "SVALBARD": "SJ",
                "SLOVAKIA": "SK",
                "SIERRA LEONE": "SL",
                "SAN MARINO": "SM",
                "SENEGAL": "SN",
                "SOMALIA": "SO",
                "SURINAME": "SR",
                "SOUTH SUDAN": "SS",
                "S.TOME,PRINCIPE": "ST",
                "EL SALVADOR": "SV",
                "SINT MAARTEN": "SX",
                "SYRIA": "SY",
                "SWAZILAND": "SZ",
                "TURKSH CAICOSIN": "TC",
                "CHAD": "TD",
                "FRENCH S.TERRIT": "TF",
                "TOGO": "TG",
                "THAILAND": "TH",
                "TAJIKISTAN": "TJ",
                "TOKELAU ISLANDS": "TK",
                "EAST TIMOR": "TL",
                "TURKMENISTAN": "TM",
                "TUNISIA": "TN",
                "TONGA": "TO",
                "TURKEY": "TR",
                "TRINIDAD,TOBAGO": "TT",
                "TUVALU": "TV",
                "TAIWAN": "TW",
                "TANZANIA": "TZ",
                "UKRAINE": "UA",
                "UGANDA": "UG",
                "MINOR OUTL.ISL.": "UM",
                "UNITED NATIONS": "UN",
                "USA": "US",
                "URUGUAY": "UY",
                "UZBEKISTAN": "UZ",
                "VATICAN CITY": "VA",
                "ST. VINCENT": "VC",
                "VENEZUELA": "VE",
                "BRIT.VIRGIN IS.": "VG",
                "US VIRGIN ISL.": "VI",
                "VIETNAM": "VN",
                "VANUATU": "VU",
                "WALLIS,FUTUNA": "WF",
                "SAMOA": "WS",
                "YEMEN": "YE",
                "MAYOTTE": "YT",
                "SOUTH AFRICA": "ZA",
                "ZAMBIA": "ZM",
                "ZIMBABWE": "ZW"
            }

            # Map country to its corresponding code
            country_code = country_mapping.get(country, country)  # Default to the original value if not found

            # Generate a unique form number
            form_number = generate_unique_code()

            # Get the current timestamp
            submission_date = datetime.now().strftime('%Y-%m-%d')
            submit_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Check for empty values in mandatory fields
            mandatory_fields = {
                'titles': titles,
                'name': name,
                'email': email,
                'company_name': company_name,
                'country': country,
                'state': state,
                'city': city,
                'street_address': street_address,
                'street_address_2': street_address_2,
                'postal_code': postal_code,
                'phone_number': phone_number,
                'mobile_number': mobile_number,
                'mmse_type': mmse_type,
                'certificate_date': certificate_date,
                'bank_key': bank_key,
                'bank_acc_no': bank_acc_no,
                'account_holder_name': account_holder_name,
            }

            empty_fields = [field for field, value in mandatory_fields.items() if not value]
            if empty_fields:
                return f"The following fields are required: {', '.join(empty_fields)}"

            # Validate each field
            errors = []
            for field, pattern in validation_patterns_for_i.items():
                value = request.form.get(field)
                if not re.match(pattern, value):
                    errors.append(f"Invalid value for {field}")

            if errors:
                return ", ".join(errors)

            # Email details
            sender_email = 'testit@sangamgroup.com'
            sender_password = 'Krishna@123'
            subject = 'Your Form Submission'
            body = f'Thank you for your submission. Your form number is {form_number}.'

            print("Form Data Extracted Successfully")  # Debugging print statement

            # Attempt to send the email
            if send_email(sender_email, sender_password, email, subject, body):
                # If email is sent successfully, insert data into the database
                region = "00"  # Set region to "00"
                cursor = db.cursor()
                cursor.execute("""
                        INSERT INTO formsbyv (
                            titles, name, email, company_name, country,
                            state, city, street_address, street_address_2, street_address_3,
                            postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name,
                            region, category, form_number, request_number, submission_date, submit_timestamp
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                    titles, name, email, company_name, country_code,
                    state, city, street_address, street_address_2, street_address_3,
                    postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name,
                    region, category, form_number, request_number, submission_date, submit_timestamp
                ))
                db.commit()
                cursor.close()

                print("Email Sent Successfully! Form Submitted.")  # Debugging print statement

                # flash("Email sent successfully! Form submitted.", "success")
                # Display the form number on the screen
                return f"Form submitted successfully. This is your form number: {form_number}"
            else:
                print("Failed to send email. Form not submitted.")  # Debugging print statement
                # flash("Failed to send email. Form not submitted.", "danger")
                return "Failed to send email. Form not submitted."

        except Exception as e:
            print("Error:", e)  # Debugging print statement
            traceback.print_exc()  # Print traceback for detailed error analysis
            return "An error occurred while processing form submission."
    else:
        return "Method not allowed"

# Function to get a cursor from the database
def get_cursor():
    return db.cursor(dictionary=True)

@app.route('/view_gst/<form_number>')
def view_gst(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT gst_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'gst_document' in result and result['gst_document']:
            pdf_data = result['gst_document']
            encoded_pdf = base64.b64encode(pdf_data).decode('utf-8')
            return encoded_pdf  # Return base64 encoded PDF content

        else:
            return "GST document not found or path is incorrect.", 404

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while processing GST document.", 500

    except Exception as e:
        print("Error:", e)
        return "An error occurred while processing GST document.", 500

    finally:
        cursor.close()

@app.route('/viewv_gst/<form_number>')
def viewv_gst(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT gst_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'gst_document' in result and result['gst_document']:
            pdf_data = result['gst_document']
            encoded_pdf = base64.b64encode(pdf_data).decode('utf-8')
            return encoded_pdf  # Return base64 encoded PDF content

        else:
            return "GST document not found or path is incorrect.", 404

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while processing GST document.", 500

    except Exception as e:
        print("Error:", e)
        return "An error occurred while processing GST document.", 500

    finally:
        cursor.close()

@app.route('/view_pan/<form_number>')
def view_pan(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT pan_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'pan_document' in result and result['pan_document']:
            pdf_data = result['pan_document']
            encoded_pdf = base64.b64encode(pdf_data).decode('utf-8')
            return encoded_pdf  # Return base64 encoded PDF content

        else:
            return "PAN document not found or path is incorrect.", 404

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while processing PAN document.", 500

    except Exception as e:
        print("Error:", e)
        return "An error occurred while processing PAN document.", 500

    finally:
        cursor.close()

@app.route('/viewv_pan/<form_number>')
def viewv_pan(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT pan_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'pan_document' in result and result['pan_document']:
            pdf_data = result['pan_document']
            encoded_pdf = base64.b64encode(pdf_data).decode('utf-8')
            return encoded_pdf  # Return base64 encoded PDF content

        else:
            return "PAN document not found or path is incorrect.", 404

    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return "An error occurred while processing PAN document.", 500

    except Exception as e:
        print("Error:", e)
        return "An error occurred while processing PAN document.", 500

    finally:
        cursor.close()

@app.route('/download_gst/<form_number>')
def download_gst(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT gst_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'gst_document' in result and result['gst_document']:
            pdf_data = result['gst_document']
            response = make_response(pdf_data)
            response.headers.set('Content-Type', 'application/pdf')
            response.headers.set('Content-Disposition', 'attachment', filename=f"GST_Document_{form_number}.pdf")
            return response
        else:
            abort(404, "GST document not found or path is incorrect.")
    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        abort(500, "An error occurred while processing GST document.")
    except Exception as e:
        print("Error:", e)
        abort(500, "An error occurred while processing GST document.")
    finally:
        cursor.close()

@app.route('/downloadv_gst/<form_number>')
def downloadv_gst(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT gst_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'gst_document' in result and result['gst_document']:
            pdf_data = result['gst_document']
            response = make_response(pdf_data)
            response.headers.set('Content-Type', 'application/pdf')
            response.headers.set('Content-Disposition', 'attachment', filename=f"GST_Document_{form_number}.pdf")
            return response
        else:
            abort(404, "GST document not found or path is incorrect.")
    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        abort(500, "An error occurred while processing GST document.")
    except Exception as e:
        print("Error:", e)
        abort(500, "An error occurred while processing GST document.")
    finally:
        cursor.close()

@app.route('/download_pan/<form_number>')
def download_pan(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT pan_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'pan_document' in result and result['pan_document']:
            pdf_data = result['pan_document']
            response = make_response(pdf_data)
            response.headers.set('Content-Type', 'application/pdf')
            response.headers.set('Content-Disposition', 'attachment', filename=f"PAN_Document_{form_number}.pdf")
            return response
        else:
            abort(404, "PAN document not found or path is incorrect.")
    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        abort(500, "An error occurred while processing PAN document.")
    except Exception as e:
        print("Error:", e)
        abort(500, "An error occurred while processing PAN document.")
    finally:
        cursor.close()

@app.route('/downloadv_pan/<form_number>')
def downloadv_pan(form_number):
    try:
        cursor = get_cursor()
        cursor.execute(
            "SELECT pan_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result and 'pan_document' in result and result['pan_document']:
            pdf_data = result['pan_document']
            response = make_response(pdf_data)
            response.headers.set('Content-Type', 'application/pdf')
            response.headers.set('Content-Disposition', 'attachment', filename=f"PAN_Document_{form_number}.pdf")
            return response
        else:
            abort(404, "PAN document not found or path is incorrect.")
    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        abort(500, "An error occurred while processing PAN document.")
    except Exception as e:
        print("Error:", e)
        abort(500, "An error occurred while processing PAN document.")
    finally:
        cursor.close()

def export_and_download(form_number):
    try:
        cursor = get_cursor()

        # Fetch GST document
        cursor.execute(
            "SELECT gst_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        gst_result = cursor.fetchone()
        gst_document = None
        if gst_result and 'gst_document' in gst_result and gst_result['gst_document']:
            gst_document = base64.b64encode(gst_result['gst_document']).decode('utf-8')

        # Fetch PAN document
        cursor.execute(
            "SELECT pan_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        pan_result = cursor.fetchone()
        pan_document = None
        if pan_result and 'pan_document' in pan_result and pan_result['pan_document']:
            pan_document = base64.b64encode(pan_result['pan_document']).decode('utf-8')

        # Prepare export URL
        export_url = url_for('export_to_excel', form_number=form_number)  # Adjust if needed

        return {
            "status": "success",
            "gst_document": gst_document,
            "pan_document": pan_document,
            "export_url": export_url
        }
    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return {
            "status": "error",
            "message": "An error occurred while processing the documents."
        }, 500
    except Exception as e:
        print("Error:", e)
        return {
            "status": "error",
            "message": "An error occurred while processing the documents."
        }, 500
    finally:
        cursor.close()

def export_and_downloadv(form_number):
    try:
        cursor = get_cursor()

        # Fetch GST document
        cursor.execute(
            "SELECT gst_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        gst_result = cursor.fetchone()
        gst_document = None
        if gst_result and 'gst_document' in gst_result and gst_result['gst_document']:
            gst_document = base64.b64encode(gst_result['gst_document']).decode('utf-8')

        # Fetch PAN document
        cursor.execute(
            "SELECT pan_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        pan_result = cursor.fetchone()
        pan_document = None
        if pan_result and 'pan_document' in pan_result and pan_result['pan_document']:
            pan_document = base64.b64encode(pan_result['pan_document']).decode('utf-8')

        # Prepare export URL
        export_url = url_for('export_to_excelv', form_number=form_number)  # Adjust if needed

        return {
            "status": "success",
            "gst_document": gst_document,
            "pan_document": pan_document,
            "export_url": export_url
        }
    except mysql.connector.Error as e:
        print("MySQL Error:", e)
        return {
            "status": "error",
            "message": "An error occurred while processing the documents."
        }, 500
    except Exception as e:
        print("Error:", e)
        return {
            "status": "error",
            "message": "An error occurred while processing the documents."
        }, 500
    finally:
        cursor.close()

@app.route('/marketingteamds/<form_number>')
def marketingteamds(form_number):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, category, request_number, gst_document, pan_document FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result:
            return render_template(
                'marketingteamds.html',
                form_number=form_number,
                request_number=result['request_number'],
                titles=result['titles'],
                name=result['name'],
                email=result['email'],
                company_name=result['company_name'],
                country=result['country'],
                state=result['state'],
                city=result['city'],
                street_address=result['street_address'],
                street_address_2=result['street_address_2'],
                street_address_3=result['street_address_3'],
                postal_code=result['postal_code'],
                phone_number=result['phone_number'],
                mobile_number=result['mobile_number'],
                gst_number=result['gst_number'],
                pan_number=result['pan_number'],
                region=result['region'],
                category=result['category'],
                gst_document=result['gst_document'],
                pan_document=result['pan_document']
            )
        else:
            return "Form not found.", 404

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return "An error occurred while processing form submission."

    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()

@app.route('/submit_form/<form_number>', methods=['POST'])
def submit_form(form_number):
    if request.method == 'POST':
        try:
            # Check if GST and PAN documents are viewed
            if not request.form.get('gst_viewed') or not request.form.get('pan_viewed'):
                flash('Please view both GST and PAN documents before submitting.', 'warning')
                return redirect(url_for('marketingteamds', form_number=form_number))

            cursor = db.cursor()

            # Check if form has already been submitted
            query = "SELECT * FROM marketing_submission WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            existing_form = cursor.fetchone()

            if existing_form:
                cursor.close()
                flash('Form has already been submitted for this form number.', 'warning')
                return redirect(url_for('marketingteamds', form_number=form_number))

            # Fetch data from formsbyc table
            cursor.execute(
                "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, category, request_number, gst_document, pan_document FROM formsbyc WHERE form_number = %s",
                (form_number,)
            )
            result = cursor.fetchone()

            if not result:
                cursor.close()
                flash('Form not found in formsbyc table.', 'error')
                return redirect(url_for('marketingteamds', form_number=form_number))

            # Construct data for insertion into marketing_submission
            data = {
                'form_number': form_number,
                'request_number': result[17],   # Adjust index based on your actual column order
                'titles': result[0],
                'name_1': result[1],
                'email_1': result[2],
                'company_name': result[3],
                'country': result[4],
                'state': result[5],
                'city': result[6],
                'street_3': result[7],
                'street_house_number': result[8],
                'street_2': result[9],
                'pin_code': result[10],
                'telephone_number_1': result[11],
                'mobile_number_1': result[12],
                'gstin_no': result[13],
                'pan_card': result[14],
                'region': result[15],
                # Include other fields as necessary
            }

            # Validate fields and update data
            for field, pattern in validation_rules.items():
                if field not in request.form:
                    cursor.close()
                    message = f'Missing form field: {field}'
                    return message
                if not re.match(pattern, request.form[field]):
                    cursor.close()
                    message = f'Invalid value for {field.replace("_", " ").title()}'
                    return message
                data[field] = request.form[field]

            data.update(fixed_values)

            # Additional data processing
            agent_code = request.form.get('agent_code', '').strip()
            broker_agent_code = request.form.get('broker_agent_code', '').strip()
            forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()

            data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
            data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
            data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''

            # Validate annual sales, currency, and sales year
            annual_sales = request.form.get('annual_sales', '').strip()
            currency = request.form.get('currency', '').strip()
            sales_year = request.form.get('sales_year', '').strip()

            sql = """INSERT INTO marketing_submission 
                     (customer_account_group, company_code, sales_org, division, titles, name_1, search_1,
                        street_3, street_house_number, street_2,
                        district, different_city, pin_code, city, country, region, telephone_number_1, mobile_number_1,
                        contact_person_1_comments_of_mobile_number, email_1, department_1_notes_of_email, mobile_phone_2,
                        contact_person_2_comments_of_mobile_number, email_2, department_2_notes_of_email, mobile_phone_3,
                        contact_person_3_comments_of_mobile_number, email_3, department_3_notes_of_email, legal_form, bp_type,
                        pan_card, gstin_no, annual_sales, currency, sales_year, sales_district, sales_office, sales_group,
                        currency_2, delivering_plant, overdeliv_tolerance, incoterms, incoterms_location, payment_terms,
                        credit_control_area, agent_code, broker_agent_code, forwarding_agent_code,
                        recon_account, sort_key, planning_group, payment_terms_2, payment_methods, dunning_procedure,
                        distribution_channel, name_2, search_2_old_customer_code, street, street_4, street_5, language, fax, extension, gst_category, price_group,
                        cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance, indicator_customer_is_rebate_relevant,
                        relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category, tax_category_2, tax_category_3, tax_category_4, sales_person, sales_person_code, relationship_category,
                        agent, broker_agent, forwarding_agent, form_number, request_number) 
                     VALUES (%(customer_account_group)s, %(company_code)s, %(sales_org)s, %(division)s, %(titles)s, %(name_1)s, %(search_1)s, 
                                %(street_3)s, %(street_house_number)s, %(street_2)s,  
                                %(district)s, %(different_city)s, %(pin_code)s, %(city)s, %(country)s, %(region)s, %(telephone_number_1)s, %(mobile_number_1)s, 
                                %(contact_person_1_comments_of_mobile_number)s, %(email_1)s, %(department_1_notes_of_email)s, %(mobile_phone_2)s, 
                                %(contact_person_2_comments_of_mobile_number)s, %(email_2)s, %(department_2_notes_of_email)s, %(mobile_phone_3)s, 
                                %(contact_person_3_comments_of_mobile_number)s, %(email_3)s, %(department_3_notes_of_email)s, %(legal_form)s, %(bp_type)s, 
                                %(pan_card)s, %(gstin_no)s, %(annual_sales)s, %(currency)s, %(sales_year)s, %(sales_district)s, %(sales_office)s, %(sales_group)s, 
                                %(currency_2)s, %(delivering_plant)s, %(overdeliv_tolerance)s, %(incoterms)s, %(incoterms_location)s, %(payment_terms)s, 
                                %(credit_control_area)s, %(agent_code)s, %(broker_agent_code)s, %(forwarding_agent_code)s, %(recon_account)s, %(sort_key)s, %(planning_group)s, %(payment_terms_2)s, %(payment_methods)s, %(dunning_procedure)s, 
                                %(distribution_channel)s, %(name_2)s, %(search_2_old_customer_code)s, %(street)s, %(street_4)s, %(street_5)s, %(language)s, %(fax)s, %(extension)s, %(gst_category)s, %(price_group)s, 
                                %(cust_pric_procedure)s, %(order_combination_indicator)s, %(shipping_conditions)s, %(underdel_tolerance)s, %(indicator_customer_is_rebate_relevant)s, 
                                %(relevant_for_price_determination_id)s, %(acct_assmt_grp_cust)s, %(tax_category)s, %(tax_category_2)s, %(tax_category_3)s, %(tax_category_4)s, %(sales_person)s, %(sales_person_code)s, %(relationship_category)s,  
                                %(agent)s, %(broker_agent)s, %(forwarding_agent)s, %(form_number)s, %(request_number)s)"""

            # Execute insertion
            cursor.execute(sql, data)
            db.commit()
            cursor.close()

            return redirect(url_for('totalnewrowsinserted'))

        except KeyError as e:
            logging.error(f"Missing key: {e}")
            traceback.print_exc()
            flash(f'Missing form field: {e}', 'error')
            return redirect(url_for('marketingteamds', form_number=form_number))

        except Exception as e:
            logging.error(f"Error: {e}")
            traceback.print_exc()
            flash(f'Form not Submitted. Error: {e}', 'error')
            return redirect(url_for('marketingteamds', form_number=form_number))

        finally:
            if 'cursor' in locals() and cursor is not None:
                cursor.close()
            if 'db' in locals() and db is not None and db.is_connected():
                db.close()

    else:
        flash('Method not allowed.', 'error')
        return redirect(url_for('index'))


@app.route('/marketingteamvds/<form_number>')
def marketingteamvds(form_number):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name, gst_number, pan_number, region, category, request_number, gst_document, pan_document FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result:
            return render_template(
                'marketingteamvds.html',
                form_number=form_number,
                request_number=result['request_number'],
                titles=result['titles'],
                name=result['name'],
                email=result['email'],
                company_name=result['company_name'],
                country=result['country'],
                state=result['state'],
                city=result['city'],
                street_address=result['street_address'],
                street_address_2=result['street_address_2'],
                street_address_3=result['street_address_3'],
                postal_code=result['postal_code'],
                phone_number=result['phone_number'],
                mobile_number=result['mobile_number'],
                mmse_type=result['mmse_type'],
                certificate_date=result['certificate_date'],
                bank_key=result['bank_key'],
                bank_acc_no=result['bank_acc_no'],
                account_holder_name=result['account_holder_name'],
                gst_number=result['gst_number'],
                pan_number=result['pan_number'],
                region=result['region'],
                category=result['category'],
                gst_document=result['gst_document'],
                pan_document=result['pan_document']
            )
        else:
            return "Form not found.", 404

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return "An error occurred while processing form submission."

    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()

@app.route('/submit_formv/<form_number>', methods=['POST'])
def submit_formv(form_number):
    if request.method == 'POST':
        try:
            # Check if GST and PAN documents are viewed
            if not request.form.get('gst_viewed') or not request.form.get('pan_viewed'):
                flash('Please view both GST and PAN documents before submitting.', 'warning')
                return redirect(url_for('marketingteamvds', form_number=form_number))

            cursor = db.cursor()

            # Check if form has already been submitted
            query = "SELECT * FROM purchase_submission WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            existing_form = cursor.fetchone()

            if existing_form:
                cursor.close()
                flash('Form has already been submitted for this form number.', 'warning')
                return redirect(url_for('marketingteamvds', form_number=form_number))

            # Fetch data from formsbyc table
            cursor.execute(
                "SELECT titles, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name, gst_number, pan_number, region, category, request_number, gst_document, pan_document FROM formsbyv WHERE form_number = %s",
                (form_number,)
            )
            result = cursor.fetchone()

            if not result:
                cursor.close()
                flash('Form not found in formsbyv table.', 'error')
                return redirect(url_for('marketingteamvds', form_number=form_number))

            # Construct data for insertion into marketing_submission
            data = {
                'form_number': form_number,
                'request_number': result[21],   # Adjust index based on your actual column order
                'titles': result[0],
                'email_id': result[2],
                'name_org1': result[3],
                'country': result[4],
                'state': result[5],
                'city': result[6],
                'street': result[7],
                'street_2': result[8],
                'street_3': result[9],
                'postal_code': result[10],
                'telephoneno': result[11],
                'mobileno': result[12],
                'mmse_type': result[13],
                'certificate_date': result[14],
                'bank_key': result[15],
                'bank_acc_no': result[16],
                'account_holder_name': result[17],
                'tax_number': result[18],
                'pan_no': result[19],
                'region': result[20],
                'company_code': request.form.get('p_org', ''),  # Assign 'p_org' to 'company_code'
                'payment_term': request.form.get('payment_terms', ''),  # Assigning 'payment_terms' to 'payment_term'
                # Include other fields as necessary
            }

            data['sort_text1'] = data['email_id']

            # # Debugging: print the value of sort_text1 to ensure it's correct
            # print(f"sort_text1: {data['sort_text1']}")  # This line is for debugging, remove it after confirmation

            # Validate fields and update data
            for field, pattern in validation_rules_vendor.items():
                if field not in request.form:
                    cursor.close()
                    message = f'Missing form field: {field}'
                    return message
                if not re.match(pattern, request.form[field]):
                    cursor.close()
                    message = f'Invalid value for {field.replace("_", " ").title()}'
                    return message
                data[field] = request.form[field]

            data.update(fixed_values_vendor)

            # # Additional data processing
            tax_number = request.form.get('tax_number', '').strip()

            data['tax_type'] = 'IN3' if tax_number and tax_number.lower() != 'none' else ''
            data['vendor_class'] = '1' if tax_number and tax_number.lower() != 'none' else ''


            sql = """INSERT INTO purchase_submission 
                      (creation_group, titles, name_org1, sort_text1, name_org2, postal_code, city, city_2, country, region, timezone,
                      house_number, street_2, street_3, street, telephoneno, mobileno, fax_no, 
                      email_id, legal_entity, tax_number, bp_type, social_insurance2, recon_account, sort_key, 
                      mmse_type, certificate_date, payment_method, p_org, payment_terms, incoterm, 
                      incoterm_location, purchase_group, type_of_business, 
                      pan_no, order_currency, bank_key, bank_acc_no, account_holder_name, 
                      partner_role, saluation, sort_text2, social_insurance, check_double_invoice, g_r_iv_verification, sr_based_iv_verificvcation,
                      schema_group, bank_country_key, payment_term, company_code, tax_type, vendor_class, form_number, request_number) 
                     VALUES (%(creation_group)s, %(titles)s, %(name_org1)s, %(sort_text1)s, %(name_org2)s, %(postal_code)s, %(city)s, 
                     %(city_2)s, %(country)s, %(region)s, %(timezone)s, %(house_number)s,  
                     %(street_2)s, %(street_3)s, %(street)s, %(telephoneno)s, %(mobileno)s, %(fax_no)s, %(email_id)s, %(legal_entity)s, 
                     %(tax_number)s, %(bp_type)s, %(social_insurance2)s, %(recon_account)s, %(sort_key)s, 
                     %(mmse_type)s, %(certificate_date)s, %(payment_method)s, %(p_org)s, 
                     %(payment_terms)s, %(incoterm)s, %(incoterm_location)s,  
                     %(purchase_group)s, %(type_of_business)s, %(pan_no)s, %(order_currency)s, 
                     %(bank_key)s, %(bank_acc_no)s, %(account_holder_name)s,
                     %(partner_role)s, %(saluation)s, %(sort_text2)s, %(social_insurance)s, %(check_double_invoice)s, 
                     %(g_r_iv_verification)s, %(sr_based_iv_verificvcation)s, %(schema_group)s, %(bank_country_key)s, 
                     %(payment_term)s, %(company_code)s, %(tax_type)s, %(vendor_class)s, %(form_number)s, %(request_number)s)"""

            # Execute insertion
            cursor.execute(sql, data)
            db.commit()
            cursor.close()

            return redirect(url_for('totalnewrowsinsertedv'))

        except KeyError as e:
            logging.error(f"Missing key: {e}")
            traceback.print_exc()
            flash(f'Missing form field: {e}', 'error')
            return redirect(url_for('marketingteamvds', form_number=form_number))

        except Exception as e:
            logging.error(f"Error: {e}")
            traceback.print_exc()
            flash(f'Form not Submitted. Error: {e}', 'error')
            return redirect(url_for('marketingteamvds', form_number=form_number))

        finally:
            if 'cursor' in locals() and cursor is not None:
                cursor.close()
            if 'db' in locals() and db is not None and db.is_connected():
                db.close()

    else:
        flash('Method not allowed.', 'error')
        return redirect(url_for('index'))

@app.route('/marketingteame/<form_number>')
def marketingteame(form_number):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, region, category, request_number FROM formsbyc WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result:
            return render_template(
                'marketingteame.html',
                form_number=form_number,
                request_number=result['request_number'],
                titles=result['titles'],
                name=result['name'],
                email=result['email'],
                company_name=result['company_name'],
                country=result['country'],
                state=result['state'],
                city=result['city'],
                street_address=result['street_address'],
                street_address_2=result['street_address_2'],
                street_address_3=result['street_address_3'],
                postal_code=result['postal_code'],
                phone_number=result['phone_number'],
                mobile_number=result['mobile_number'],
                region=result['region'],
                category=result['category']
            )
        else:
            return "Form not found.", 404

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return "An error occurred while processing form submission."

    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()

@app.route('/marketingteamve/<form_number>')
def marketingteamve(form_number):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name, region, category, request_number FROM formsbyv WHERE form_number = %s",
            (form_number,)
        )
        result = cursor.fetchone()

        if result:
            return render_template(
                'marketingteamve.html',
                form_number=form_number,
                request_number=result['request_number'],
                titles=result['titles'],
                name=result['name'],
                email=result['email'],
                company_name=result['company_name'],
                country=result['country'],
                state=result['state'],
                city=result['city'],
                street_address=result['street_address'],
                street_address_2=result['street_address_2'],
                street_address_3=result['street_address_3'],
                postal_code=result['postal_code'],
                phone_number=result['phone_number'],
                mobile_number=result['mobile_number'],
                mmse_type=result['mmse_type'],
                certificate_date=result['certificate_date'],
                bank_key=result['bank_key'],
                bank_acc_no=result['bank_acc_no'],
                account_holder_name=result['account_holder_name'],
                region=result['region'],
                category=result['category']
            )
        else:
            return "Form not found.", 404

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return "An error occurred while processing form submission."

    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()

@app.route('/submit_forme/<form_number>', methods=['POST'])
def submit_forme(form_number):
    if request.method == 'POST':
        try:
            cursor = db.cursor()

            # Check if form has already been submitted
            query = "SELECT * FROM marketing_submission WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            existing_form = cursor.fetchone()

            if existing_form:
                cursor.close()
                flash('Form has already been submitted for this form number.', 'warning')
                return redirect(url_for('marketingteame', form_number=form_number))

            # Fetch data from formsbyc table
            cursor.execute(
                "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, region, category, request_number FROM formsbyc WHERE form_number = %s",
                (form_number,)
            )
            result = cursor.fetchone()

            if not result:
                cursor.close()
                flash('Form not found in formsbyc table.', 'error')
                return redirect(url_for('marketingteame', form_number=form_number))

            # Construct data for insertion into marketing_submission
            data = {
                'form_number': form_number,
                'request_number': result[15],   # Adjust index based on your actual column order
                'titles': result[0],
                'name_1': result[1],
                'email_1': result[2],
                'company_name': result[3],
                'country': result[4],
                'state': result[5],
                'city': result[6],
                'street_3': result[7],
                'street_house_number': result[8],
                'street_2': result[9],
                'pin_code': result[10],
                'telephone_number_1': result[11],
                'mobile_number_1': result[12],
                'region': result[13],
                # Include other fields as necessary
            }

            # Validate fields and update data
            for field, pattern in validation_rules_for_e.items():
                if field not in request.form:
                    cursor.close()
                    message = f'Missing form field: {field}'
                    return message
                if not re.match(pattern, request.form[field]):
                    cursor.close()
                    message = f'Invalid value for {field.replace("_", " ").title()}'
                    return message
                data[field] = request.form[field]


            data.update(fixed_values_e)

            # Additional data processing
            agent_code = request.form.get('agent_code', '').strip()
            broker_agent_code = request.form.get('broker_agent_code', '').strip()
            forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()

            data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
            data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
            data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''

            # Validate annual sales, currency, and sales year
            annual_sales = request.form.get('annual_sales', '').strip()
            currency = request.form.get('currency', '').strip()
            sales_year = request.form.get('sales_year', '').strip()

            sql = """INSERT INTO marketing_submission 
                     (customer_account_group, company_code, sales_org, division, titles, name_1, search_1,
                        street_3, street_house_number, street_2,
                        district, different_city, pin_code, city, country, region, telephone_number_1, mobile_number_1,
                        contact_person_1_comments_of_mobile_number, email_1, department_1_notes_of_email, mobile_phone_2,
                        contact_person_2_comments_of_mobile_number, email_2, department_2_notes_of_email, mobile_phone_3,
                        contact_person_3_comments_of_mobile_number, email_3, department_3_notes_of_email, legal_form, bp_type,
                        annual_sales, currency, sales_year, sales_district, sales_office, sales_group,
                        currency_2, delivering_plant, overdeliv_tolerance, incoterms, incoterms_location, payment_terms,
                        credit_control_area, agent_code, broker_agent_code, forwarding_agent_code, 
                        recon_account, sort_key, planning_group, payment_terms_2, payment_methods, dunning_procedure,
                        distribution_channel, name_2, search_2_old_customer_code, street, street_4, street_5, language, fax, extension, gst_category, price_group,
                        cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance, indicator_customer_is_rebate_relevant,
                        relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category, tax_category_2, tax_category_3, tax_category_4, sales_person, sales_person_code, relationship_category,
                        agent, broker_agent, forwarding_agent, form_number, request_number) 
                     VALUES (%(customer_account_group)s, %(company_code)s, %(sales_org)s, %(division)s, %(titles)s, %(name_1)s, %(search_1)s, 
                                %(street_3)s, %(street_house_number)s, %(street_2)s,  
                                %(district)s, %(different_city)s, %(pin_code)s, %(city)s, %(country)s, %(region)s, %(telephone_number_1)s, %(mobile_number_1)s, 
                                %(contact_person_1_comments_of_mobile_number)s, %(email_1)s, %(department_1_notes_of_email)s, %(mobile_phone_2)s, 
                                %(contact_person_2_comments_of_mobile_number)s, %(email_2)s, %(department_2_notes_of_email)s, %(mobile_phone_3)s, 
                                %(contact_person_3_comments_of_mobile_number)s, %(email_3)s, %(department_3_notes_of_email)s, %(legal_form)s, %(bp_type)s, 
                                %(annual_sales)s, %(currency)s, %(sales_year)s, %(sales_district)s, %(sales_office)s, %(sales_group)s, 
                                %(currency_2)s, %(delivering_plant)s, %(overdeliv_tolerance)s, %(incoterms)s, %(incoterms_location)s, %(payment_terms)s, 
                                %(credit_control_area)s, %(agent_code)s, %(broker_agent_code)s, %(forwarding_agent_code)s, %(recon_account)s, %(sort_key)s, %(planning_group)s, %(payment_terms_2)s, %(payment_methods)s, %(dunning_procedure)s, 
                                %(distribution_channel)s, %(name_2)s, %(search_2_old_customer_code)s, %(street)s, %(street_4)s, %(street_5)s, %(language)s, %(fax)s, %(extension)s, %(gst_category)s, %(price_group)s, 
                                %(cust_pric_procedure)s, %(order_combination_indicator)s, %(shipping_conditions)s, %(underdel_tolerance)s, %(indicator_customer_is_rebate_relevant)s, 
                                %(relevant_for_price_determination_id)s, %(acct_assmt_grp_cust)s, %(tax_category)s, %(tax_category_2)s, %(tax_category_3)s, %(tax_category_4)s, %(sales_person)s, %(sales_person_code)s, %(relationship_category)s,  
                                %(agent)s, %(broker_agent)s, %(forwarding_agent)s, %(form_number)s, %(request_number)s)"""

            # Execute insertion
            cursor.execute(sql, data)
            db.commit()
            cursor.close()

            # flash('Data successfully submitted', 'success')
            return redirect(url_for('totalnewrowsinserted'))

        except KeyError as e:
            logging.error(f"Missing key: {e}")
            traceback.print_exc()
            flash(f'Missing form field: {e}', 'error')
            return redirect(url_for('marketingteame', form_number=form_number))

        except Exception as e:
            logging.error(f"Error: {e}")
            traceback.print_exc()
            flash(f'Form not Submitted. Error: {e}', 'error')
            return redirect(url_for('marketingteame', form_number=form_number))

        finally:
            if 'cursor' in locals() and cursor is not None:
                cursor.close()
            if 'db' in locals() and db is not None and db.is_connected():
                db.close()
    else:
        flash('Method not allowed.', 'error')
        return redirect(url_for('index'))

@app.route('/submit_formve/<form_number>', methods=['POST'])
def submit_formve(form_number):
    if request.method == 'POST':
        try:
            cursor = db.cursor()

            # Check if form has already been submitted
            query = "SELECT * FROM purchase_submission WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            existing_form = cursor.fetchone()

            if existing_form:
                cursor.close()
                flash('Form has already been submitted for this form number.', 'warning')
                return redirect(url_for('marketingteamve', form_number=form_number))

            # Fetch data from formsbyc table
            cursor.execute(
                "SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, mmse_type, certificate_date, bank_key, bank_acc_no, account_holder_name, region, category, request_number FROM formsbyv WHERE form_number = %s",
                (form_number,)
            )
            result = cursor.fetchone()

            if not result:
                cursor.close()
                flash('Form not found in formsbyv table.', 'error')
                return redirect(url_for('marketingteamve', form_number=form_number))

            # Construct data for insertion into marketing_submission
            data = {
                'form_number': form_number,
                'request_number': result[18],   # Adjust index based on your actual column order
                'titles': result[0],
                'email_id': result[1],
                'name_org1': result[2],
                'country': result[3],
                'state': result[4],
                'city': result[5],
                'street': result[6],
                'street_2': result[7],
                'street_3': result[8],
                'pin_code': result[9],
                'telephoneno': result[10],
                'mobileno': result[11],
                'mmse_type': result[12],
                'certificate_date': result[13],
                'bank_key': result[14],
                'bank_acc_no': result[15],
                'account_holder_name': result[16],
                'region': result[17],
                'company_code': request.form.get('p_org', ''),  # Assign 'p_org' to 'company_code'
                'payment_term': request.form.get('payment_terms', ''),  # Assigning 'payment_terms' to 'payment_term'
                'sort_text1': request.form.get('name_org1', ''),
                # Include other fields as necessary
            }

            # Validate fields and update data
            for field, pattern in validation_rules_vendor_i.items():
                if field not in request.form:
                    cursor.close()
                    message = f'Missing form field: {field}'
                    return message
                if not re.match(pattern, request.form[field]):
                    cursor.close()
                    message = f'Invalid value for {field.replace("_", " ").title()}'
                    return message
                data[field] = request.form[field]


            data.update(fixed_values_vendor_i)

            # # Additional data processing
            # agent_code = request.form.get('agent_code', '').strip()
            # broker_agent_code = request.form.get('broker_agent_code', '').strip()
            # forwarding_agent_code = request.form.get('forwarding_agent_code', '').strip()
            #
            # data['agent'] = 'ZA' if agent_code and agent_code.lower() != 'none' else ''
            # data['broker_agent'] = 'ZB' if broker_agent_code and broker_agent_code.lower() != 'none' else ''
            # data['forwarding_agent'] = 'CR' if forwarding_agent_code and forwarding_agent_code.lower() != 'none' else ''
            #
            # # Validate annual sales, currency, and sales year
            # annual_sales = request.form.get('annual_sales', '').strip()
            # currency = request.form.get('currency', '').strip()
            # sales_year = request.form.get('sales_year', '').strip()

            sql = """INSERT INTO purchase_submission 
                      (creation_group, titles, name_org1, name_org2, postal_code, city, city_2, country, region, timezone,
                      house_number, street_2, street_3, street, telephoneno, mobileno, fax_no, 
                      email_id, legal_entity, tax_number, bp_type, social_insurance2, recon_account, sort_key, 
                      mmse_type, certificate_date, payment_method, p_org, payment_terms, incoterm, 
                      incoterm_location, purchase_group, type_of_business, 
                      pan_no, order_currency, bank_key, bank_acc_no, account_holder_name, 
                      partner_role, saluation, sort_text2, social_insurance, check_double_invoice, g_r_iv_verification, sr_based_iv_verificvcation,
                      schema_group, tax_type, bank_country_key, payment_term, company_code, sort_text1, vendor_class, form_number, request_number) 
                     VALUES (%(creation_group)s, %(titles)s, %(name_org1)s, %(name_org2)s, %(postal_code)s, %(city)s, 
                     %(city_2)s, %(country)s, %(region)s, %(timezone)s, %(house_number)s,  
                     %(street_2)s, %(street_3)s, %(street)s, %(telephoneno)s, %(mobileno)s, %(fax_no)s, %(email_id)s, %(legal_entity)s, 
                     %(tax_number)s, %(bp_type)s, %(social_insurance2)s, %(recon_account)s, %(sort_key)s, 
                     %(mmse_type)s, %(certificate_date)s, %(payment_method)s, %(p_org)s, 
                     %(payment_terms)s, %(incoterm)s, %(incoterm_location)s,  
                     %(purchase_group)s, %(type_of_business)s, %(pan_no)s, %(order_currency)s, 
                     %(bank_key)s, %(bank_acc_no)s, %(account_holder_name)s,
                     %(partner_role)s, %(saluation)s, %(sort_text2)s, %(social_insurance)s, %(check_double_invoice)s, 
                     %(g_r_iv_verification)s, %(sr_based_iv_verificvcation)s, %(schema_group)s, %(tax_type)s, %(bank_country_key)s, 
                     %(payment_term)s, %(company_code)s, %(sort_text1)s, %(vendor_class)s, %(form_number)s, %(request_number)s)"""

            # Execute insertion
            cursor.execute(sql, data)
            db.commit()
            cursor.close()

            # flash('Data successfully submitted', 'success')
            return redirect(url_for('totalnewrowsinsertedv'))

        except KeyError as e:
            logging.error(f"Missing key: {e}")
            traceback.print_exc()
            flash(f'Missing form field: {e}', 'error')
            return redirect(url_for('marketingteamve', form_number=form_number))

        except Exception as e:
            logging.error(f"Error: {e}")
            traceback.print_exc()
            flash(f'Form not Submitted. Error: {e}', 'error')
            return redirect(url_for('marketingteamve', form_number=form_number))

        finally:
            if 'cursor' in locals() and cursor is not None:
                cursor.close()
            if 'db' in locals() and db is not None and db.is_connected():
                db.close()
    else:
        flash('Method not allowed.', 'error')
        return redirect(url_for('index'))

def get_mr_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT cr.request_number, cr.company_name AS customer_company_name, cr.email,
                   cr.category AS customer_category,
                   cr.logged_in_user_email AS customer_logged_in_user_email,
                   fb.titles AS form_titles, fb.name AS form_name, fb.email AS form_email,
                   fb.company_name AS form_company_name, fb.country, fb.state, fb.city,
                   fb.street_address, fb.street_address_2, fb.street_address_3,
                   fb.postal_code, fb.phone_number, fb.mobile_number, fb.gst_number,
                   fb.pan_number, fb.region AS form_region, fb.category AS form_category,
                   fb.form_number AS form_number, fb.request_number,
                   fb.submission_date AS form_submission_date,
                   ms.customer_account_group, ms.company_code, ms.sales_org,
                   ms.distribution_channel, ms.division, ms.name_1, ms.name_2, ms.search_1,
                   ms.search_2_old_customer_code, ms.street_3, ms.street_house_number,
                   ms.street_2, ms.street, ms.street_4,
                   ms.street_5, ms.district, ms.different_city, ms.pin_code, ms.city,
                   ms.country, ms.region, ms.language,
                   ms.telephone_number_1, ms.mobile_number_1, ms.contact_person_1_comments_of_mobile_number,
                   ms.fax, ms.extension, ms.email_1, ms.department_1_notes_of_email,
                   ms.mobile_phone_2, ms.contact_person_2_comments_of_mobile_number, ms.email_2,
                   ms.department_2_notes_of_email, ms.mobile_phone_3, ms.contact_person_3_comments_of_mobile_number,
                   ms.email_3, ms.department_3_notes_of_email, ms.legal_form, ms.bp_type,
                   ms.pan_card, ms.gst_category, ms.gstin_no, ms.annual_sales,
                   ms.currency, ms.sales_year, ms.sales_district, ms.sales_office,
                   ms.sales_group, ms.currency_2, ms.price_group, ms.cust_pric_procedure,
                   ms.order_combination_indicator, ms.delivering_plant, ms.shipping_conditions,
                   ms.underdel_tolerance, ms.overdeliv_tolerance, ms.indicator_customer_is_rebate_relevant,
                   ms.relevant_for_price_determination_id, ms.incoterms, ms.incoterms_location,
                   ms.payment_terms, ms.credit_control_area, ms.acct_assmt_grp_cust,
                   ms.tax_category, ms.tax_category_2, ms.tax_category_3, ms.tax_category_4,
                   ms.agent, ms.agent_code, ms.broker_agent, ms.broker_agent_code,
                   ms.forwarding_agent, ms.forwarding_agent_code, ms.sales_person,
                   ms.sales_person_code, ms.recon_account, ms.sort_key, ms.planning_group,
                   ms.payment_terms_2, ms.payment_methods, ms.dunning_procedure,
                   ms.relationship_category,  
                   ms.form_number AS ms_form_number,
                   ms.request_number AS ms_request_number, ms.submission_date AS ms_submission_date,
                   ms.submit_timestamp AS ms_submit_timestamp,
                   cmd.form_number AS changes_done_form_number, cmd.date_changed AS changes_done_date,
                   crf.details AS changes_requested_details,
                   crf.form_number AS changes_requested_form_number,
                   cad.form_number AS changes_done_it_form_number, cad.date_changed AS changes_done_it_date,
                   crt.details AS changes_requested_it_details,
                   crt.form_number AS changes_requested_it_form_number,
                   af.form_number AS changes_done_accounts_form_number,
                   itf.form_number AS changes_done_itf_form_number
            FROM customerrequested cr
            LEFT JOIN formsbyc fb ON cr.request_number = fb.request_number
            LEFT JOIN marketing_submission ms ON fb.form_number = ms.form_number
            LEFT JOIN changesdoneby_marketing cmd ON fb.form_number = cmd.form_number
            LEFT JOIN changesrequestedfromar crf ON fb.form_number = crf.form_number
            LEFT JOIN changesdoneby_ar cad ON fb.form_number = cad.form_number
            LEFT JOIN changes_requestedtoar crt ON fb.form_number = crt.form_number
            LEFT JOIN account_final af ON fb.form_number = af.form_number
            LEFT JOIN it_final itf ON fb.form_number = itf.form_number
            WHERE ms.form_number IS NOT NULL
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

def get_pr_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT vr.request_number, vr.company_name AS customer_company_name, vr.email,
                   vr.category AS customer_category,
                   vr.logged_in_user_email AS customer_logged_in_user_email,
                   fv.titles AS form_titles, fv.name AS form_name, fv.email AS form_email,
                   fv.company_name AS form_company_name, fv.country, fv.state, fv.city,
                   fv.street_address, fv.street_address_2, fv.street_address_3,
                   fv.postal_code, fv.phone_number, fv.mobile_number, fv.gst_number,
                   fv.pan_number, fv.region AS form_region, fv.category AS form_category,
                   fv.form_number AS form_number, fv.request_number,
                   fv.submission_date AS form_submission_date,
                   ps.partner_role, ps.creation_group, ps.titles, ps.name_org1, ps.name_org2, ps.postal_code, 
                   ps.city, ps.city_2, ps.country, ps.region, ps.timezone, ps.house_number, ps.saluation, 
                   ps.sort_text1, ps.sort_text2, ps.street_2, ps.street_3, ps.street, ps.telephoneno, 
                   ps.mobileno, ps.fax_no, ps.email_id, ps.legal_entity, ps.tax_type, ps.tax_number, 
                   ps.bp_type, ps.social_insurance, ps.company_code, ps.recon_account, ps.sort_key, 
                   ps.mmse_type, ps.certificate_date, ps.payment_term, ps.check_double_invoice, ps.payment_method, 
                   ps.p_org, ps.payment_terms, ps.incoterm, ps.incoterm_location, ps.g_r_iv_verification, 
                   ps.sr_based_iv_verificvcation, ps.purchase_group, ps.schema_group, ps.type_of_business, 
                   ps.pan_no, ps.vendor_class, ps.order_currency, ps.bank_country_key, ps.bank_key, ps.bank_acc_no, 
                   ps.account_holder_name,
                   ps.form_number AS ps_form_number,
                   ps.request_number AS ps_request_number, ps.submission_date AS ps_submission_date,
                   ps.submit_timestamp AS ps_submit_timestamp,
                   cmp.form_number AS changes_done_form_number, cmp.date_changed AS changes_done_date,
                   crfp.details AS changes_requested_details,
                   crfp.form_number AS changes_requested_form_number,
                   cap.form_number AS changes_done_it_form_number, cap.date_changed AS changes_done_it_date,
                   crp.details AS changes_requested_it_details,
                   crp.form_number AS changes_requested_it_form_number,
                   apf.form_number AS changes_done_accounts_form_number,
                   itv.form_number AS changes_done_itv_form_number
            FROM vendorrequested vr
            LEFT JOIN formsbyv fv ON vr.request_number = fv.request_number
            LEFT JOIN purchase_submission ps ON fv.form_number = ps.form_number
            LEFT JOIN changesdoneby_purchase cmp ON fv.form_number = cmp.form_number
            LEFT JOIN changesrequestedfromap crfp ON fv.form_number = crfp.form_number
            LEFT JOIN changesdoneby_ap cap ON fv.form_number = cap.form_number
            LEFT JOIN changes_requestedtoap crp ON fv.form_number = crp.form_number
            LEFT JOIN accountp_final apf ON fv.form_number = apf.form_number
            LEFT JOIN itv_final itv ON fv.form_number = itv.form_number
            WHERE ps.form_number IS NOT NULL
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

@app.route('/marketcheckbyar')
def marketcheckbyar():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_mr_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ms_form_number')
            changes_done_form_number = form_detail.get('changes_done_form_number')
            changes_requested_form_number = form_detail.get('changes_requested_form_number')
            changes_done_accounts_form_number = form_detail.get('changes_done_accounts_form_number')

            if form_number is None:
                logging.error("Missing 'ms_form_number' in form_detail: %s", form_detail)
                continue

            logging.debug("Processing form_detail: %s", form_detail)

            if changes_done_accounts_form_number and changes_requested_form_number:
                form_detail['approved_status'] = 'Form Sent to IT Team'
            elif changes_done_accounts_form_number:
                form_detail['approved_status'] = 'Form Sent to IT Team'
            else:
                form_detail['approved_status'] = ''

            form_detail['form_number_exists_in_account_final'] = bool(changes_done_accounts_form_number)

            if changes_done_form_number and changes_requested_form_number:
                form_detail['status_details'] = 'Changes Done'
            elif changes_requested_form_number:
                form_detail['status_details'] = 'Still Pending'
            else:
                form_detail['status_details'] = ''

            form_detail['form_number_exists_in_changesdoneby_marketing'] = bool(changes_done_form_number)

        # Render the page after processing all form details
        return render_template('marketcheckbyar.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in marketcheckbyar(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/vendorcheckbyap')
def vendorcheckbyap():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_pr_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ps_form_number')
            changes_done_form_number = form_detail.get('changes_done_form_number')
            changes_requested_form_number = form_detail.get('changes_requested_form_number')
            changes_done_accounts_form_number = form_detail.get('changes_done_accounts_form_number')

            if form_number is None:
                logging.error("Missing 'ps_form_number' in form_detail: %s", form_detail)
                continue

            logging.debug("Processing form_detail: %s", form_detail)

            if changes_done_accounts_form_number and changes_requested_form_number:
                form_detail['approved_status'] = 'Form Sent to IT Team'
            elif changes_done_accounts_form_number:
                form_detail['approved_status'] = 'Form Sent to IT Team'
            else:
                form_detail['approved_status'] = ''

            form_detail['form_number_exists_in_accountp_final'] = bool(changes_done_accounts_form_number)

            if changes_done_form_number and changes_requested_form_number:
                form_detail['status_details'] = 'Changes Done'
            elif changes_requested_form_number:
                form_detail['status_details'] = 'Still Pending'
            else:
                form_detail['status_details'] = ''

            form_detail['form_number_exists_in_changesdoneby_purchase'] = bool(changes_done_form_number)

        # Render the page after processing all form details
        return render_template('vendorcheckbyap.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in vendorcheckbyap(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/arteamformds/<form_number>')
def arteamformds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyc WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        cursor.close()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        return render_template('arteamformds.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/arteamformvds/<form_number>')
def arteamformvds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyv WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        cursor.close()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        return render_template('arteamformvds.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

# Route for handling Export category
@app.route('/arteamforme/<form_number>')
def arteamforme(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from database
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        cursor.close()

        if form_details:
            return render_template('arteamforme.html', form_number=form_number, form_details=form_details)
        else:
            return "Form not found", 404

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/arteamformve/<form_number>')
def arteamformve(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from database
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        cursor.close()

        if form_details:
            return render_template('arteamformve.html', form_number=form_number, form_details=form_details)
        else:
            return "Form not found", 404

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_art_form_details', methods=['POST'])
def submit_art_form_details():
    form_number = request.form['form_number']
    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')
    submit_action = request.form.get('submit_action')

    try:
        cursor = db.cursor()

        # Check if form_number already exists in account_final table
        query_check_final = "SELECT form_number FROM account_final WHERE form_number = %s"
        cursor.execute(query_check_final, (form_number,))
        existing_final = cursor.fetchone()

        if existing_final and submit_action == 'changes_required':
            flash('Once the details are submitted to IT Team!, The Changes Required button will not work.', 'danger')
            return redirect(url_for('marketcheckbyar'))

        # Check if form_number already exists in changes_requestedtoar table
        query_check_changes_requested = "SELECT form_number, details FROM changesrequestedfromar WHERE form_number = %s"
        cursor.execute(query_check_changes_requested, (form_number,))
        existing_changes_requested = cursor.fetchone()

        # Check if form_number already exists in changesdoneby_marketing table
        query_check_changes_done = "SELECT form_number FROM changesdoneby_marketing WHERE form_number = %s"
        cursor.execute(query_check_changes_done, (form_number,))
        existing_changes_done = cursor.fetchone()

        # Determine if the form number should be submitted to account_final
        if submit_action == 'submit':
            if (existing_changes_done and existing_changes_requested) or (not existing_changes_done and not existing_changes_requested):
                # Form number is either present in both tables or not present in both tables
                if not existing_final:
                    # Insert into account_final if not already present
                    query_insert_final = "INSERT INTO account_final (form_number, date_changed) VALUES (%s, %s)"
                    cursor.execute(query_insert_final, (form_number, date_changed))
                    db.commit()
                return redirect(url_for('marketcheckbyar'))
            else:
                # Form number is only present in one of the tables, show error
                flash('There are still pending changes from the marketing team so the data will not submit.', 'danger')
                return redirect(url_for('marketcheckbyar'))

        if existing_changes_requested and submit_action == 'changes_required':
            # If form_number exists in changes_requestedtoar and submit_action is 'changes_required', update details with comma
            current_details = existing_changes_requested[1] + ', ' if existing_changes_requested[1] else ''
            updated_details = current_details + changes_required
            query_update_changes = "UPDATE changesrequestedfromar SET details = %s WHERE form_number = %s"
            cursor.execute(query_update_changes, (updated_details, form_number))
            db.commit()

            # Delete form_number from changesdoneby_marketing
            query_delete_changes_done = "DELETE FROM changesdoneby_marketing WHERE form_number = %s"
            cursor.execute(query_delete_changes_done, (form_number,))
            db.commit()

        elif submit_action == 'changes_required':
            # If form_number does not exist in changes_requestedtoar and submit_action is 'changes_required', insert new record
            query_insert_changes = "INSERT INTO changesrequestedfromar (form_number, details) VALUES (%s, %s)"
            cursor.execute(query_insert_changes, (form_number, changes_required))
            db.commit()

            # Delete form_number from changesdoneby_marketing
            query_delete_changes_done = "DELETE FROM changesdoneby_marketing WHERE form_number = %s"
            cursor.execute(query_delete_changes_done, (form_number,))
            db.commit()

        cursor.close()

        return redirect(url_for('marketcheckbyar'))

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return "An error occurred while submitting the form.", 500

    except Exception as e:
        logging.error("Error: %s", e)
        return "An unexpected error occurred.", 500

@app.route('/submit_apt_form_details', methods=['POST'])
def submit_apt_form_details():
    form_number = request.form['form_number']
    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')
    submit_action = request.form.get('submit_action')

    try:
        cursor = db.cursor()

        # Check if form_number already exists in account_final table
        query_check_final = "SELECT form_number FROM accountp_final WHERE form_number = %s"
        cursor.execute(query_check_final, (form_number,))
        existing_final = cursor.fetchone()

        if existing_final and submit_action == 'changes_required':
            flash('Once the details are submitted to IT Team!, The Changes Required button will not work.', 'danger')
            return redirect(url_for('vendorcheckbyap'))

        # Check if form_number already exists in changes_requestedtoar table
        query_check_changes_requested = "SELECT form_number, details FROM changesrequestedfromap WHERE form_number = %s"
        cursor.execute(query_check_changes_requested, (form_number,))
        existing_changes_requested = cursor.fetchone()

        # Check if form_number already exists in changesdoneby_marketing table
        query_check_changes_done = "SELECT form_number FROM changesdoneby_purchase WHERE form_number = %s"
        cursor.execute(query_check_changes_done, (form_number,))
        existing_changes_done = cursor.fetchone()

        # Determine if the form number should be submitted to account_final
        if submit_action == 'submit':
            if (existing_changes_done and existing_changes_requested) or (not existing_changes_done and not existing_changes_requested):
                # Form number is either present in both tables or not present in both tables
                if not existing_final:
                    # Insert into account_final if not already present
                    query_insert_final = "INSERT INTO accountp_final (form_number, date_changed) VALUES (%s, %s)"
                    cursor.execute(query_insert_final, (form_number, date_changed))
                    db.commit()
                return redirect(url_for('vendorcheckbyap'))
            else:
                # Form number is only present in one of the tables, show error
                flash('There are still pending changes from the marketing team so the data will not submit.', 'danger')
                return redirect(url_for('vendorcheckbyap'))

        if existing_changes_requested and submit_action == 'changes_required':
            # If form_number exists in changes_requestedtoar and submit_action is 'changes_required', update details with comma
            current_details = existing_changes_requested[1] + ', ' if existing_changes_requested[1] else ''
            updated_details = current_details + changes_required
            query_update_changes = "UPDATE changesrequestedfromap SET details = %s WHERE form_number = %s"
            cursor.execute(query_update_changes, (updated_details, form_number))
            db.commit()

            # Delete form_number from changesdoneby_marketing
            query_delete_changes_done = "DELETE FROM changesdoneby_purchase WHERE form_number = %s"
            cursor.execute(query_delete_changes_done, (form_number,))
            db.commit()

        elif submit_action == 'changes_required':
            # If form_number does not exist in changes_requestedtoar and submit_action is 'changes_required', insert new record
            query_insert_changes = "INSERT INTO changesrequestedfromap (form_number, details) VALUES (%s, %s)"
            cursor.execute(query_insert_changes, (form_number, changes_required))
            db.commit()

            # Delete form_number from changesdoneby_marketing
            query_delete_changes_done = "DELETE FROM changesdoneby_purchase WHERE form_number = %s"
            cursor.execute(query_delete_changes_done, (form_number,))
            db.commit()

        cursor.close()

        return redirect(url_for('vendorcheckbyap'))

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return "An error occurred while submitting the form.", 500

    except Exception as e:
        logging.error("Error: %s", e)
        return "An unexpected error occurred.", 500


@app.route('/changesrequestedfromitseear')
def changesrequestedfromitseear():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_it_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ms_form_number')
            # changes_done_it_form_number = form_detail.get('changes_done_it_form_number')
            changes_requested_it_form_number = form_detail.get('changes_requested_it_form_number')
            changes_requested_it_details = form_detail.get('changes_requested_it_details')

            if form_number is None:
                logging.error("Missing 'ms_form_number' in form_detail: %s", form_detail)
                continue

            # Check if the form_number exists in changesdoneby_ar
            cursor = db.cursor(dictionary=True)
            query = "SELECT * FROM changesdoneby_ar WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            exists = cursor.fetchone() is not None
            cursor.close()

            # Set form_number_exists_in_changesdoneby_ar based on existence
            form_detail['form_number_exists_in_changesdoneby_ar'] = exists

            if changes_requested_it_form_number:
                form_detail['marketing_changes'] = changes_requested_it_details
            else:
                form_detail['marketing_changes'] = ''

        # Render the page after processing all form details
        return render_template('changesrequestedfromitseear.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in changesrequestedfromitseear(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/changesrequestedfromitseeap')
def changesrequestedfromitseeap():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_itv_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ps_form_number')
            # changes_done_it_form_number = form_detail.get('changes_done_it_form_number')
            changes_requested_it_form_number = form_detail.get('changes_requested_it_form_number')
            changes_requested_it_details = form_detail.get('changes_requested_it_details')

            if form_number is None:
                logging.error("Missing 'ps_form_number' in form_detail: %s", form_detail)
                continue

            # Check if the form_number exists in changesdoneby_ar
            cursor = db.cursor(dictionary=True)
            query = "SELECT * FROM changesdoneby_ap WHERE form_number = %s"
            cursor.execute(query, (form_number,))
            exists = cursor.fetchone() is not None
            cursor.close()

            # Set form_number_exists_in_changesdoneby_ar based on existence
            form_detail['form_number_exists_in_changesdoneby_ap'] = exists

            if changes_requested_it_form_number:
                form_detail['marketing_changes'] = changes_requested_it_details
            else:
                form_detail['marketing_changes'] = ''

        # Render the page after processing all form details
        return render_template('changesrequestedfromitseeap.html', logged_in_user_email=logged_in_user_email, form_details=form_details)

    except Exception as e:
        logging.error("Error in changesrequestedfromitseeap(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/arteamformdsseear/<form_number>')
def arteamformdsseear(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyc WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        cursor.close()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        return render_template('arteamformdsseear.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/arteamformdsseeap/<form_number>')
def arteamformdsseeap(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyv WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        cursor.close()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents['gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents['pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        return render_template('arteamformdsseeap.html', form_number=form_number, form_details=form_details, gst_document=gst_document, pan_document=pan_document)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

# Route for handling Export category
@app.route('/arteamformeseear/<form_number>')
def arteamformeseear(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from database
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        cursor.close()

        if form_details:
            return render_template('arteamformeseear.html', form_number=form_number, form_details=form_details)
        else:
            return "Form not found", 404

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

# Route for handling Export category
@app.route('/arteamformeseeap/<form_number>')
def arteamformeseeap(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from database
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        cursor.close()

        if form_details:
            return render_template('arteamformeseeap.html', form_number=form_number, form_details=form_details)
        else:
            return "Form not found", 404

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

def get_cit_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT cr.request_number, cr.company_name AS customer_company_name, cr.email,
                   cr.category AS customer_category,
                   cr.logged_in_user_email AS customer_logged_in_user_email,
                   fb.titles AS form_titles, fb.name AS form_name, fb.email AS form_email,
                   fb.company_name AS form_company_name, fb.country, fb.state, fb.city,
                   fb.street_address, fb.street_address_2, fb.street_address_3,
                   fb.postal_code, fb.phone_number, fb.mobile_number, fb.gst_number,
                   fb.pan_number, fb.region AS form_region, fb.category AS form_category,
                   fb.form_number AS form_number, fb.request_number,
                   fb.submission_date AS form_submission_date,
                   ms.customer_account_group, ms.company_code, ms.sales_org,
                   ms.distribution_channel, ms.division, ms.name_1, ms.name_2, ms.search_1,
                   ms.search_2_old_customer_code, ms.street_3, ms.street_house_number,
                   ms.street_2, ms.street, ms.street_4,
                   ms.street_5, ms.district, ms.different_city, ms.pin_code, ms.city,
                   ms.country, ms.region, ms.language,
                   ms.telephone_number_1, ms.mobile_number_1, ms.contact_person_1_comments_of_mobile_number,
                   ms.fax, ms.extension, ms.email_1, ms.department_1_notes_of_email,
                   ms.mobile_phone_2, ms.contact_person_2_comments_of_mobile_number, ms.email_2,
                   ms.department_2_notes_of_email, ms.mobile_phone_3, ms.contact_person_3_comments_of_mobile_number,
                   ms.email_3, ms.department_3_notes_of_email, ms.legal_form, ms.bp_type,
                   ms.pan_card, ms.gst_category, ms.gstin_no, ms.annual_sales,
                   ms.currency, ms.sales_year, ms.sales_district, ms.sales_office,
                   ms.sales_group, ms.currency_2, ms.price_group, ms.cust_pric_procedure,
                   ms.order_combination_indicator, ms.delivering_plant, ms.shipping_conditions,
                   ms.underdel_tolerance, ms.overdeliv_tolerance, ms.indicator_customer_is_rebate_relevant,
                   ms.relevant_for_price_determination_id, ms.incoterms, ms.incoterms_location,
                   ms.payment_terms, ms.credit_control_area, ms.acct_assmt_grp_cust,
                   ms.tax_category, ms.tax_category_2, ms.tax_category_3, ms.tax_category_4,
                   ms.agent, ms.agent_code, ms.broker_agent, ms.broker_agent_code,
                   ms.forwarding_agent, ms.forwarding_agent_code, ms.sales_person,
                   ms.sales_person_code, ms.recon_account, ms.sort_key, ms.planning_group,
                   ms.payment_terms_2, ms.payment_methods, ms.dunning_procedure,
                   ms.relationship_category,  
                   ms.form_number AS ms_form_number,
                   ms.request_number AS ms_request_number, ms.submission_date AS ms_submission_date,
                   ms.submit_timestamp AS ms_submit_timestamp,
                   ms.sap_number AS ms_sap_number,
                   cmd.form_number AS changes_done_form_number, cmd.date_changed AS changes_done_date,
                   crf.details AS changes_requested_details,
                   crf.form_number AS changes_requested_form_number,
                   cad.form_number AS changes_done_it_form_number, cad.date_changed AS changes_done_it_date,
                   crt.details AS changes_requested_it_details,
                   crt.form_number AS changes_requested_it_form_number,
                   af.form_number AS changes_done_accounts_form_number,
                   itf.form_number AS changes_done_itf_form_number,
                   ite.form_number AS changes_done_ite_form_number
            FROM customerrequested cr
            LEFT JOIN formsbyc fb ON cr.request_number = fb.request_number
            LEFT JOIN marketing_submission ms ON fb.form_number = ms.form_number
            LEFT JOIN changesdoneby_marketing cmd ON fb.form_number = cmd.form_number
            LEFT JOIN changesrequestedfromar crf ON fb.form_number = crf.form_number
            LEFT JOIN changesdoneby_ar cad ON fb.form_number = cad.form_number
            LEFT JOIN changes_requestedtoar crt ON fb.form_number = crt.form_number
            LEFT JOIN account_final af ON fb.form_number = af.form_number
            LEFT JOIN it_final itf ON fb.form_number = itf.form_number
            LEFT JOIN it_excel_export ite ON fb.form_number = ite.form_number
            WHERE af.form_number = ms.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

def get_citv_form_details():
    try:
        cursor = db.cursor(dictionary=True)

        query = """
            SELECT vr.request_number, vr.company_name AS customer_company_name, vr.email,
                   vr.category AS customer_category,
                   vr.logged_in_user_email AS customer_logged_in_user_email,
                   fv.titles AS form_titles, fv.name AS form_name, fv.email AS form_email,
                   fv.company_name AS form_company_name, fv.country, fv.state, fv.city,
                   fv.street_address, fv.street_address_2, fv.street_address_3,
                   fv.postal_code, fv.phone_number, fv.mobile_number, fv.gst_number,
                   fv.pan_number, fv.region AS form_region, fv.category AS form_category,
                   fv.form_number AS form_number, fv.request_number,
                   fv.submission_date AS form_submission_date,
                   ps.partner_role, ps.creation_group, ps.titles, ps.name_org1, ps.name_org2, ps.postal_code, 
                   ps.city, ps.city_2, ps.country, ps.region, ps.timezone, ps.house_number, ps.saluation, 
                   ps.sort_text1, ps.sort_text2, ps.street_2, ps.street_3, ps.street, ps.telephoneno, 
                   ps.mobileno, ps.fax_no, ps.email_id, ps.legal_entity, ps.tax_type, ps.tax_number, 
                   ps.bp_type, ps.social_insurance, ps.company_code, ps.recon_account, ps.sort_key, 
                   ps.mmse_type, ps.certificate_date, ps.payment_term, ps.check_double_invoice, ps.payment_method, 
                   ps.p_org, ps.payment_terms, ps.incoterm, ps.incoterm_location, ps.g_r_iv_verification, 
                   ps.sr_based_iv_verificvcation, ps.purchase_group, ps.schema_group, ps.type_of_business, 
                   ps.pan_no, ps.vendor_class, ps.order_currency, ps.bank_country_key, ps.bank_key, ps.bank_acc_no, 
                   ps.account_holder_name,
                   ps.form_number AS ps_form_number,
                   ps.request_number AS ps_request_number, ps.submission_date AS ps_submission_date,
                   ps.submit_timestamp AS ps_submit_timestamp,
                   cmp.form_number AS changes_done_form_number, cmp.date_changed AS changes_done_date,
                   crfp.details AS changes_requested_details,
                   crfp.form_number AS changes_requested_form_number,
                   cap.form_number AS changes_done_it_form_number, cap.date_changed AS changes_done_it_date,
                   crp.details AS changes_requested_it_details,
                   crp.form_number AS changes_requested_it_form_number,
                   apf.form_number AS changes_done_accounts_form_number,
                   itv.form_number AS changes_done_itv_form_number,
                   itve.form_number AS changes_done_itve_form_number
            FROM vendorrequested vr
            LEFT JOIN formsbyv fv ON vr.request_number = fv.request_number
            LEFT JOIN purchase_submission ps ON fv.form_number = ps.form_number
            LEFT JOIN changesdoneby_purchase cmp ON fv.form_number = cmp.form_number
            LEFT JOIN changesrequestedfromap crfp ON fv.form_number = crfp.form_number
            LEFT JOIN changesdoneby_ap cap ON fv.form_number = cap.form_number
            LEFT JOIN changes_requestedtoap crp ON fv.form_number = crp.form_number
            LEFT JOIN accountp_final apf ON fv.form_number = apf.form_number
            LEFT JOIN itv_final itv ON fv.form_number = itv.form_number
            LEFT JOIN itv_excel_export itve ON fv.form_number = itve.form_number
            WHERE apf.form_number = ps.form_number
        """
        cursor.execute(query)
        form_details = cursor.fetchall()

        cursor.close()

        return form_details

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return None

    except Exception as e:
        logging.error("Error: %s", e)
        return None

@app.route('/choose', methods=['GET', 'POST'])
def choose():
    if 'username' not in session:
        return redirect(url_for('index'))

    return render_template('choose.html', logged_in_user_email=session.get('username'))

# Route for archeckbyit
@app.route('/archeckbyit')
def archeckbyit():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_cit_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ms_form_number')
            changes_done_ite_form_number = form_detail.get('changes_done_ite_form_number')
            changes_done_itf_form_number = form_detail.get('changes_done_itf_form_number')
            changes_done_it_form_number = form_detail.get('changes_done_it_form_number')
            changes_requested_it_form_number = form_detail.get('changes_requested_it_form_number')

            if form_number is None:
                logging.error("Missing 'ms_form_number' in form_detail: %s", form_detail)
                continue

            if changes_done_itf_form_number and changes_requested_it_form_number:
                form_detail['approved_status'] = 'Details Sent to Hana'
            elif changes_done_itf_form_number:
                form_detail['approved_status'] = 'Details Sent to Hana'
            else:
                form_detail['approved_status'] = ''

            form_detail['form_number_exists_in_it_final'] = bool(changes_done_itf_form_number)

            if changes_done_it_form_number and changes_requested_it_form_number:
                form_detail['status_it_details'] = 'Changes Done'
            elif changes_requested_it_form_number:
                form_detail['status_it_details'] = 'Still Pending'
            else:
                form_detail['status_it_details'] = ''

            form_detail['form_number_exists_in_changesdoneby_marketing'] = bool(changes_done_it_form_number)

            if changes_done_ite_form_number:
                form_detail['status_ite_details'] = 'Excel Exported'
            else:
                form_detail['status_ite_details'] = ''

            form_detail['form_number_exists_in_ite_final'] = bool(changes_done_ite_form_number)

        # Render the page after processing all form details
        return render_template('archeckbyit.html', logged_in_user_email=logged_in_user_email,
                               form_details=form_details)

    except Exception as e:
        logging.error("Error in archeckbyit(): %s", e)
        return "An error occurred while fetching form details."

# Route for archeckbyit
@app.route('/apcheckbyit')
def apcheckbyit():
    if 'username' not in session:
        return redirect(url_for('index'))

    logged_in_user_email = session['username']

    try:
        form_details = get_citv_form_details()

        if form_details is None:
            return "An error occurred while fetching form details."

        # Process each form detail to add the 'marketing_changes' field
        for form_detail in form_details:
            form_number = form_detail.get('ps_form_number')
            changes_done_itve_form_number = form_detail.get('changes_done_itve_form_number')
            changes_done_itv_form_number = form_detail.get('changes_done_itv_form_number')
            changes_done_it_form_number = form_detail.get('changes_done_it_form_number')
            changes_requested_it_form_number = form_detail.get('changes_requested_it_form_number')

            if form_number is None:
                logging.error("Missing 'ps_form_number' in form_detail: %s", form_detail)
                continue

            if changes_done_itv_form_number and changes_requested_it_form_number:
                form_detail['approved_status'] = 'Details Sent to Hana'
            elif changes_done_itv_form_number:
                form_detail['approved_status'] = 'Details Sent to Hana'
            else:
                form_detail['approved_status'] = ''

            form_detail['form_number_exists_in_itv_final'] = bool(changes_done_itv_form_number)

            if changes_done_it_form_number and changes_requested_it_form_number:
                form_detail['status_it_details'] = 'Changes Done'
            elif changes_requested_it_form_number:
                form_detail['status_it_details'] = 'Still Pending'
            else:
                form_detail['status_it_details'] = ''

            form_detail['form_number_exists_in_changesdoneby_purchase'] = bool(changes_done_it_form_number)

            if changes_done_itve_form_number:
                form_detail['status_ite_details'] = 'Excel Exported'
            else:
                form_detail['status_ite_details'] = ''

            form_detail['form_number_exists_in_itve_final'] = bool(changes_done_itve_form_number)

        # Render the page after processing all form details
        return render_template('apcheckbyit.html', logged_in_user_email=logged_in_user_email,
                               form_details=form_details)

    except Exception as e:
        logging.error("Error in apcheckbyit(): %s", e)
        return "An error occurred while fetching form details."

@app.route('/itteamformds/<form_number>')
def itteamformds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyc WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        cursor.close()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents[
                'gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents[
                'pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        return render_template('itteamformds.html', form_number=form_number, form_details=form_details,
                               gst_document=gst_document, pan_document=pan_document)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."


@app.route('/itteamformvds/<form_number>')
def itteamformvds(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from the marketing_submission table
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        if not form_details:
            cursor.close()
            return "Form not found", 404

        # Fetch GST and PAN documents from formsbyc table
        query = "SELECT gst_document, pan_document FROM formsbyv WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        documents = cursor.fetchone()

        cursor.close()

        if documents:
            gst_document = base64.b64encode(documents['gst_document']).decode('utf-8') if documents[
                'gst_document'] else None
            pan_document = base64.b64encode(documents['pan_document']).decode('utf-8') if documents[
                'pan_document'] else None
        else:
            gst_document = None
            pan_document = None

        return render_template('itteamformvds.html', form_number=form_number, form_details=form_details,
                               gst_document=gst_document, pan_document=pan_document)

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

# Route for handling Export category
@app.route('/itteamforme/<form_number>')
def itteamforme(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from database
        query = "SELECT * FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        cursor.close()

        if form_details:
            return render_template('itteamforme.html', form_number=form_number, form_details=form_details)
        else:
            return "Form not found", 404

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."


# Route for handling Export category
@app.route('/itteamformve/<form_number>')
def itteamformve(form_number):
    try:
        cursor = db.cursor(dictionary=True)

        # Fetch form details based on form_number from database
        query = "SELECT * FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query, (form_number,))
        form_details = cursor.fetchone()

        cursor.close()

        if form_details:
            return render_template('itteamformve.html', form_number=form_number, form_details=form_details)
        else:
            return "Form not found", 404

    except mysql.connector.Error as e:
        # Log MySQL errors
        app.logger.error("MySQL Error: %s", e)
        return "An error occurred while fetching form details."

    except Exception as e:
        # Log other unexpected errors
        app.logger.error("Error: %s", e)
        return "An unexpected error occurred."

@app.route('/submit_itt_form_details', methods=['POST'])
def submit_itt_form_details():
    form_number = request.form['form_number']
    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')
    submit_action = request.form.get('submit_action')

    try:
        cursor = db.cursor()

        # Check if form_number already exists in it_final table
        query_check_final = "SELECT form_number FROM it_final WHERE form_number = %s"
        cursor.execute(query_check_final, (form_number,))
        existing_final = cursor.fetchone()

        # Check if form_number already exists in changes_requestedtoar table
        query_check_changes_requested = "SELECT form_number, details FROM changes_requestedtoar WHERE form_number = %s"
        cursor.execute(query_check_changes_requested, (form_number,))
        existing_changes_requested = cursor.fetchone()

        # Check if form_number already exists in changesdoneby_ar table
        query_check_changes_done = "SELECT form_number FROM changesdoneby_ar WHERE form_number = %s"
        cursor.execute(query_check_changes_done, (form_number,))
        existing_changes_done = cursor.fetchone()

        # Check if form_number already exists in it_excel_export table
        query_check_export = "SELECT form_number FROM it_excel_export WHERE form_number = %s"
        cursor.execute(query_check_export, (form_number,))
        existing_export = cursor.fetchone()

        # Check if sap_number exists for the given form_number
        query_check_sap_number = "SELECT sap_number FROM marketing_submission WHERE form_number = %s"
        cursor.execute(query_check_sap_number, (form_number,))
        sap_number_row = cursor.fetchone()

        # Check if the fetched sap_number is not None or empty
        sap_number_exists = sap_number_row is not None and sap_number_row[0] is not None and sap_number_row[
            0].strip() != ""

        # Log the result of the SAP number check
        logging.debug(f"Checked SAP number for form_number {form_number}: Exists = {sap_number_exists}")

        # Handle 'submit' action
        if submit_action == 'submit':
            if (existing_changes_done and existing_changes_requested) or (
                    not existing_changes_done and not existing_changes_requested):
                if not existing_final:
                    query_insert_final = "INSERT INTO it_final (form_number, date_changed) VALUES (%s, %s)"
                    cursor.execute(query_insert_final, (form_number, date_changed))
                    db.commit()
                return redirect(url_for('archeckbyit'))
            else:
                flash('There are still pending changes from the marketing team so the data will not submit.', 'danger')
                return redirect(url_for('archeckbyit'))

        # Handle 'changes_required' action
        elif submit_action == 'changes_required':
            if sap_number_exists:
                logging.debug(f"SAP Number exists for form_number: {form_number}")
                flash('The Changes Required button is disabled because the details are submitted in Hana! and the SAP number is already received.', 'warning')
                return redirect(url_for('archeckbyit'))

            if existing_final:
                logging.debug("Form number exists in it_final, preventing changes required.")
                flash('Once the details are submitted in Hana!, the Changes Required button will not work.', 'warning')
                return redirect(url_for('archeckbyit'))

            if existing_changes_requested:
                current_details = existing_changes_requested[1] + ', ' if existing_changes_requested[1] else ''
                updated_details = current_details + changes_required
                logging.debug(f"Updating details in changes_requestedtoar: {updated_details}")
                query_update_changes = "UPDATE changes_requestedtoar SET details = %s WHERE form_number = %s"
                cursor.execute(query_update_changes, (updated_details, form_number))
                db.commit()

                query_delete_final = "DELETE FROM it_final WHERE form_number = %s"
                cursor.execute(query_delete_final, (form_number,))
                db.commit()

                query_delete_changes_done = "DELETE FROM changesdoneby_ar WHERE form_number = %s"
                cursor.execute(query_delete_changes_done, (form_number,))
                db.commit()

            else:
                logging.debug(f"Inserting new record into changes_requestedtoar with details: {changes_required}")
                query_insert_changes = "INSERT INTO changes_requestedtoar (form_number, details) VALUES (%s, %s)"
                cursor.execute(query_insert_changes, (form_number, changes_required))
                db.commit()

                query_delete_final = "DELETE FROM it_final WHERE form_number = %s"
                cursor.execute(query_delete_final, (form_number,))
                db.commit()

                query_delete_changes_done = "DELETE FROM changesdoneby_ar WHERE form_number = %s"
                cursor.execute(query_delete_changes_done, (form_number,))
                db.commit()


        elif submit_action == 'export_to_excel':

            # Check if the export can proceed based on the same condition
            if (existing_changes_done and existing_changes_requested) or (
                    not existing_changes_done and not existing_changes_requested):
                # Form number is either present in both tables or not present in both tables
                # Proceed with exporting to Excel

                # Fetch all columns from marketing_submission table based on form_number
                query_fetch_data = """
                SELECT
                    1 as s_no,
                    COALESCE(TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(customer_account_group, '(', -1), ')', 1)),'') as customer_account_group,
                    COALESCE(SUBSTRING_INDEX(company_code, ' - ', 1), '') as company_code,
                    COALESCE(SUBSTRING_INDEX(sales_org, ' - ', 1), '') as sales_org,
                    COALESCE(SUBSTRING_INDEX(distribution_channel, ' - ', 1), '') as distribution_channel,
                    COALESCE(SUBSTRING_INDEX(division, ' - ', 1), '') as division,
                    COALESCE(SUBSTRING_INDEX(titles, ' - ', 1), '') as titles,
                    COALESCE(SUBSTRING_INDEX(name_1, ' - ', 1), '') as name_1,
                    COALESCE(SUBSTRING_INDEX(name_2, ' - ', 1), '') as name_2,
                    COALESCE(SUBSTRING_INDEX(search_1, ' - ', 1), '') as search_1,
                    COALESCE(SUBSTRING_INDEX(search_2_old_customer_code, ' - ', 1), '') as search_2_old_customer_code,
                    COALESCE(street_3, '') as street_3,
                    COALESCE(street_house_number, '') as street_house_number,
                    COALESCE(street_2, '') as street_2,
                    COALESCE(street, '') as street,
                    COALESCE(street_4, '') as street_4,
                    COALESCE(street_5, '') as street_5,
                    COALESCE(district, '') as district,
                    COALESCE(different_city, '') as different_city,
                    COALESCE(pin_code, '') as pin_code,
                    COALESCE(city, '') as city,
                    COALESCE(country, '') as country,
                    COALESCE(region, '') as region,
                    COALESCE(language, '') as language,
                    COALESCE(telephone_number_1, '') as telephone_number_1,
                    COALESCE(mobile_number_1, '') as mobile_number_1,
                    COALESCE(contact_person_1_comments_of_mobile_number, '') as contact_person_1_comments_of_mobile_number,
                    COALESCE(fax, '') as fax,
                    COALESCE(extension, '') as extension,
                    COALESCE(email_1, '') as email_1,
                    COALESCE(department_1_notes_of_email, '') as department_1_notes_of_email,
                    COALESCE(mobile_phone_2, '') as mobile_phone_2,
                    COALESCE(contact_person_2_comments_of_mobile_number, '') as contact_person_2_comments_of_mobile_number,
                    COALESCE(email_2, '') as email_2,
                    COALESCE(department_2_notes_of_email, '') as department_2_notes_of_email,
                    COALESCE(mobile_phone_3, '') as mobile_phone_3,
                    COALESCE(contact_person_3_comments_of_mobile_number, '') as contact_person_3_comments_of_mobile_number,
                    COALESCE(email_3, '') as email_3,
                    COALESCE(department_3_notes_of_email, '') as department_3_notes_of_email,
                    COALESCE(SUBSTRING_INDEX(legal_form, ' - ', 1), '') as legal_form,
                    COALESCE(SUBSTRING_INDEX(bp_type, ' - ', 1), '') as bp_type,
                    COALESCE(pan_card, '') as pan_card,
                    COALESCE(gst_category, '') as gst_category,
                    COALESCE(gstin_no, '') as gstin_no,
                    COALESCE(annual_sales, '') as annual_sales,
                    COALESCE(currency, '') as currency,
                    COALESCE(sales_year, '') as sales_year,
                    COALESCE(sales_district, '') as sales_district,
                    COALESCE(SUBSTRING_INDEX(sales_office, ' - ', 1), '') as sales_office,
                    COALESCE(SUBSTRING_INDEX(sales_group, ' - ', 1), '') as sales_group,
                    COALESCE(currency_2, '') as currency_2,
                    COALESCE(price_group, '') as price_group,
                    COALESCE(cust_pric_procedure, '') as cust_pric_procedure,
                    COALESCE(order_combination_indicator, '') as order_combination_indicator,
                    COALESCE(SUBSTRING_INDEX(delivering_plant, ' - ', 1), '') as delivering_plant,
                    COALESCE(shipping_conditions, '') as shipping_conditions,
                    COALESCE(underdel_tolerance, '') as underdel_tolerance,
                    COALESCE(overdeliv_tolerance, '') as overdeliv_tolerance,
                    COALESCE(indicator_customer_is_rebate_relevant, '') as indicator_customer_is_rebate_relevant,
                    COALESCE(relevant_for_price_determination_id, '') as relevant_for_price_determination_id,
                    COALESCE(SUBSTRING_INDEX(incoterms, ' - ', 1), '') as incoterms,
                    COALESCE(incoterms_location, '') as incoterms_location,
                    COALESCE(SUBSTRING_INDEX(payment_terms, ' - ', 1), '') as payment_terms,
                    COALESCE(SUBSTRING_INDEX(credit_control_area, ' - ', 1), '') as credit_control_area,
                    COALESCE(acct_assmt_grp_cust, '') as acct_assmt_grp_cust,
                    COALESCE(tax_category, '') as tax_category,
                    COALESCE(tax_category_2, '') as tax_category_2,
                    COALESCE(tax_category_3, '') as tax_category_3,
                    COALESCE(tax_category_4, '') as tax_category_4,
                    COALESCE(agent, '') as agent,
                    COALESCE(agent_code, '') as agent_code,
                    COALESCE(broker_agent, '') as broker_agent,
                    COALESCE(broker_agent_code, '') as broker_agent_code,
                    COALESCE(forwarding_agent, '') as forwarding_agent,
                    COALESCE(forwarding_agent_code, '') as forwarding_agent_code,
                    COALESCE(sales_person, '') as sales_person,
                    COALESCE(sales_person_code, '') as sales_person_code,
                    COALESCE(SUBSTRING_INDEX(recon_account, ' - ', 1), '') as recon_account,
                    COALESCE(SUBSTRING_INDEX(sort_key, ' - ', 1), '') as sort_key,
                    COALESCE(SUBSTRING_INDEX(planning_group, ' - ', 1), '') as planning_group,
                    COALESCE(SUBSTRING_INDEX(payment_terms_2, ' - ', 1), '') as payment_terms_2,
                    COALESCE(SUBSTRING_INDEX(payment_methods, ' - ', 1), '') as payment_methods,
                    COALESCE(dunning_procedure, '') as dunning_procedure,
                    COALESCE(relationship_category, '') as relationship_category
                FROM
                    marketing_submission
                WHERE
                    form_number = %s
                """
                cursor.execute(query_fetch_data, (form_number,))
                form_data = cursor.fetchall()

                if not form_data:
                    return "Form not found", 404

                # Check if form_number already exists in it_excel_export table
                query_check_export = "SELECT form_number FROM it_excel_export WHERE form_number = %s"
                cursor.execute(query_check_export, (form_number,))
                existing_export = cursor.fetchone()

                if not existing_export:
                    # Insert current_date and form_number into it_excel_export if not already present
                    query_insert_export = "INSERT INTO it_excel_export (form_number, date_changed) VALUES (%s, %s)"
                    cursor.execute(query_insert_export, (form_number, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    db.commit()

                # Create a DataFrame with the fetched data
                df = pd.DataFrame(form_data, columns=[
                    'SR NO', 'CUSTOMER ACCOUNT GROUP', 'COMPANY CODE', 'SALES ORG.', 'DISTR. CHANNEL',
                    'DIVISION', 'TITLES', 'NAME1', 'NAME2', 'SEARCH 1', 'SEARCH 2 (OLD CUSTOMER CODE)',
                    'STREET 3', 'STREET / HOUSE NUMBER', 'STREET 2', 'STREET', 'STREET4', 'STREET5',
                    'DISTRICT', 'DIFFERENT CITY', 'PIN CODE', 'CITY', 'COUNTRY', 'REGION', 'LANGUANGE',
                    'TELPHONE NUMBER 1', 'MOBILE NUMBER 1', 'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)',
                    'FAX', 'EXTENSION', 'EMAIL 1', 'DEPARTMENT 1 (NOTES OF E-MAIL)', 'MOBILE PHONE-2',
                    'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)', 'EMAIL 2', 'DEPARTMENT 1 (NOTES OF E-MAIL)',
                    'MOBILE PHONE-3', 'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)', 'EMAIL 3',
                    'DEPARTMENT 3 (NOTES OF E-MAIL)', 'LEGAL FORM', 'BP TYPE', 'PAN CARD', 'GST CATEGORY',
                    'GSTIN NO', 'ANNUAL SALES', 'CURRENCY', 'SALES YEAR', 'SALES DISTRICT', 'SALES OFFICE',
                    'SALES GROUP', 'CURRENCY', 'PRICE GROUP', 'CUST.PRIC.PROCEDURE', 'ORDER COMBINATION INDICATOR',
                    'DELIVERING PLANT', 'SHIPPING CONDITIONS', 'UNDERDEL. TOLERANCE', 'OVERDELIV. TOLERANCE',
                    'INDICATOR: CUSTOMER IS REBATE-RELEVANT', 'RELEVANT FOR PRICE DETERMINATION ID', 'INCOTERMS',
                    'INCOTERMS LOCATION 1', 'PAYMENT TERMS', 'CREDIT CONTROL AREA', 'ACCT ASSMT GRP CUST.',
                    'TAX CATEGRY', 'TAX CATEGRY', 'TAX CATEGRY', 'TAX CATEGRY', 'AGENT', 'AGENT-CODE',
                    'BROKER AGENT', 'BROKER AGENT-CODE', 'FORWARDING AGENT', 'FORWARDING AGENT-CODE',
                    'SALES PERSON', 'SALES PERSON-CODE', 'RECON ACCOUNT', 'SORT KEY', 'PLANNING GROUP',
                    'PAYMENT TERMS', 'PAYMENT METHODS', 'DUNNING PROCEDURE', 'RELATIONSHIP CATEGORY'
                ])
                # Swap values between street_2 and street_3 columns
                df['STREET 2'], df['STREET 3'] = df['STREET 3'], df['STREET 2']

                # Replace 'None' values with empty string ''
                df.replace(to_replace='None', value='', inplace=True)

                # Create an in-memory Excel file
                output = io.BytesIO()
                writer = pd.ExcelWriter(output, engine='xlsxwriter')
                df.to_excel(writer, index=False, sheet_name='Sheet1')
                writer.close()
                output.seek(0)

                # Send the Excel file as a downloadable attachment
                return send_file(output, download_name='export.xlsx', as_attachment=True)

            else:
                # Show error if form number is not in the required state for export
                flash('There are still pending changes from the marketing team so excel cannot be exported.', 'danger')
                return redirect(url_for('archeckbyit'))

        cursor.close()

        return redirect(url_for('archeckbyit'))

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return "An error occurred while submitting the form.", 500

    except Exception as e:
        logging.error("Error: %s", e)
        return "An unexpected error occurred.", 500

@app.route('/submit_ittv_form_details', methods=['POST'])
def submit_ittv_form_details():
    form_number = request.form['form_number']
    date_changed = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    changes_required = request.form.get('changes_required')
    submit_action = request.form.get('submit_action')

    try:
        cursor = db.cursor()

        # Check if form_number already exists in it_final table
        query_check_final = "SELECT form_number FROM itv_final WHERE form_number = %s"
        cursor.execute(query_check_final, (form_number,))
        existing_final = cursor.fetchone()

        # Check if form_number already exists in changes_requestedtoar table
        query_check_changes_requested = "SELECT form_number, details FROM changes_requestedtoap WHERE form_number = %s"
        cursor.execute(query_check_changes_requested, (form_number,))
        existing_changes_requested = cursor.fetchone()

        # Check if form_number already exists in changesdoneby_ar table
        query_check_changes_done = "SELECT form_number FROM changesdoneby_ap WHERE form_number = %s"
        cursor.execute(query_check_changes_done, (form_number,))
        existing_changes_done = cursor.fetchone()

        # Check if form_number already exists in it_excel_export table
        query_check_export = "SELECT form_number FROM itv_excel_export WHERE form_number = %s"
        cursor.execute(query_check_export, (form_number,))
        existing_export = cursor.fetchone()

        # Check if sap_number exists for the given form_number
        query_check_sap_number = "SELECT sap_number FROM purchase_submission WHERE form_number = %s"
        cursor.execute(query_check_sap_number, (form_number,))
        sap_number_row = cursor.fetchone()

        # Check if the fetched sap_number is not None or empty
        sap_number_exists = sap_number_row is not None and sap_number_row[0] is not None and sap_number_row[
            0].strip() != ""

        # Log the result of the SAP number check
        logging.debug(f"Checked SAP number for form_number {form_number}: Exists = {sap_number_exists}")

        # Handle 'submit' action
        if submit_action == 'submit':
            if (existing_changes_done and existing_changes_requested) or (
                    not existing_changes_done and not existing_changes_requested):
                if not existing_final:
                    query_insert_final = "INSERT INTO itv_final (form_number, date_changed) VALUES (%s, %s)"
                    cursor.execute(query_insert_final, (form_number, date_changed))
                    db.commit()
                return redirect(url_for('apcheckbyit'))
            else:
                flash('There are still pending changes from the marketing team so the data will not submit.', 'danger')
                return redirect(url_for('apcheckbyit'))

        # Handle 'changes_required' action
        elif submit_action == 'changes_required':
            if sap_number_exists:
                logging.debug(f"SAP Number exists for form_number: {form_number}")
                flash('The Changes Required button is disabled because the details are submitted in Hana! and the SAP number is already received.', 'warning')
                return redirect(url_for('apcheckbyit'))

            if existing_final:
                logging.debug("Form number exists in itv_final, preventing changes required.")
                flash('Once the details are submitted in Hana!, the Changes Required button will not work.', 'warning')
                return redirect(url_for('apcheckbyit'))

            if existing_changes_requested:
                current_details = existing_changes_requested[1] + ', ' if existing_changes_requested[1] else ''
                updated_details = current_details + changes_required
                logging.debug(f"Updating details in changes_requestedtoap: {updated_details}")
                query_update_changes = "UPDATE changes_requestedtoap SET details = %s WHERE form_number = %s"
                cursor.execute(query_update_changes, (updated_details, form_number))
                db.commit()

                query_delete_final = "DELETE FROM itv_final WHERE form_number = %s"
                cursor.execute(query_delete_final, (form_number,))
                db.commit()

                query_delete_changes_done = "DELETE FROM changesdoneby_ap WHERE form_number = %s"
                cursor.execute(query_delete_changes_done, (form_number,))
                db.commit()

            else:
                logging.debug(f"Inserting new record into changes_requestedtoap with details: {changes_required}")
                query_insert_changes = "INSERT INTO changes_requestedtoap (form_number, details) VALUES (%s, %s)"
                cursor.execute(query_insert_changes, (form_number, changes_required))
                db.commit()

                query_delete_final = "DELETE FROM itv_final WHERE form_number = %s"
                cursor.execute(query_delete_final, (form_number,))
                db.commit()

                query_delete_changes_done = "DELETE FROM changesdoneby_ap WHERE form_number = %s"
                cursor.execute(query_delete_changes_done, (form_number,))
                db.commit()


        elif submit_action == 'export_to_excel':

            # Check if the export can proceed based on the same condition
            if (existing_changes_done and existing_changes_requested) or (
                    not existing_changes_done and not existing_changes_requested):
                # Form number is either present in both tables or not present in both tables
                # Proceed with exporting to Excel

                # Fetch all columns from marketing_submission table based on form_number
                query_fetch_data = """
                SELECT
                    1 as s_no,
                    COALESCE(TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(customer_account_group, '(', -1), ')', 1)),'') as customer_account_group,
                    COALESCE(SUBSTRING_INDEX(company_code, ' - ', 1), '') as company_code,
                    COALESCE(SUBSTRING_INDEX(sales_org, ' - ', 1), '') as sales_org,
                    COALESCE(SUBSTRING_INDEX(distribution_channel, ' - ', 1), '') as distribution_channel,
                    COALESCE(SUBSTRING_INDEX(division, ' - ', 1), '') as division,
                    COALESCE(SUBSTRING_INDEX(titles, ' - ', 1), '') as titles,
                    COALESCE(SUBSTRING_INDEX(name_1, ' - ', 1), '') as name_1,
                    COALESCE(SUBSTRING_INDEX(name_2, ' - ', 1), '') as name_2,
                    COALESCE(SUBSTRING_INDEX(search_1, ' - ', 1), '') as search_1,
                    COALESCE(SUBSTRING_INDEX(search_2_old_customer_code, ' - ', 1), '') as search_2_old_customer_code,
                    COALESCE(street_3, '') as street_3,
                    COALESCE(street_house_number, '') as street_house_number,
                    COALESCE(street_2, '') as street_2,
                    COALESCE(street, '') as street,
                    COALESCE(street_4, '') as street_4,
                    COALESCE(street_5, '') as street_5,
                    COALESCE(district, '') as district,
                    COALESCE(different_city, '') as different_city,
                    COALESCE(pin_code, '') as pin_code,
                    COALESCE(city, '') as city,
                    COALESCE(country, '') as country,
                    COALESCE(region, '') as region,
                    COALESCE(language, '') as language,
                    COALESCE(telephone_number_1, '') as telephone_number_1,
                    COALESCE(mobile_number_1, '') as mobile_number_1,
                    COALESCE(contact_person_1_comments_of_mobile_number, '') as contact_person_1_comments_of_mobile_number,
                    COALESCE(fax, '') as fax,
                    COALESCE(extension, '') as extension,
                    COALESCE(email_1, '') as email_1,
                    COALESCE(department_1_notes_of_email, '') as department_1_notes_of_email,
                    COALESCE(mobile_phone_2, '') as mobile_phone_2,
                    COALESCE(contact_person_2_comments_of_mobile_number, '') as contact_person_2_comments_of_mobile_number,
                    COALESCE(email_2, '') as email_2,
                    COALESCE(department_2_notes_of_email, '') as department_2_notes_of_email,
                    COALESCE(mobile_phone_3, '') as mobile_phone_3,
                    COALESCE(contact_person_3_comments_of_mobile_number, '') as contact_person_3_comments_of_mobile_number,
                    COALESCE(email_3, '') as email_3,
                    COALESCE(department_3_notes_of_email, '') as department_3_notes_of_email,
                    COALESCE(SUBSTRING_INDEX(legal_form, ' - ', 1), '') as legal_form,
                    COALESCE(SUBSTRING_INDEX(bp_type, ' - ', 1), '') as bp_type,
                    COALESCE(pan_card, '') as pan_card,
                    COALESCE(gst_category, '') as gst_category,
                    COALESCE(gstin_no, '') as gstin_no,
                    COALESCE(annual_sales, '') as annual_sales,
                    COALESCE(currency, '') as currency,
                    COALESCE(sales_year, '') as sales_year,
                    COALESCE(sales_district, '') as sales_district,
                    COALESCE(SUBSTRING_INDEX(sales_office, ' - ', 1), '') as sales_office,
                    COALESCE(SUBSTRING_INDEX(sales_group, ' - ', 1), '') as sales_group,
                    COALESCE(currency_2, '') as currency_2,
                    COALESCE(price_group, '') as price_group,
                    COALESCE(cust_pric_procedure, '') as cust_pric_procedure,
                    COALESCE(order_combination_indicator, '') as order_combination_indicator,
                    COALESCE(SUBSTRING_INDEX(delivering_plant, ' - ', 1), '') as delivering_plant,
                    COALESCE(shipping_conditions, '') as shipping_conditions,
                    COALESCE(underdel_tolerance, '') as underdel_tolerance,
                    COALESCE(overdeliv_tolerance, '') as overdeliv_tolerance,
                    COALESCE(indicator_customer_is_rebate_relevant, '') as indicator_customer_is_rebate_relevant,
                    COALESCE(relevant_for_price_determination_id, '') as relevant_for_price_determination_id,
                    COALESCE(SUBSTRING_INDEX(incoterms, ' - ', 1), '') as incoterms,
                    COALESCE(incoterms_location, '') as incoterms_location,
                    COALESCE(SUBSTRING_INDEX(payment_terms, ' - ', 1), '') as payment_terms,
                    COALESCE(SUBSTRING_INDEX(credit_control_area, ' - ', 1), '') as credit_control_area,
                    COALESCE(acct_assmt_grp_cust, '') as acct_assmt_grp_cust,
                    COALESCE(tax_category, '') as tax_category,
                    COALESCE(tax_category_2, '') as tax_category_2,
                    COALESCE(tax_category_3, '') as tax_category_3,
                    COALESCE(tax_category_4, '') as tax_category_4,
                    COALESCE(agent, '') as agent,
                    COALESCE(agent_code, '') as agent_code,
                    COALESCE(broker_agent, '') as broker_agent,
                    COALESCE(broker_agent_code, '') as broker_agent_code,
                    COALESCE(forwarding_agent, '') as forwarding_agent,
                    COALESCE(forwarding_agent_code, '') as forwarding_agent_code,
                    COALESCE(sales_person, '') as sales_person,
                    COALESCE(sales_person_code, '') as sales_person_code,
                    COALESCE(SUBSTRING_INDEX(recon_account, ' - ', 1), '') as recon_account,
                    COALESCE(SUBSTRING_INDEX(sort_key, ' - ', 1), '') as sort_key,
                    COALESCE(SUBSTRING_INDEX(planning_group, ' - ', 1), '') as planning_group,
                    COALESCE(SUBSTRING_INDEX(payment_terms_2, ' - ', 1), '') as payment_terms_2,
                    COALESCE(SUBSTRING_INDEX(payment_methods, ' - ', 1), '') as payment_methods,
                    COALESCE(dunning_procedure, '') as dunning_procedure,
                    COALESCE(relationship_category, '') as relationship_category
                FROM
                    marketing_submission
                WHERE
                    form_number = %s
                """
                cursor.execute(query_fetch_data, (form_number,))
                form_data = cursor.fetchall()

                if not form_data:
                    return "Form not found", 404

                # Check if form_number already exists in it_excel_export table
                query_check_export = "SELECT form_number FROM itv_excel_export WHERE form_number = %s"
                cursor.execute(query_check_export, (form_number,))
                existing_export = cursor.fetchone()

                if not existing_export:
                    # Insert current_date and form_number into it_excel_export if not already present
                    query_insert_export = "INSERT INTO itv_excel_export (form_number, date_changed) VALUES (%s, %s)"
                    cursor.execute(query_insert_export, (form_number, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    db.commit()

                # Create a DataFrame with the fetched data
                df = pd.DataFrame(form_data, columns=[
                    'SR NO', 'CUSTOMER ACCOUNT GROUP', 'COMPANY CODE', 'SALES ORG.', 'DISTR. CHANNEL',
                    'DIVISION', 'TITLES', 'NAME1', 'NAME2', 'SEARCH 1', 'SEARCH 2 (OLD CUSTOMER CODE)',
                    'STREET 3', 'STREET / HOUSE NUMBER', 'STREET 2', 'STREET', 'STREET4', 'STREET5',
                    'DISTRICT', 'DIFFERENT CITY', 'PIN CODE', 'CITY', 'COUNTRY', 'REGION', 'LANGUANGE',
                    'TELPHONE NUMBER 1', 'MOBILE NUMBER 1', 'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)',
                    'FAX', 'EXTENSION', 'EMAIL 1', 'DEPARTMENT 1 (NOTES OF E-MAIL)', 'MOBILE PHONE-2',
                    'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)', 'EMAIL 2', 'DEPARTMENT 1 (NOTES OF E-MAIL)',
                    'MOBILE PHONE-3', 'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)', 'EMAIL 3',
                    'DEPARTMENT 3 (NOTES OF E-MAIL)', 'LEGAL FORM', 'BP TYPE', 'PAN CARD', 'GST CATEGORY',
                    'GSTIN NO', 'ANNUAL SALES', 'CURRENCY', 'SALES YEAR', 'SALES DISTRICT', 'SALES OFFICE',
                    'SALES GROUP', 'CURRENCY', 'PRICE GROUP', 'CUST.PRIC.PROCEDURE', 'ORDER COMBINATION INDICATOR',
                    'DELIVERING PLANT', 'SHIPPING CONDITIONS', 'UNDERDEL. TOLERANCE', 'OVERDELIV. TOLERANCE',
                    'INDICATOR: CUSTOMER IS REBATE-RELEVANT', 'RELEVANT FOR PRICE DETERMINATION ID', 'INCOTERMS',
                    'INCOTERMS LOCATION 1', 'PAYMENT TERMS', 'CREDIT CONTROL AREA', 'ACCT ASSMT GRP CUST.',
                    'TAX CATEGRY', 'TAX CATEGRY', 'TAX CATEGRY', 'TAX CATEGRY', 'AGENT', 'AGENT-CODE',
                    'BROKER AGENT', 'BROKER AGENT-CODE', 'FORWARDING AGENT', 'FORWARDING AGENT-CODE',
                    'SALES PERSON', 'SALES PERSON-CODE', 'RECON ACCOUNT', 'SORT KEY', 'PLANNING GROUP',
                    'PAYMENT TERMS', 'PAYMENT METHODS', 'DUNNING PROCEDURE', 'RELATIONSHIP CATEGORY'
                ])
                # Swap values between street_2 and street_3 columns
                df['STREET 2'], df['STREET 3'] = df['STREET 3'], df['STREET 2']

                # Replace 'None' values with empty string ''
                df.replace(to_replace='None', value='', inplace=True)

                # Create an in-memory Excel file
                output = io.BytesIO()
                writer = pd.ExcelWriter(output, engine='xlsxwriter')
                df.to_excel(writer, index=False, sheet_name='Sheet1')
                writer.close()
                output.seek(0)

                # Send the Excel file as a downloadable attachment
                return send_file(output, download_name='export.xlsx', as_attachment=True)

            else:
                # Show error if form number is not in the required state for export
                flash('There are still pending changes from the marketing team so excel cannot be exported.', 'danger')
                return redirect(url_for('apcheckbyit'))

        cursor.close()

        return redirect(url_for('apcheckbyit'))

    except mysql.connector.Error as e:
        logging.error("MySQL Error: %s", e)
        return "An error occurred while submitting the form.", 500

    except Exception as e:
        logging.error("Error: %s", e)
        return "An unexpected error occurred.", 500

@app.route('/send_data', methods=['POST'])
def send_data():
    cursor = None
    try:
        data = request.json  # Expecting a list of dictionaries
        logging.info(f"Received payload: {data}")

        if not isinstance(data, list):
            raise ValueError("Expected payload to be a list of dictionaries")

        # Ensure db is properly connected
        if not db:
            raise Exception("Database connection is not initialized")

        cursor = db.cursor()

        responses = []  # Collect responses for each payload
        sap_number_added = False  # Flag to track if SAP number was added
        status_not_s_messages = []  # Collect messages for status not "S"

        # Process each item in the list
        for item in data:
            form_number = item.get('FORMNO')
            payload = [
                {
                'FORMNO': item.get('FORMNO'),
                'KTOKD': item.get('KTOKD'),
                'BUKRS': item.get('BUKRS'),
                'VKORG': item.get('VKORG'),
                'VTWEG': item.get('VTWEG'),
                'SPART': item.get('SPART'),
                'TITLE': item.get('TITLE'),
                'NAME1': item.get('NAME1'),
                'NAME2': item.get('NAME2'),
                'SORTL': item.get('SORTL'),
                'SORT2': item.get('SORT2'),
                'STR_SUPPL2': item.get('STR_SUPPL2'),
                'STREET': item.get('STREET'),
                'STR_SUPPL1': item.get('STR_SUPPL1'),
                'STRAS': item.get('STRAS'),
                'STR_SUPPL3': item.get('STR_SUPPL3'),
                'LOCATION': item.get('LOCATION'),
                'CITY1': item.get('CITY1'),
                'CITY2': item.get('CITY2'),
                'POST_CODE1': item.get('POST_CODE1'),
                'ORT01': item.get('ORT01'),
                'COUNTRY': item.get('COUNTRY'),
                'REGION': item.get('REGION'),
                'LANGU': item.get('LANGU'),
                'TELF1': item.get('TELF1'),
                'TELF2': item.get('TELF2'),
                'CONT_PERSON1': item.get('CONT_PERSON1'),
                'FAX_NUMBER': item.get('FAX_NUMBER'),
                'TEL_EXTENS': item.get('TEL_EXTENS'),
                'AD_SMTPADR': item.get('AD_SMTPADR'),
                'DEPT1': item.get('DEPT1'),
                'MOBILE2': item.get('MOBILE2'),
                'CONT_PERSON2': item.get('CONT_PERSON2'),
                'EMAIL2': item.get('EMAIL2'),
                'DEPT2': item.get('DEPT2'),
                'MOBILE3': item.get('MOBILE3'),
                'CONT_PERSON3': item.get('CONT_PERSON3'),
                'EMAIL3': item.get('EMAIL3'),
                'DEPT3': item.get('DEPT3'),
                'LEGAL_ENTY': item.get('LEGAL_ENTY'),
                'BPTYPE': item.get('BPTYPE'),
                'J_1IPANNO': item.get('J_1IPANNO'),
                'GST_CATG': item.get('GST_CATG'),
                'STCD3': item.get('STCD3'),
                'UMSA1': item.get('UMSA1'),
                'WAERS': item.get('WAERS'),
                'UMJAH': item.get('UMJAH'),
                'SALES_DIST': item.get('SALES_DIST'),
                'VKBUR': item.get('VKBUR'),
                'VKGRP': item.get('VKGRP'),
                'WAERS2': item.get('WAERS2'),
                'KONDA': item.get('KONDA'),
                'KALKS': item.get('KALKS'),
                'KZAZU': item.get('KZAZU'),
                'VWERK': item.get('VWERK'),
                'VSBED': item.get('VSBED'),
                'UNTTO': item.get('UNTTO'),
                'UEBTO': item.get('UEBTO'),
                'BOKRE': item.get('BOKRE'),
                'PRFRE': item.get('PRFRE'),
                'INCO1': item.get('INCO1'),
                'INCO2_L': item.get('INCO2_L'),
                'ZTERM': item.get('ZTERM'),
                'KKBER': item.get('KKBER'),
                'KTGRD': item.get('KTGRD'),
                'TAXKD1': item.get('TAXKD1'),
                'TAXKD2': item.get('TAXKD2'),
                'TAXKD3': item.get('TAXKD3'),
                'TAXKD4': item.get('TAXKD4'),
                'PARVW_ZA': item.get('PARVW_ZA'),
                'LIFNR_ZA': item.get('LIFNR_ZA'),
                'PARVW_ZB': item.get('PARVW_ZB'),
                'LIFNR_ZB': item.get('LIFNR_ZB'),
                'PARVW_ZC': item.get('PARVW_ZC'),
                'LIFNR_ZC': item.get('LIFNR_ZC'),
                'SALES_PERSON': item.get('SALES_PERSON'),
                'SALES_PERSON_CODE': item.get('SALES_PERSON_CODE'),
                'AKONT': item.get('AKONT'),
                'ZUAWA': item.get('ZUAWA'),
                'FDGRV': item.get('FDGRV'),
                'ZTERM1': item.get('ZTERM1'),
                'ZWELS': item.get('ZWELS')
                }
            ]

            # Logging payload
            logging.info(f"Payload to API: {payload}")

            # Display payload and send request
            api_url = 'http://sildevapp.sangamgroup.com:8080/sap/bc/zcustomerbdc?sap-client=200'
            response = requests.post(api_url, json=payload)
            response_data = response.text

            # Log the API response
            logging.info(f"API Response: {response.status_code} - {response_data}")

            # Attempt to parse the response as JSON
            if 'application/json' in response.headers.get('Content-Type', ''):
                try:
                    response_json = response.json()
                    response_content = response_json
                    # Extract MSG from nested DATA
                    data_list = response_json.get('DATA', [])
                    if data_list and isinstance(data_list, list) and len(data_list) > 0:
                        msg_value = data_list[0].get('MSG', 'No MSG field')
                        status_value = data_list[0].get('STATUS', 'No STATUS field')
                        # Extract SAP number using regular expression
                        match = re.search(r'BP Number -(\d+)', msg_value)
                        sap_number = match.group(1) if match else 'No SAP Number Found'
                    else:
                        msg_value = 'No DATA or MSG field'
                        status_value = 'No DATA or STATUS field'
                        sap_number = 'No SAP Number Found'
                except ValueError as e:
                    logging.error(f"Failed to parse JSON from response: {e}")
                    response_content = {'error': 'Response is not valid JSON', 'details': response_data}
                    msg_value = 'No MSG field'
                    status_value = 'No STATUS field'
                    sap_number = 'No SAP Number Found'
            else:
                response_content = {'error': 'Response is not JSON', 'details': response_data}
                msg_value = 'No MSG field'
                status_value = 'No STATUS field'
                sap_number = 'No SAP Number Found'

            # Collect each response
            responses.append({
                'payload': payload,
                'status_code': response.status_code,
                'response_content': response_content,
                'msg_value': msg_value,  # Include MSG value in the response
                'status_value': status_value,  # Include STATUS value in the response
                'sap_number': sap_number  # Include SAP Number in the response
            })

            # Update the database with the SAP number if status is "S"
            if sap_number != 'No SAP Number Found' and form_number and status_value == "S":
                update_query = "UPDATE marketing_submission SET sap_number = %s WHERE form_number = %s"
                cursor.execute(update_query, (sap_number, form_number))
                db.commit()
                sap_number_added = True  # Set flag to True if SAP number is added
            elif status_value != "S":
                status_not_s_messages.append(f'Form number {form_number} has status {status_value}, that is why SAP number is not added.')

        # Flash a success message if SAP number was added
        if sap_number_added:
            flash('SAP Number added successfully!', 'success')

        else:
            flash('No SAP Number added.', 'info')

        # Flash messages for statuses not "S"
        for message in status_not_s_messages:
            flash(message, 'warning')

        # Render the payloads and responses
        return render_template_string('''
            <h3>Payloads Sent to API and Responses</h1>
            {% for response in responses %}
                <h3>Payload {{ loop.index }}</h2>
                <pre>{{ response.payload }}</pre>
                <h3>API Response {{ loop.index }}</h2>
                <pre>Status Code: {{ response.status_code }}</pre>
                <pre>Response Content: {{ response.response_content | tojson(indent=2) }}</pre>
                <pre>MSG Value: {{ response.msg_value }}</pre>
                <pre>STATUS Value: {{ response.status_value }}</pre>
                <pre>SAP Number Received: {{ response.sap_number }}</pre>
            {% endfor %}
            {% with messages = get_flashed_messages(with_categories=True) %}
                {% if messages %}
                    <ul class="flashes">
                        {% for category, message in messages %}
                            <li class="{{ category }}">{{ message }}</li>
                        {% endfor %}
                    </ul>
                {% endif %}
            {% endwith %}
        ''', responses=responses)

    except requests.exceptions.RequestException as e:
        app.logger.error('Error occurred while sending data: %s', str(e))
        return jsonify({'message': 'Error occurred while sending data', 'error': str(e)}), 500
    except Exception as e:
        app.logger.error('Error occurred: %s', str(e))
        return jsonify({'message': 'An error occurred', 'error': str(e)}), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/send_datav', methods=['POST'])
def send_datav():
    cursor = None
    try:
        data = request.json  # Expecting a list of dictionaries
        logging.info(f"Received payload: {data}")

        if not isinstance(data, list):
            raise ValueError("Expected payload to be a list of dictionaries")

        # Ensure db is properly connected
        if not db:
            raise Exception("Database connection is not initialized")

        cursor = db.cursor()

        responses = []  # Collect responses for each payload
        sap_number_added = False  # Flag to track if SAP number was added
        status_not_s_messages = []  # Collect messages for status not "S"

        # Process each item in the list
        for item in data:
            form_number = item.get('FORMNO')
            payload = [
                {
                'FORMNO': item.get('FORMNO'),
                'KTOKD': item.get('KTOKD'),
                'BUKRS': item.get('BUKRS'),
                'VKORG': item.get('VKORG'),
                'VTWEG': item.get('VTWEG'),
                'SPART': item.get('SPART'),
                'TITLE': item.get('TITLE'),
                'NAME1': item.get('NAME1'),
                'NAME2': item.get('NAME2'),
                'SORTL': item.get('SORTL'),
                'SORT2': item.get('SORT2'),
                'STR_SUPPL2': item.get('STR_SUPPL2'),
                'STREET': item.get('STREET'),
                'STR_SUPPL1': item.get('STR_SUPPL1'),
                'STRAS': item.get('STRAS'),
                'STR_SUPPL3': item.get('STR_SUPPL3'),
                'LOCATION': item.get('LOCATION'),
                'CITY1': item.get('CITY1'),
                'CITY2': item.get('CITY2'),
                'POST_CODE1': item.get('POST_CODE1'),
                'ORT01': item.get('ORT01'),
                'COUNTRY': item.get('COUNTRY'),
                'REGION': item.get('REGION'),
                'LANGU': item.get('LANGU'),
                'TELF1': item.get('TELF1'),
                'TELF2': item.get('TELF2'),
                'CONT_PERSON1': item.get('CONT_PERSON1'),
                'FAX_NUMBER': item.get('FAX_NUMBER'),
                'TEL_EXTENS': item.get('TEL_EXTENS'),
                'AD_SMTPADR': item.get('AD_SMTPADR'),
                'DEPT1': item.get('DEPT1'),
                'MOBILE2': item.get('MOBILE2'),
                'CONT_PERSON2': item.get('CONT_PERSON2'),
                'EMAIL2': item.get('EMAIL2'),
                'DEPT2': item.get('DEPT2'),
                'MOBILE3': item.get('MOBILE3'),
                'CONT_PERSON3': item.get('CONT_PERSON3'),
                'EMAIL3': item.get('EMAIL3'),
                'DEPT3': item.get('DEPT3'),
                'LEGAL_ENTY': item.get('LEGAL_ENTY'),
                'BPTYPE': item.get('BPTYPE'),
                'J_1IPANNO': item.get('J_1IPANNO'),
                'GST_CATG': item.get('GST_CATG'),
                'STCD3': item.get('STCD3'),
                'UMSA1': item.get('UMSA1'),
                'WAERS': item.get('WAERS'),
                'UMJAH': item.get('UMJAH'),
                'SALES_DIST': item.get('SALES_DIST'),
                'VKBUR': item.get('VKBUR'),
                'VKGRP': item.get('VKGRP'),
                'WAERS2': item.get('WAERS2'),
                'KONDA': item.get('KONDA'),
                'KALKS': item.get('KALKS'),
                'KZAZU': item.get('KZAZU'),
                'VWERK': item.get('VWERK'),
                'VSBED': item.get('VSBED'),
                'UNTTO': item.get('UNTTO'),
                'UEBTO': item.get('UEBTO'),
                'BOKRE': item.get('BOKRE'),
                'PRFRE': item.get('PRFRE'),
                'INCO1': item.get('INCO1'),
                'INCO2_L': item.get('INCO2_L'),
                'ZTERM': item.get('ZTERM'),
                'KKBER': item.get('KKBER'),
                'KTGRD': item.get('KTGRD'),
                'TAXKD1': item.get('TAXKD1'),
                'TAXKD2': item.get('TAXKD2'),
                'TAXKD3': item.get('TAXKD3'),
                'TAXKD4': item.get('TAXKD4'),
                'PARVW_ZA': item.get('PARVW_ZA'),
                'LIFNR_ZA': item.get('LIFNR_ZA'),
                'PARVW_ZB': item.get('PARVW_ZB'),
                'LIFNR_ZB': item.get('LIFNR_ZB'),
                'PARVW_ZC': item.get('PARVW_ZC'),
                'LIFNR_ZC': item.get('LIFNR_ZC'),
                'SALES_PERSON': item.get('SALES_PERSON'),
                'SALES_PERSON_CODE': item.get('SALES_PERSON_CODE'),
                'AKONT': item.get('AKONT'),
                'ZUAWA': item.get('ZUAWA'),
                'FDGRV': item.get('FDGRV'),
                'ZTERM1': item.get('ZTERM1'),
                'ZWELS': item.get('ZWELS')
                }
            ]

            # Logging payload
            logging.info(f"Payload to API: {payload}")

            # Display payload and send request
            api_url = 'http://sildevapp.sangamgroup.com:8080/sap/bc/zcustomerbdc?sap-client=200'
            response = requests.post(api_url, json=payload)
            response_data = response.text

            # Log the API response
            logging.info(f"API Response: {response.status_code} - {response_data}")

            # Attempt to parse the response as JSON
            if 'application/json' in response.headers.get('Content-Type', ''):
                try:
                    response_json = response.json()
                    response_content = response_json
                    # Extract MSG from nested DATA
                    data_list = response_json.get('DATA', [])
                    if data_list and isinstance(data_list, list) and len(data_list) > 0:
                        msg_value = data_list[0].get('MSG', 'No MSG field')
                        status_value = data_list[0].get('STATUS', 'No STATUS field')
                        # Extract SAP number using regular expression
                        match = re.search(r'BP Number -(\d+)', msg_value)
                        sap_number = match.group(1) if match else 'No SAP Number Found'
                    else:
                        msg_value = 'No DATA or MSG field'
                        status_value = 'No DATA or STATUS field'
                        sap_number = 'No SAP Number Found'
                except ValueError as e:
                    logging.error(f"Failed to parse JSON from response: {e}")
                    response_content = {'error': 'Response is not valid JSON', 'details': response_data}
                    msg_value = 'No MSG field'
                    status_value = 'No STATUS field'
                    sap_number = 'No SAP Number Found'
            else:
                response_content = {'error': 'Response is not JSON', 'details': response_data}
                msg_value = 'No MSG field'
                status_value = 'No STATUS field'
                sap_number = 'No SAP Number Found'

            # Collect each response
            responses.append({
                'payload': payload,
                'status_code': response.status_code,
                'response_content': response_content,
                'msg_value': msg_value,  # Include MSG value in the response
                'status_value': status_value,  # Include STATUS value in the response
                'sap_number': sap_number  # Include SAP Number in the response
            })

            # Update the database with the SAP number if status is "S"
            if sap_number != 'No SAP Number Found' and form_number and status_value == "S":
                update_query = "UPDATE purchase_submission SET sap_number = %s WHERE form_number = %s"
                cursor.execute(update_query, (sap_number, form_number))
                db.commit()
                sap_number_added = True  # Set flag to True if SAP number is added
            elif status_value != "S":
                status_not_s_messages.append(f'Form number {form_number} has status {status_value}, that is why SAP number is not added.')

        # Flash a success message if SAP number was added
        if sap_number_added:
            flash('SAP Number added successfully!', 'success')

        else:
            flash('No SAP Number added.', 'info')

        # Flash messages for statuses not "S"
        for message in status_not_s_messages:
            flash(message, 'warning')

        # Render the payloads and responses
        return render_template_string('''
            <h3>Payloads Sent to API and Responses</h1>
            {% for response in responses %}
                <h3>Payload {{ loop.index }}</h2>
                <pre>{{ response.payload }}</pre>
                <h3>API Response {{ loop.index }}</h2>
                <pre>Status Code: {{ response.status_code }}</pre>
                <pre>Response Content: {{ response.response_content | tojson(indent=2) }}</pre>
                <pre>MSG Value: {{ response.msg_value }}</pre>
                <pre>STATUS Value: {{ response.status_value }}</pre>
                <pre>SAP Number Received: {{ response.sap_number }}</pre>
            {% endfor %}
            {% with messages = get_flashed_messages(with_categories=True) %}
                {% if messages %}
                    <ul class="flashes">
                        {% for category, message in messages %}
                            <li class="{{ category }}">{{ message }}</li>
                        {% endfor %}
                    </ul>
                {% endif %}
            {% endwith %}
        ''', responses=responses)

    except requests.exceptions.RequestException as e:
        app.logger.error('Error occurred while sending data: %s', str(e))
        return jsonify({'message': 'Error occurred while sending data', 'error': str(e)}), 500
    except Exception as e:
        app.logger.error('Error occurred: %s', str(e))
        return jsonify({'message': 'An error occurred', 'error': str(e)}), 500
    finally:
        if cursor:
            cursor.close()

if __name__ == '__main__':
    cert_path = 'C:/Users/Bhavesh/AppData/Local/Programs/Python/Python312/Lib/test/certdata/cert.pem'
    key_path = 'C:/Users/Bhavesh/AppData/Local/Programs/Python/Python312/Lib/test/certdata/key.pem'

    if os.path.isfile(cert_path) and os.path.isfile(key_path):
        app.run(ssl_context=(cert_path, key_path), debug=True)
    else:
        print("SSL certificate or key file not found. Running without SSL.")
        app.run(debug=True, host="0.0.0.0", port=5003)