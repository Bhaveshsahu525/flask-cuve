from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
import re

app = Flask(__name__)
app.secret_key = 'your_secret_key'


# Function to create the users table
def create_users_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_mr
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')


# Function to create the users_ar table
def create_users_ar_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_ar
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')

# Function to create the users_it table
def create_users_it_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_it
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')

def create_users_pr_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_pr
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')

def create_users_ap_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_ap
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')


# Function to add a new user to the database
def add_user(cursor, table_name, username, password):
    cursor.execute(f"INSERT INTO {table_name} (username, password) VALUES (%s, %s)", (username, password))


# Function to fetch all user details (excluding ID)
def fetch_all_users(cursor, table_name):
    cursor.execute(f"SELECT username, password FROM {table_name}")
    return cursor.fetchall()


# Function to delete a user from the database
def delete_user(cursor, table_name, username):
    cursor.execute(f"DELETE FROM {table_name} WHERE username = %s", (username,))
    return cursor.rowcount


# Function to validate email format
def validate_email(email):
    email_regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(email_regex, email))


# Function to validate password format (for demonstration purposes, let's assume password must be at least 6 characters)
def validate_password(password):
    return len(password) >= 6


@app.route('/')
def signup():
    return render_template('signup.html')


@app.route('/create_user', methods=['POST'])
def create_user():
    selected_department = request.form['department']
    new_username = request.form['email']
    new_password = request.form['password']

    if not validate_email(new_username):
        flash("Please enter a valid email address.", "info")
    elif not validate_password(new_password):
        flash("Password must be at least 6 characters.", "danger")
    else:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Enter your password here
            database="sangamcustomer"
        )
        cursor = conn.cursor()

        table_name = ""
        if selected_department == "Marketing":
            table_name = "users_mr"
            create_users_table(cursor)
        elif selected_department == "AR":
            table_name = "users_ar"
            create_users_ar_table(cursor)
        elif selected_department == "IT":
            table_name = "users_it"
            create_users_it_table(cursor)
        elif selected_department == "Purchase":
            table_name = "users_pr"
            create_users_pr_table(cursor)
        elif selected_department == "AP":
            table_name = "users_ap"
            create_users_ap_table(cursor)

        # Check if the user already exists
        cursor.execute(f"SELECT * FROM {table_name} WHERE username = %s", (new_username,))
        existing_user = cursor.fetchone()

        if existing_user:
            flash(f"User with email '{new_username}' already exists in the {selected_department} department.", "info")
        else:
            # Add new user
            add_user(cursor, table_name, new_username, new_password)
            conn.commit()
            flash("User created successfully.", "success")

        cursor.close()
        conn.close()

    return redirect(url_for('signup'))


@app.route('/show_users', methods=['POST'])
def show_users():
    selected_department = request.form['department']

    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Enter your password here
        database="sangamcustomer"
    )
    cursor = conn.cursor()

    if selected_department == "Marketing":
        users_data = fetch_all_users(cursor, "users_mr")
    elif selected_department == "AR":
        users_data = fetch_all_users(cursor, "users_ar")
    elif selected_department == "IT":
        users_data = fetch_all_users(cursor, "users_it")
    elif selected_department == "Purchase":
        users_data = fetch_all_users(cursor, "users_pr")
    elif selected_department == "AP":
        users_data = fetch_all_users(cursor, "users_ap")

    cursor.close()
    conn.close()

    return render_template('signup.html', users=users_data)


@app.route('/delete_user', methods=['POST'])
def delete_user_route():
    selected_department = request.form['department']
    username_to_delete = request.form['username_to_delete']

    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Enter your password here
        database="sangamcustomer"
    )
    cursor = conn.cursor()

    if selected_department == "Marketing":
        rows_deleted = delete_user(cursor, "users_mr", username_to_delete)
    elif selected_department == "AR":
        rows_deleted = delete_user(cursor, "users_ar", username_to_delete)
    elif selected_department == "IT":
        rows_deleted = delete_user(cursor, "users_it", username_to_delete)
    elif selected_department == "Purchase":
        rows_deleted = delete_user(cursor, "users_pr", username_to_delete)
    elif selected_department == "AP":
        rows_deleted = delete_user(cursor, "users_ap", username_to_delete)

    conn.commit()
    cursor.close()
    conn.close()

    if rows_deleted > 0:
        flash(f"User '{username_to_delete}' deleted successfully.", "success")
    else:
        flash(f"No user with username '{username_to_delete}' found.", "danger")
    return redirect(url_for('signup'))


if __name__ == '__main__':
    app.run(debug=True, port=5001)
