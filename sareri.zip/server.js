import { fileURLToPath } from 'url';
import path from 'path';
import express from 'express';
import bodyParser from 'body-parser';
import session from 'express-session';
import sql from 'mssql';

import XlsxPopulate from 'xlsx-populate';
import fs from 'fs/promises';



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

// Set EJS as the view engine
const viewsPath = path.join(__dirname, 'views');
app.set('view engine', 'ejs');
app.set('views', viewsPath);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Set up session middleware
app.use(session({
  secret: 'aF@r3$ecrE7K3y', // Replace with a strong, random secret key
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Adjust secure flag based on your deployment environment
}));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// MSSQL configuration
const mssqlConfig = {
  user: 'sa',
  password: 'server@2010',
  server: '172.16.0.89',
  database: 'easyWDMS',
  options: {
    encrypt: false,
    trustServerCertificate: true
  }
};

// Create MSSQL connection pool
const pool = new sql.ConnectionPool(mssqlConfig);
const poolConnect = pool.connect();

// Middleware to check if the user is authenticated
function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  res.redirect('/');
}

// Serve the login page and handle login form submission
app.get('/', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect('/index');
  }
  const error = req.query.error;
  res.render('login', { error });
});

app.post('/login', async (req, res) => {
  const { username, emppassword } = req.body;

  if (!username || !emppassword) {
    return res.redirect('/?error=1'); // Handle invalid credentials
  }

  await poolConnect; // Wait for pool to connect

  try {
    const request = pool.request();
    request.input('username', sql.VarChar, username);
    request.input('emppassword', sql.VarChar, emppassword);
    
    const query = 'SELECT username, department FROM sangamscript WHERE username = @username AND emppassword = @emppassword';
    const result = await request.query(query);

    if (result.recordset.length === 0) {
      return res.redirect('/?error=1'); // Redirect if no user found
    }

    const { username: foundUsername, department } = result.recordset[0]; // Renamed to foundUsername to avoid conflicts

    req.session.user = foundUsername;
    req.session.department = department;
    res.redirect('/index');
  } catch (err) {
    console.error('Error executing SQL query or invalid credentials:', err);
    res.redirect('/?error=1');
  }
});

// Route to serve the index page
app.get('/index', isAuthenticated, async (req, res) => {
  try {
    // Connect to MSSQL
    await poolConnect;
const result = await pool.request().query(`
    WITH CTE AS (
        SELECT 
            id,
            emp_code,
            CONVERT(varchar(255), punch_time, 121) AS punch_time,
            punch_state,
            verify_type,
            work_code,
            terminal_sn,
            terminal_alias,
            area_alias,
            ROW_NUMBER() OVER (PARTITION BY emp_code, CAST(punch_time AS DATE) ORDER BY punch_time) AS rn,
            CASE
                WHEN CAST(punch_time AS TIME) BETWEEN '09:00:00' AND '15:00:00' THEN 1
                ELSE 2
            END AS time_category
        FROM iclock_transaction
        WHERE area_alias = 'Sareri Canteen'
          AND (terminal_alias = 'Sareri Canteen M23' OR terminal_alias = 'Sareri Canteen M1')
AND CAST(punch_time AS DATE) = CAST(GETDATE() AS DATE) -- Filter for today's date only

    )
    SELECT 
        id,
        emp_code,
        punch_time,
        punch_state,
        verify_type,
        work_code,
        terminal_sn,
        terminal_alias,
        area_alias
    FROM CTE
    WHERE rn = 1 OR time_category = 2 -- Include the first punch in the specified time range or punches outside that range
    ORDER BY id ASC;
`);





    // Extract data from the result
    const iclockTransactions = result.recordset;

    // Render the index page with data
    res.render('index', { iclockTransactions });
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).send('Error fetching data');
  } finally {
    // Release MSSQL connection
    sql.close();
  }
});



// Route to serve the all page
app.get('/all', isAuthenticated, async (req, res) => {
  try {
    // Connect to MSSQL
    await poolConnect;
const result = await pool.request().query(`
    WITH CTE AS (
        SELECT 
            id,
            emp_code,
            CONVERT(varchar(255), punch_time, 121) AS punch_time,
            punch_state,
            verify_type,
            work_code,
            terminal_sn,
            terminal_alias,
            area_alias,
            ROW_NUMBER() OVER (PARTITION BY emp_code, CAST(punch_time AS DATE) ORDER BY punch_time) AS rn,
            CASE
                WHEN CAST(punch_time AS TIME) BETWEEN '09:00:00' AND '15:00:00' THEN 1
                ELSE 2
            END AS time_category
        FROM iclock_transaction
        WHERE area_alias = 'Sareri Canteen'
          AND (terminal_alias = 'Sareri Canteen M23' OR terminal_alias = 'Sareri Canteen M1')
-- AND CAST(punch_time AS DATE) = CAST(GETDATE() AS DATE) -- Filter for today's date only

    )
    SELECT 
        id,
        emp_code,
        punch_time,
        punch_state,
        verify_type,
        work_code,
        terminal_sn,
        terminal_alias,
        area_alias
    FROM CTE
    WHERE rn = 1 OR time_category = 2 -- Include the first punch in the specified time range or punches outside that range
    ORDER BY id ASC;
`);





    // Extract data from the result
    const iclockTransactions = result.recordset;

    // Render the all page with data
    res.render('all', { iclockTransactions });
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).send('Error fetching data');
  } finally {
    // Release MSSQL connection
    sql.close();
  }
});

// Handle logout
app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
      return res.status(500).json({ error: 'Logout failed' });
    }
    res.redirect('/');
  });
});


// Route to download employee monthly count as Excel
app.post('/download-employee-monthly-count', isAuthenticated, async (req, res) => {
  const { month } = req.body;

  // Convert numeric month to month name
  const monthName = new Date(`${month}-01`).toLocaleString('default', { month: 'long' });

  try {
    // Connect to MSSQL
    await poolConnect;

    const result = await pool.request().query(`
    WITH CTE AS (
        SELECT
            emp_code AS empCode,
            CAST(punch_time AS DATE) AS punch_date,
            ROW_NUMBER() OVER (PARTITION BY emp_code, CAST(punch_time AS DATE) ORDER BY punch_time) AS rn,
            CASE
                WHEN CAST(punch_time AS TIME) BETWEEN '09:00:00' AND '15:00:00' THEN 1
                ELSE 2
            END AS time_category
        FROM
            iclock_transaction
        WHERE
            MONTH(punch_time) = '${month}'
    )
    SELECT
        empCode,
        COUNT(DISTINCT CASE WHEN time_category = 1 OR rn = 1 THEN punch_date END) AS totalDays
    FROM
        CTE
    GROUP BY
        empCode
    `);

    const results = result.recordset;

    // Create a new Excel workbook
    const wb = await XlsxPopulate.fromBlankAsync();

    // Add data to the sheet
    const sheet = wb.sheet(0);

    // Set the month name in cell A1
    sheet.cell("A1").value(`Month: ${monthName}`);

    // Headers for the data
    sheet.cell("A2").value("Employee Code");
    sheet.cell("B2").value("Total Days Eat");
    
    // Populate data starting from row 3
    results.forEach((data, index) => {
      sheet.cell(`A${index + 3}`).value(data.empCode);
      sheet.cell(`B${index + 3}`).value(data.totalDays);
    });

    // Generate a temporary file path
    const filePath = path.join(__dirname, `Employee Food Count of ${month}.xlsx`);

    // Save the workbook to a file
    await wb.toFileAsync(filePath);

    // Stream the file to the client as an attachment
    res.download(filePath, `Employee Food Count of ${monthName}.xlsx`, async (err) => {
      if (err) {
        console.error('Error downloading file:', err);
        res.status(500).json({ error: 'Error downloading file' });
      }
      // Delete the temporary file after sending
      try {
        await fs.unlink(filePath);
        console.log(`Deleted file: ${filePath}`);
      } catch (unlinkError) {
        console.error('Error deleting file:', unlinkError);
      }
    });

  } catch (error) {
    console.error('Error fetching employee monthly count:', error);
    res.status(500).json({ error: 'Error fetching employee monthly count' });
  }
});




// Start server
const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
