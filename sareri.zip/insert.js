import sql from 'mssql';
import mysql from 'mysql2/promise';

const mssqlConfig = {
  user: 'sa',
  password: 'server@2010',
  server: '172.16.0.89',
  database: 'easyWDMS',
  options: {
    encrypt: false,
    trustServerCertificate: true
  }
};

const mysqlConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'sareri'
};

// Function to convert MSSQL datetime to UTC string
function convertToUTC(datetime) {
  return datetime.toISOString().slice(0, 19).replace('T', ' ');
}

async function fetchDataAndInsert() {
  let mssqlPool;
  let mysqlConnection;

  try {
    // Connect to MSSQL
    mssqlPool = await sql.connect(mssqlConfig);
    const result = await mssqlPool.query`SELECT emp_code, punch_time FROM iclock_transaction`;
    console.log("Fetched data:");
    console.table(result.recordset);

    // Convert MSSQL datetime to UTC string
    const data = result.recordset.map(row => [
      row.emp_code,
      convertToUTC(new Date(row.punch_time))  // Convert punch_time to UTC
    ]);

    // Connect to MySQL
    mysqlConnection = await mysql.createConnection(mysqlConfig);

    // Bulk insert or update into MySQL
    await mysqlConnection.query(
      'INSERT INTO punching (emp_code, emp_time) VALUES ? ' +
      'ON DUPLICATE KEY UPDATE emp_time = VALUES(emp_time)',
      [data]
    );

    console.log('Data inserted or updated in MySQL table.');

  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    try {
      if (mysqlConnection) await mysqlConnection.end();
      console.log('MySQL connection closed.');
      if (mssqlPool) await mssqlPool.close();
      console.log('MSSQL connection closed.');
    } catch (err) {
      console.error('Error while closing connections:', err.message);
    }
  }
}

fetchDataAndInsert();
