import streamlit as st
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import re
import mysql.connector
import uuid
import ssl
import traceback
import threading

# Function to connect to the MySQL database
def connect_to_database(host, user, password, database):
    conn = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )
    return conn

# Function to create a table if it doesn't exist
def create_table_if_not_exists(conn, table_name):
    cursor = conn.cursor()
    cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INT AUTO_INCREMENT PRIMARY KEY,
            login_number VARCHAR(40) NOT NULL,
            request_number VARCHAR(40) NOT NULL,
            company_name VARCHAR(40) NOT NULL,
            email VARCHAR(40) NOT NULL,
            logged_in_user_email VARCHAR(40) NOT NULL,
            category VARCHAR(10) NOT NULL
        );
    """)
    conn.commit()

# Function to insert data into the table
def insert_data(conn, table_name, login_number, request_number, company_name, email, logged_in_user_email, category):
    cursor = conn.cursor()
    cursor.execute(f"""
        INSERT INTO {table_name} (login_number, request_number, company_name, email, logged_in_user_email, category) VALUES (%s, %s, %s, %s, %s, %s)
    """, (login_number, request_number, company_name, email, logged_in_user_email, category))
    conn.commit()

# Function to generate a new request number
def generate_request_number():
    return str(uuid.uuid4())

# Function to get the total number of rows in the table
def get_total_rows(conn, table_name):
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
    total_rows = cursor.fetchone()[0]
    return total_rows

# Function to get the total number of rows in the table for the logged-in user
def get_total_rows_for_logged_in_user(conn, table_name, logged_in_user_email):
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE logged_in_user_email = %s;", (logged_in_user_email,))
    total_rows = cursor.fetchone()[0]
    return total_rows

# Function to send email
def send_email(sender_email, sender_password, recipient_email, subject, body):
    # Set up the MIME
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = recipient_email
    message['Subject'] = subject

    # Add body to email
    message.attach(MIMEText(body, 'plain'))

    # Connect to the SMTP server securely using SSL/TTLS
    smtp_server = 'mail.sangamgroup.com'  # Update SMTP server address
    port = 465  # Default port for SSL/TLS
    context = ssl.create_default_context()

    try:
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            # Login to the SMTP server using authentication
            server.login(sender_email, sender_password)

            # Send email
            server.sendmail(sender_email, recipient_email, message.as_string())
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        traceback.print_exc()  # Print full traceback
        return False

def send_email_task(sender_email, sender_password, recipient_email, subject, body, conn_requests, table_requests, login_number, request_number, company_name, logged_in_user_email, category):
    try:
        if send_email(sender_email, sender_password, recipient_email, subject, body):
            st.success("Email sent successfully!")

            # Insert data into the database only if email is sent successfully
            insert_data(conn_requests, table_requests, login_number, request_number, company_name, email, logged_in_user_email, category)

            # Update total rows after insertion
            total_rows = get_total_rows(conn_requests, table_requests)
            total_rows_display.text("Total customer contacted: " + str(total_rows))
            if logged_in_user_email:
                total_rows_logged_in_user = get_total_rows_for_logged_in_user(conn_requests, table_requests, logged_in_user_email)
                total_rows_logged_in_user_display.text("Customer contacted by me : " + str(total_rows_logged_in_user))
        else:
            st.error("Failed to send email.")
    except Exception as e:
        st.error(f"Failed to send email: {e}")

# Function to validate email
def validate_email(email):
    # Regular expression for email validation
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(pattern, email))

# Function to validate company name
def validate_company_name(company_name):
    # Regular expression for company name validation (allowing alphabets, spaces, dots, and parentheses)
    pattern = r'^[A-Z\s.()]+$'
    return bool(re.match(pattern, company_name))

# Function to check if company name and email already exist
def check_if_user_exists(conn, table_name, company_name, email):
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE company_name = %s AND email = %s", (company_name, email))
    count = cursor.fetchone()[0]
    cursor.close()
    return count > 0

# Function to fetch email address of logged-in user based on request number
def fetch_logged_in_user_email(conn, login_number):
    cursor = conn.cursor()
    cursor.execute(f"SELECT email FROM logged_in_user WHERE login_number = %s", (login_number,))
    result = cursor.fetchone()
    cursor.close()
    return result[0] if result else None

# Function to delete request number and email from the table
def delete_request_number_and_email(conn, table_name, login_number):
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM {table_name} WHERE login_number = %s", (login_number,))
    conn.commit()
    cursor.close()

# Function to redirect to a URL with optional login number
def redirect_to_url(url, login_number=None):
    if login_number:
        new_url = f"{url}?login_number={login_number}"
    else:
        new_url = url
    st.markdown(f'<meta http-equiv="refresh" content="0;URL={new_url}">', unsafe_allow_html=True)


# Function to check if company name exists in the database
def check_if_company_exists(conn, table_name, company_name):
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE company_name = %s", (company_name,))
    count = cursor.fetchone()[0]
    cursor.close()
    return count > 0

# Function to check if email exists in the database
def check_if_email_exists(conn, table_name, email):
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE email = %s", (email,))
    count = cursor.fetchone()[0]
    cursor.close()
    return count > 0


def main():
    st.title('Sangam Customer Email Sending')

    # Get request number from URL or generate a new one
    params = st.query_params
    request_number = params.get('request_number', generate_request_number())

    # Get login_number from query params
    login_number = params.get('login_number')

    # Connect to the database for logged-in users
    host_login = "localhost"
    user_login = "root"
    password_login = ""
    database_login = "logindashboard"
    conn_login = connect_to_database(host_login, user_login, password_login, database_login)

    # Fetch email address of logged-in user based on request number
    logged_in_user_email = fetch_logged_in_user_email(conn_login, login_number)

    # Close connection to the login database
    conn_login.close()
    if logged_in_user_email:
        st.sidebar.text("Logged-in User: " + logged_in_user_email)
    else:
        st.sidebar.text("User not logged in")

    # Add "Work done" button to sidebar
    if st.sidebar.button('logout'):
        # Connect to the database for logged-in users
        conn_work_done = connect_to_database(host_login, user_login, password_login, database_login)
        delete_request_number_and_email(conn_work_done, "logged_in_user", login_number)
        redirect_to_url("http://127.0.0.1:5000/")
        return

    # Add "Work done" button to sidebar
    if st.sidebar.button('Customer Contacted Back'):
        # Specify the URL to redirect to
        redirect_url = "http://localhost:8504/"
        redirect_to_url(redirect_url, login_number)
        return

    if st.sidebar.button('Changes Requested By AR'):
        # Specify the URL to redirect to
        redirect_url = "http://localhost:8505/"
        redirect_to_url(redirect_url, login_number)
        return

    if st.sidebar.button('Changes Requested By IT'):
        # Specify the URL to redirect to with login_number as a parameter
        redirect_url = f"http://localhost:8506/"
        redirect_to_url(redirect_url, login_number)
        return

    # Connect to the database for customer requests
    host_requests = "localhost"
    user_requests = "root"
    password_requests = ""
    database_requests = "emailssenttocustomer"
    table_requests = "Customerrequested"
    conn_requests = connect_to_database(host_requests, user_requests, password_requests, database_requests)

    # Create table if it doesn't exist
    create_table_if_not_exists(conn_requests, table_requests)

    # Get total rows in the database
    total_rows = get_total_rows(conn_requests, table_requests)

    # Display total rows in the database on the sidebar
    total_rows_display = st.sidebar.text("Total customer contacted: " + str(total_rows))

    # Get total rows in the database for the logged-in user
    if logged_in_user_email:
        total_rows_logged_in_user = get_total_rows_for_logged_in_user(conn_requests, table_requests,
                                                                      logged_in_user_email)

        # Display total rows for the logged-in user in the database on the sidebar
        total_rows_logged_in_user_display = st.sidebar.text(
            "Total customer contacted by you: " + str(total_rows_logged_in_user))

    company_name = st.text_input('Company Name: ')
    email = st.text_input('Company Email ID: ')
    category = st.selectbox('Category', ['Domestic (ZDOM)', 'Export (ZEXP)', 'Ship to Party (ZDSH)'])

    if st.button("Submit"):
        if not validate_company_name(company_name):
            st.error("Please enter a valid Company name in Capital letters.")
        elif not validate_email(email):
            st.error("Please enter a valid email address.")
        else:
            company_exists = check_if_company_exists(conn_requests, table_requests, company_name)
            email_exists = check_if_email_exists(conn_requests, table_requests, email)

            if company_exists and email_exists:
                st.error("Company name and email already exist.")
            elif company_exists:
                st.error("Company name already exists.")
            elif email_exists:
                st.error("Email already exists.")
            else:
                st.success("Company name and email are valid!")

                # Email sending parameters
                sender_email = 'testit@sangamgroup.com'  # Your email
                sender_password = 'Krishna@123'  # Your email password
                recipient_email = email  # Recipient's email
                subject = 'Welcome to Sangam Vendor!'  # Email subject

                # Determine link based on category
                if category == 'Domestic (ZDOM)':
                    link = "http://localhost:8507/"
                elif category == 'Export (ZEXP)':
                    link = "http://localhost:8508/"
                elif category == 'Ship to Party (ZDSH)':
                    link = "http://localhost:8509/"  # You may adjust this as per your requirement

                body = f'Hello {company_name},\n\nWelcome to Sangam Vendor. Please click on the following link to complete your registration: {link}?request_number={request_number}'

                # Spawn a new thread for each email sending task
                email_thread = threading.Thread(target=send_email_task, args=(
                    sender_email, sender_password, recipient_email, subject, body, conn_requests, table_requests,
                    login_number,
                    request_number, company_name, logged_in_user_email, category))
                email_thread.start()
                # Send email
                try:
                    if send_email(sender_email, sender_password, recipient_email, subject, body):
                        st.success("Email sent successfully!")

                        # Insert data into the database only if email is sent successfully
                        insert_data(conn_requests, table_requests, login_number, request_number, company_name, email,
                                    logged_in_user_email, category)

                        # Update total rows after insertion
                        total_rows = get_total_rows(conn_requests, table_requests)
                        total_rows_display.text("Total customer contacted: " + str(total_rows))
                        if logged_in_user_email:
                            total_rows_logged_in_user = get_total_rows_for_logged_in_user(conn_requests, table_requests,
                                                                                          logged_in_user_email)
                            total_rows_logged_in_user_display.text(
                                "Customer contacted by me : " + str(total_rows_logged_in_user))
                    else:
                        st.error("Failed to send email.")
                except Exception as e:
                    st.error(f"Failed to send email: {e}")

    # Close database connection
    conn_requests.close()

if __name__ == "__main__":
    main()
