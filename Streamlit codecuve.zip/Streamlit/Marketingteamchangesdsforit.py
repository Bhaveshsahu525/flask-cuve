import streamlit as st
import re
import mysql.connector
import base64
import datetime

# Function to validate field based on regular expression
def validate_field(field_name, field_value):
    validation_patterns = {
        'CUSTOMER ACCOUNT GROUP': r'^[A-Z]+$',
        'COMPANY CODE': r'^[0-9]+$',
        'SALES ORG.': r'^[0-9]+$',
        'DIVISION': r'^[0-9]+$',
        'TITLES': r'^[0-9]+$',
        'NAME1': r'^[a-zA-Z0-9\s.,()-]+$',
        'NAME2': r'^[a-zA-Z0-9\s.,()-]+$',
        'SEARCH 1': r'^[a-zA-Z0-9\s.,()-]*$',
        'SEARCH 2 (OLD CUSTOMER CODE)': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET 3': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET / HOUSE NUMBER': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET 2': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET4': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET5': r'^[a-zA-Z0-9\s.,()-]+$',
        'DISTRICT': r'^[a-zA-Z0-9\s.,()-]+$',
        'DIFFERENT CITY': r'^[a-zA-Z0-9\s.,()-]+$',
        'PIN CODE': r'^\d{6}$',
        'CITY': r'^[a-zA-Z0-9\s.,()-]+$',
        'COUNTRY': r'^[a-zA-Z0-9\s.,()-]+$',
        'REGION': r'^[a-zA-Z0-9\s.,()-]+$',
        'TELPHONE NUMBER 1': r'^\d{10}$',
        'MOBILE NUMBER 1': r'^\d{10}$',
        'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
        'FAX': r'^\d{10}$',
        'EXTENSION': r'^\d{3}$',
        'EMAIL 1': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'DEPARTMENT 1 (NOTES OF E-MAIL)': r'^[a-zA-Z0-9\s.,()-]+$',
        'MOBILE PHONE-2': r'^\d{10}$',
        'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
        'EMAIL 2': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'MOBILE PHONE-3': r'^\d{10}$',
        'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
        'EMAIL 3': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'DEPARTMENT 3 (NOTES OF E-MAIL)': r'^[a-zA-Z0-9\s.,()-]+$',
        'LEGAL FORM': r'^[a-zA-Z0-9\s.,()-]+$',
        'BP TYPE': r'^[a-zA-Z0-9\s.,()-]+$',
        'PAN CARD': r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
        'GSTIN NO': r'^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$',
        'ANNUAL SALES': r'^[a-zA-Z0-9\s.,()-]+$',
        'CURRENCY': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES YEAR': r'^\d{4}$',
        'SALES DISTRICT': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES OFFICE': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES GROUP': r'^[a-zA-Z0-9\s.,()-]+$',
        'DELIVERING PLANT': r'^[a-zA-Z0-9\s.,()-]+$',
        'OVERDELIV. TOLERANCE': r'^[a-zA-Z0-9\s.,()-]+$',
        'INCOTERMS': r'^[a-zA-Z0-9\s.,()-]+$',
        'INCOTERMS LOCATION': r'^[a-zA-Z0-9\s.,()-]+$',
        'PAYMENT TERMS': r'^[a-zA-Z0-9\s.,()-]+$',
        'ACCT ASSMT GRP CUST.': r'^[a-zA-Z0-9\s.,()-]+$',
        'AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'BROKER AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'FORWARDING AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES PERSON': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES PERSON-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'RECON ACCOUNT': r'^[a-zA-Z0-9\s.,()-]+$',
        'SORT KEY': r'^[a-zA-Z0-9\s.,()-]+$',
        'PLANNING GROUP': r'^[a-zA-Z0-9\s.,()-]+$',
        'PAYMENT METHODS': r'^[a-zA-Z0-9\s.,()-]+$',
        'DUNNING PROCEDURE': r'^[a-zA-Z0-9\s.,()-]+$',
        'RELATIONSHIP CATEGORY': r'^[a-zA-Z0-9\s.,()-]+$',
    }
    pattern = validation_patterns.get(field_name)
    if pattern:
        return bool(re.match(pattern, field_value))
    return False

def extract_numeric(value):
    match = re.match(r'(\d+)', value)
    return int(match.group(1)) if match else 0

# Connect to MySQL database for inserting data
def connect_to_insert_database():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="formsubmitteddetails"
        )
        return conn
    except mysql.connector.Error as err:
        st.error(f"Error connecting to MySQL database: {err}")
        return None

# Connect to MySQL database for fetching data
def connect_to_fetch_database():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="formsubmitteddetails"
        )
        return conn
    except mysql.connector.Error as err:
        st.error(f"Error connecting to MySQL database: {err}")
        return None

# Function to fetch company name and email from the database
def fetch_company_email(conn, form_number):
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT customer_account_group, company_code, sales_org, division, titles, name_1, name_2, search_1, search_2_old_customer_code, street_3, street_house_number, street_2, street, street_4, street_5, district, different_city, pin_code, city, country, region, telephone_number_1, mobile_number_1, contact_person_1_comments_of_mobile_number, email_1, department_1_notes_of_email, mobile_phone_2, contact_person_2_comments_of_mobile_number, email_2, department_2_notes_of_email, mobile_phone_3, contact_person_3_comments_of_mobile_number, email_3, department_3_notes_of_email, legal_form, bp_type, pan_card, gstin_no, annual_sales, currency, sales_year, sales_district, sales_office, sales_group, currency_2, delivering_plant, overdeliv_tolerance, incoterms, incoterms_location, payment_terms, agent_code, broker_agent_code, forwarding_agent_code, sales_person, sales_person_code, recon_account, sort_key, planning_group, payment_terms_2, payment_methods, dunning_procedure, relationship_category, distribution_channel, language, fax, extension, gst_category, price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance, indicator_customer_is_rebate_relevant, relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category, tax_category_2, tax_category_3, tax_category_4 FROM marketing_submission WHERE form_number = '{form_number}'")
        result = cursor.fetchone()
        cursor.close()
        return result if result else None
    except mysql.connector.Error as err:
        st.error(f"Error fetching data from database: {err}")
        return None

def pdf_download(pdf_data, filename):
    with open(filename, "wb") as f:
        f.write(base64.b64decode(pdf_data))

    st.markdown(f'<a href="data:application/pdf;base64,{base64.b64encode(pdf_data).decode()}" download="{filename}">Download PDF</a>', unsafe_allow_html=True)

# Function to insert form data into the database
def update_database(conn, data, form_number):

    try:
        cursor = conn.cursor()

        current_date = datetime.datetime.now().date()

        cursor.execute("SELECT request_number FROM form_details WHERE form_number = %s", (form_number,))
        result = cursor.fetchone()
        if result:
            request_number = result[0]
        else:
            st.error("Error fetching request number.")
            return None

        sales_org_numeric = extract_numeric(data[2])
        division_numeric = extract_numeric(data[4])
        credit_control_area = sales_org_numeric + division_numeric

        # Insert data into the database along with the form number
        update_query = """
            UPDATE marketing_submission
            SET `credit_control_area` = %s, `agent` = %s, `broker_agent` = %s, `forwarding_agent` = %s, `customer_account_group` = %s, `company_code` = %s, `sales_org` = %s, `distribution_channel` = %s,
            `division` = %s, `titles` = %s, `name_1` = %s, `name_2` = %s, `search_1` = %s, `search_2_old_customer_code` = %s, `street_3` = %s, 
            `street_house_number` = %s, `street_2` = %s, `street` = %s, `street_4` = %s, `street_5` = %s, `district` = %s, 
            `different_city` = %s, `pin_code` = %s, `city` = %s, `country` = %s, `region` = %s, `language` = %s, `telephone_number_1` = %s, 
            `mobile_number_1` = %s, `contact_person_1_comments_of_mobile_number` = %s, `fax` = %s, `extension` = %s, `email_1` = %s, 
            `department_1_notes_of_email` = %s, `mobile_phone_2` = %s, `contact_person_2_comments_of_mobile_number` = %s, `email_2` = %s, 
            `department_2_notes_of_email` = %s, `mobile_phone_3` = %s, `contact_person_3_comments_of_mobile_number` = %s, `email_3` = %s, 
            `department_3_notes_of_email` = %s, `legal_form` = %s, `bp_type` = %s, `pan_card` = %s, `gst_category` = %s, `gstin_no` = %s, 
            `annual_sales` = %s, `currency` = %s, `sales_year` = %s, `sales_district` = %s, `sales_office` = %s, `sales_group` = %s, 
            `currency_2` = %s, `price_group` = %s, `cust_pric_procedure` = %s, `order_combination_indicator` = %s, `delivering_plant` = %s, 
            `shipping_conditions` = %s, `underdel_tolerance` = %s, `overdeliv_tolerance` = %s, `indicator_customer_is_rebate_relevant` = %s, 
            `relevant_for_price_determination_id` = %s, `incoterms` = %s, `incoterms_location` = %s, `payment_terms` = %s, 
            `acct_assmt_grp_cust` = %s, `tax_category` = %s, `tax_category_2` = %s, `tax_category_3` = %s, 
            `tax_category_4` = %s, `agent_code` = %s, `broker_agent_code` = %s, 
            `forwarding_agent_code` = %s, `sales_person` = %s, `sales_person_code` = %s, `recon_account` = %s, `sort_key` = %s, 
            `planning_group` = %s, `payment_terms_2` = %s, `payment_methods` = %s, `dunning_procedure` = %s, `relationship_category` = %s
            WHERE `form_number` = %s
        """
        # Add values for 'DISTR. CHANNEL' and 'form_number' to data tuple
        update_data = (
            credit_control_area,
            agent,
            broker_agent,
            forwarding_agent,
            data[0],  # customer_account_group
            data[1],  # company_code
            data[2],  # sales_org
            data[3],  # division
            data[4],  # titles
            data[5],  # name1
            data[6],  # name2
            data[7],  # search1
            data[8],  # search2_old_customer_code
            data[9],  # street3
            data[10],  # street_house_number
            data[11],  # street2
            data[12],  # street
            data[13],  # street4
            data[14],  # street5
            data[15],  # district
            data[16],  # different_city
            data[17],  # pin_code
            data[18],  # city
            data[19],  # country
            data[20],  # region
            data[21],  # language
            data[22],  # telephone_number1
            data[23],  # mobile_number1
            data[24],  # contact_person1_comments_of_mobile_number
            data[25],  # fax
            data[26],  # extension
            data[27],  # email1
            data[28],  # department1_notes_of_email
            data[29],  # mobile_phone2
            data[30],  # contact_person2_comments_of_mobile_number
            data[31],  # email2
            data[32],  # department2_notes_of_email
            data[33],  # mobile_phone3
            data[34],  # contact_person3_comments_of_mobile_number
            data[35],  # email3
            data[36],  # department3_notes_of_email
            data[37],  # legal_form
            data[38],  # bp_type
            data[39],  # pan_card
            data[40],  # gst_category
            data[41],  # gstin_no
            data[42],  # annual_sales
            data[43],  # currency
            data[44],  # sales_year
            data[45],  # sales_district
            data[46],  # sales_office
            data[47],  # sales_group
            data[48],  # currency2
            data[49],  # price_group
            data[50],  # cust_pric_procedure
            data[51],  # order_combination_indicator
            data[52],  # delivering_plant
            data[53],  # shipping_conditions
            data[54],  # underdel_tolerance
            data[55],  # overdeliv_tolerance
            data[56],  # indicator_customer_is_rebate_relevant
            data[57],  # relevant_for_price_determination_id
            data[58],  # incoterms
            data[59],  # incoterms_location
            data[60],  # payment_terms
            data[61],  # credit_control_area
            data[62],  # acct_assmt_grp_cust
            data[63],  # tax_category
            data[64],  # tax_category2
            data[65],  # tax_category3
            data[66],  # tax_category4
            data[67],  # agent
            data[68],  # agent_code
            data[69],  # broker_agent
            data[70],  # broker_agent_code
            data[71],  # forwarding_agent
            data[72],  # forwarding_agent_code
            data[73],  # sales_person
            data[74],  # sales_person_code
            data[75],  # recon_account
            data[76],  # sort_key
            data[77],  # planning_group
            data[78],  # payment_terms2
            form_number  # form_number
        )

        cursor.execute(update_query, update_data)

        # Insert form_number into changesdoneby_marketing table
        insert_query = "INSERT INTO changesdoneby_ar (form_number, date_changed) VALUES (%s, %s)"
        cursor.execute(insert_query, (form_number, current_date))

        conn.commit()
        cursor.close()

        return form_number
    except mysql.connector.Error as err:
        st.error(f"Error inserting data into database: {err}")
        return None



# Set up the Streamlit app layout
st.set_page_config(layout="wide")

# Define columns for logo and title
logo_col, title_col = st.columns([1, 3])

# Display the logo and title
with logo_col:
    st.image('sangam logo.png', width=100)

with title_col:
    st.markdown("<h1 style='text-align: left;'>Please Fill The Below Details</h1>", unsafe_allow_html=True)

# Define columns for form fields
col1, col2, col3, col4 = st.columns(4)

# Set up form fields
fields = {
    'CUSTOMER ACCOUNT GROUP': 'customer_account_group',  # 1
    'COMPANY CODE': 'company_code',  # 2
    'SALES ORG.': 'sales_org',  # 3
    'DISTR. CHANNEL': 'distribution_channel',  # 4
    'DIVISION': 'division',  # 5
    'TITLES': 'titles',  # 6
    'NAME1': 'name_1',  # 7
    'NAME2': 'name_2',  # 8
    'SEARCH 1': 'search_1',  # 9
    'SEARCH 2 (OLD CUSTOMER CODE)': 'search_2_old_customer_code',  # 10
    'STREET 3': 'street_3',  # 11
    'STREET / HOUSE NUMBER': 'street_house_number',  # 12
    'STREET 2': 'street_2',  # 13
    'STREET': 'street',  # 14
    'STREET4': 'street_4',  # 15
    'STREET5': 'street_5',  # 16
    'DISTRICT': 'district',  # 17
    'DIFFERENT CITY': 'different_city',  # 18
    'PIN CODE': 'pin_code',  # 19
    'CITY': 'city',  # 20
    'COUNTRY': 'country',  # 21
    'REGION': 'region',  # 22
    'LANGUANGE': 'language',  # 23
    'TELPHONE NUMBER 1': 'telephone_number_1',  # 24
    'MOBILE NUMBER 1': 'mobile_number_1',  # 25
    'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': 'contact_person_1_comments_of_mobile_number',  # 26
    'FAX': 'fax',  # 27
    'EXTENSION': 'extension',  # 28
    'EMAIL 1': 'email_1',  # 29
    'DEPARTMENT 1 (NOTES OF E-MAIL)': 'department_1_notes_of_email',  # 30
    'MOBILE PHONE-2': 'mobile_phone_2',  # 31
    'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': 'contact_person_2_comments_of_mobile_number',  # 32
    'EMAIL 2': 'email_2',  # 33
    'DEPARTMENT 2 (NOTES OF E-MAIL)': 'department_2_notes_of_email',  # 34
    'MOBILE PHONE-3': 'mobile_phone_3',  # 35
    'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': 'contact_person_3_comments_of_mobile_number',  # 36
    'EMAIL 3': 'email_3',  # 37
    'DEPARTMENT 3 (NOTES OF E-MAIL)': 'department_3_notes_of_email',  # 38
    'LEGAL FORM': 'legal_form',  # 39
    'BP TYPE': 'bp_type',  # 40
    'PAN CARD': 'pan_card',  # 41
    'GST CATEGORY': 'gst_category',  # 42
    'GSTIN NO': 'gstin_no',  # 43
    'ANNUAL SALES': 'annual_sales',  # 44
    'CURRENCY': 'currency',  # 45
    'SALES YEAR': 'sales_year',  # 46
    'SALES DISTRICT': 'sales_district',  # 47
    'SALES OFFICE': 'sales_office',  # 48
    'SALES GROUP': 'sales_group',  # 49
    'CURRENCY2': 'currency_2',  # 50
    'PRICE GROUP': 'price_group',  # 51
    'CUST.PRIC.PROCEDURE': 'cust_pric_procedure',  # 52
    'ORDER COMBINATION INDICATOR': 'order_combination_indicator',  # 53
    'DELIVERING PLANT': 'delivering_plant',  # 54
    'SHIPPING CONDITIONS': 'shipping_conditions',  # 55
    'UNDERDEL. TOLERANCE': 'underdel_tolerance',  # 56
    'OVERDELIV. TOLERANCE': 'overdeliv_tolerance',  # 57
    'INDICATOR: CUSTOMER IS REBATE-RELEVANT': 'indicator_customer_is_rebate_relevant',  # 58
    'RELEVANT FOR PRICE DETERMINATION ID': 'relevant_for_price_determination_id',  # 59
    'INCOTERMS': 'incoterms',  # 60
    'INCOTERMS LOCATION': 'incoterms_location',  # 61
    'PAYMENT TERMS': 'payment_terms',  # 62
    # 'CREDIT CONTROL AREA': 'credit_control_area',  # 63
    'ACCT ASSMT GRP CUST.': 'acct_assmt_grp_cust',  # 64
    'TAX CATEGORY': 'tax_category',  # 65
    'TAX CATEGORY2': 'tax_category_2',  # 66
    'TAX CATEGORY3': 'tax_category_3',  # 67
    'TAX CATEGORY4': 'tax_category_4',  # 68
    # 'AGENT': 'agent',  # 69
    'AGENT-CODE': 'agent_code',  # 70
    # 'BROKER AGENT': 'broker_agent',  # 71
    'BROKER AGENT-CODE': 'broker_agent_code',  # 72
    # 'FORWARDING AGENT': 'forwarding_agent',  # 73
    'FORWARDING AGENT-CODE': 'forwarding_agent_code',  # 74
    'SALES PERSON': 'sales_person',  # 75
    'SALES PERSON-CODE': 'sales_person_code',  # 76
    'RECON ACCOUNT': 'recon_account',  # 77
    'SORT KEY': 'sort_key',  # 78
    'PLANNING GROUP': 'planning_group',  # 79
    'PAYMENT TERMS2': 'payment_terms_2',  # 80
    'PAYMENT METHODS': 'payment_methods',  # 81
    'DUNNING PROCEDURE': 'dunning_procedure',  # 82
    'RELATIONSHIP CATEGORY': 'relationship_category',  # 83
}

dropdown_options = {
    'COMPANY CODE': ['', '1000 - Sangam India Limited', '3000 - Sangam Ventures Limited'],
    'SALES ORG.': ['', '1100 - Spinnig Sales Org', '1200 - Denim Sales Org', '1300 - Weaving Sales Org', '1400 - Processing Sales Org', '1500 - Seamless G Sales Org', '1600 - SIL Seamless', '3500 - SVL Seamless'],
    'DIVISION': ['', '00 - Common Division', '01 - Asset', '02 - Scrap', '03 - Waste', '04 - Store Sales', '05 - Synthetic Yarn', '06 - Cotton Yarn', '07 - Texturized Yarn', '08 - Knitted Fabrics', '09 - Power/Fuel', '10 - Steam', '11 - Fabric (Claim)', '12 - Denim-Fabric', '13 - SurplusYarn', '14 - Process Job', '15 - Garments', '16 - Grey Fabric', '17 - Sangam Suiting', '18 - Anupam Brand', '19 - Export Brand', '20 - Institutional', '21 - Job Weaving', '22 - Fiber', '23 - Seamless Garments', '24 - Dyed Yarn', '25 - Sangam Shirting', '26 - Sizing Job'],
    'LEGAL FORM': ['', '01 - Proprietorship', '02 - Partnership Firm', '03 - Pvt. Ltd.', '04 - Limited', '05 - LLP', '06 - INDIVIDUAL', '07 - Other'],
    'BP TYPE': ['', '0001 - MANUFACTURER', '0002 - TRADER', '0003 - SUPPLIER', '0004 - SERVICE PROVIDER', '0005 - LEASING BUSINESS', '0006 - WAREHOUSE', '0007 - SEZ', '0008 - RETAILER', '0009 - ULTIMATE CONSUMER', '0010 - PARTNER TYPE 0001', '0011 - PARTNER TYPE 0002', '0011 - EMPLOYEE', '0013 - BROKER', '0014 - MANAGER', '0015 - SALES REPRESENTATIVE', '0016 - SALES AGENT', '0017 - STAKEHOLDER'],
    'SALES OFFICE': ['', '0001 - Sales Office South', '1100 - City Office Bhilwara', '1110 - BSL GROUP', '1120 - Others (R, G, SK, Oth)', '1130 - MUMBAI', '1140 - Ludhiana & Amritsar', '1150 - Export', '1160 - Group_Inter division', '1170 - Ahmedabad', '1180 - Delhi', '1200 - Denim plant', '1300 - Atun sales office', '1400 - Processing Sales off'],
    'SALES GROUP': ['', '001 - Sales Group 001', 'C01 - Central I', 'C02 - Central II', 'C03 - Corporate', 'D01 - Delhi/Noida/Gurgaon', 'D02 - Mumbai / Ulhasnagar', 'D03 - Kolkata', 'D04 - Ahmedabad', 'D05 - Brand Sale', 'D06 - Bangalore / Bellary', 'D07 - Ludhiana', 'D08 - Others', 'E01 - East', 'MSG - Miscellaneous sales', 'N01 - North I', 'N02 - North II', 'S01 - South I', 'S02 - South II', 'W01 - West', 'Y01 - City Office Sales G1', 'Y02 - City Office Sales G2', 'Y03 - City Office Sales G3'],
    'CURRENCY': ['', 'None', 'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD', 'BDT', 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL', 'BSD', 'BTN', 'BWP', 'BYN', 'BZD', 'CAD', 'CDF', 'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF', 'DKK', 'DOP', 'DZD', 'EGP', 'ERN', 'ETB', 'EUR', 'FJD', 'FKP', 'FOK', 'GBP', 'GEL', 'GGP', 'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD', 'HKD', 'HNL', 'HRK', 'HTG', 'HUF', 'IDR', 'ILS', 'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD', 'JOD', 'JPY', 'KES', 'KGS', 'KHR', 'KID', 'KMF', 'KPW', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP', 'LKR', 'LRD', 'LSL', 'LYD', 'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR', 'MWK', 'MXN', 'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK', 'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR', 'SDG', 'SEK', 'SGD', 'SHP', 'SLL', 'SOS', 'SRD', 'SSP', 'STN', 'SYP', 'SZL', 'THB', 'TJS', 'TMT', 'TND', 'TOP', 'TRY', 'TTD', 'TVD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD', 'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST', 'XAF', 'XCD', 'XDR', 'XOF', 'XPF', 'YER', 'ZAR', 'ZMW', 'ZWL'],
    'DELIVERING PLANT': ['', 'None', '1100 - Biliya', '1110 - Sareri', '1120 - Soniyana', '1200 - Denim', '1300 - Weaving', '1400 - Process', '1500 - Seamless', '3500 - SVL'],
    'INCOTERMS': ['', 'CFR - Costs and freight', 'CIF - Costs, insurance & freight', 'CIP - Carriage and insurance paid to', 'CPT - Carriage paid to', 'DAF - Delivered at frontier', 'DDP - Delivered Duty Paid', 'DDU - Delivered Duty Unpaid', 'DEQ - Delivered ex quay (duty paid)', 'DES - Delivered ex ship', 'EXW - Ex Works', 'FAS - Free Alongside Ship', 'FCA - Free Carrier', 'FH - Free house', 'FOB - Free on board', 'FOR - FOR MILL', 'UN - Not Free'],
    'INCOTERMS LOCATION': ['', 'Costs and freight', 'Costs, insurance & freight', 'Carriage and insurance paid to', 'Carriage paid to', 'Delivered at frontier', 'Delivered Duty Paid', 'Delivered Duty Unpaid', 'Delivered ex quay (duty paid)', 'Delivered ex ship', 'Ex Works', 'Free Alongside Ship', 'Free Carrier', 'Free house', 'Free on board', 'FOR MILL', 'Not Free'],
    'PAYMENT TERMS': ['', '0001 - Pay immediately w/o deduction', '0002 - 14 days 2%, 30 net', '0003 - 14 days 3%, 20/2%, 30 net', '0004 - as of end of month', '0005 - from the 10th of subs. month', '0006 - End of month 4%, Mid-month 2%', '0007 - 15th/31st subs. month 2%, ...', '0008 - 14 days 2%, 30/1,5%, 45 net', '0009 - Payable in 3 installments', 'A001 - 100% Advance', 'A101 - Against PDC', 'A102 - Part Advance Part PDC', 'A103 - 100% Through Bank', 'A104 - Against PDC 15 Days', 'B030 - L/C At 30 Days From B/L Date', 'B060 - L/C At 60 Days From B/L Date', 'B090 - L/C At 90 Days From B/L Date', 'B120 - L/C At 120 Days From B/L Date', 'B180 - L/C At 180 Days From B/L Date', 'B360 - L/C At 360 Days Fr B/L Dt (EU)', 'C001 - Cash Against Delivery', 'C002 - Advance 2% 7 Days 1%', 'C003 - Within 7 days 5 % cash discount', 'C003 - 7 Days 7%, 15 Days 5%, 30 Days 3%', 'C004 - Within 30 days 1 % cash discount', 'C005 - 3 Days From Delivery with 1% C', 'C006 - 3 Days From Delivery with 1% Cash Discount', 'C007 - 7 Days From Delivery with 2% Cash Discount', 'C008 - 7 Days From Delivery with 2% Cash Discount', 'C009 - Same Day From Delivery with 3% Cash Discount', 'C010 - 2% CD Payment within 6 Days From Date of Invoice', 'C011 - CD 0.50 Per KG Payment within 3 Day from Receipts', 'C012 - CD 1.00 Per KG Payment within 3 Day from Receipts', 'C013 - CD 1.00 Per KG On Next Day Payment', 'C014 - CD 0.50% On Next Day Payment', 'C015 - 1 days from delivery', 'D000 - Against Delivery', 'D001 - 2 Days From Delivery', 'D002 - 3 Days From Delivery', 'D003 - 4 Days From Delivery', 'D004 - 5 Days From Delivery', 'D005 - 6 Days From Delivery', 'D006 - 7 Days From Delivery', 'D007 - 8 days from delivery', 'D008 - 9 days from delivery', 'D009 - 10 Days From Delivery', 'D010 - 11 Days From Delivery', 'D011 - 12 Days From Delivery', 'D012 - 13 days from delivery', 'D013 - 14 days from delivery', 'D014 - 15 Days From Delivery', 'D015 - 16 days from delivery', 'D016 - 17 days from delivery', 'D017 - 18 days from delivery', 'D018 - 19 Days From Delivery', 'D019 - 20 days from delivery', 'D020 - 21 Days From Delivery', 'D021 - 22 days from delivery', 'D022 - 23 days from delivery', 'D023 - 24 days from delivery', 'D024 - 25 Days From Delivery', 'D025 - 26 days from delivery', 'D026 - 27 days from delivery', 'D027 - 28 days from delivery', 'D028 - 29 days from delivery', 'D029 - 30 Days From Delivery', 'D030 - 31 days from delivery', 'D031 - 32 days from delivery', 'D032 - 33 days from delivery', 'D033 - AGAINST LR COPY PAYMENT', 'Z036 - 25% ADV, REM. AFTER 3 DAYS FROM', 'Z037 - 100% ADVANCE, 1% CD', 'Z038 - Payment Within 5 Days, 0.75% C', 'Z039 - Rs 6.00 PER KG CD ON 100% ADV.', 'Z040 - Rs 2.00 PER KG CD, PAYMENT WITH', 'Z042 - Payment after 365 days', 'Z044 - 1% C.D. On Next Day Payment', 'Z046 - 0.5% C.D., Payment in 2 days fr', 'Z047 - 0.5% C.D., Payment in 2 days fr', 'Z049 - 0.5% C.D. On 6th Day Payment', 'Z050 - Rs 0.50 PER KG CD, PAYMENT 2nd', 'Z051 - CD Rs.1/- per kg. on 100% Adva', 'Z052 - Rs 1.25 PER KG QD, PAYMENT 2nd', 'Z053 - 2% C.D., Payment Within 10 Days', 'Z054 - 50 % with in 03 month, 30% six', 'Z055 - CD 1.50%, Payment within 6 Day', 'Z056 - 20% Advance, Rest by D/P', 'Z057 - 20% Advance, 80% 30 Days After', 'Z058 - 1% C.D. , Payment in 5 Days Fr', 'Z059 - QD Rs.1.85/Kg, Payment 2 Days', 'Z060 - QD Rs.1.60/Kg, Payment 2 Days', 'Z062 - 40% Adv, 40% After 1 Month fm Com', 'Z063 - 25% Adv, 50% Agst Installation,', 'Z064 - CD@2% against 15 days payment', 'Z068 - 50% Advance, Balance after 30', 'Z069 - 80% against PI & balance after', 'Z070 - 30% advance, 70% within 15 day', 'Z071 - Within 35 days date of receipt of', 'Z072 - 70% Agst. Proforma invoice 30% af', 'Z073 - AS MENTIONED IN BELOW REMARKS', 'Z074 - 50% advance & balance after si', 'Z075 - QD Rs.1.50/Kg, Payment 2 Days', 'Z076 - 1.50% Cash Discount, 100% Adva', 'Z078 - 1.50% Cash Discount, 100% Advance Payment', 'Z079 - 100% ADVANCE BEFORE DISPATCH', 'Z080 - 100% CASH AGAINST DOCUMENTS', 'Z081 - 100% TT', 'Z082 - 100% TT THRU UCO BANK', 'Z083 - 5000 ADVANCE & BALANCE CAD', 'Z084 - 5000 ADVANCE & BALANCE TT', 'Z085 - 10000 ADVANCE & BALANCE CAD', 'Z086 - 10000 ADVANCE & BALANCE TT', 'Z087 - 20,000 USD ADVANCE AND BAL CAD', 'Z088 - 20,000 USD ADVANCE AND BAL TT', 'Z089 - 15% ADVANCE PAYMENT + BALANCE CAD', 'Z090 - 10% ADVANCE & BALANCE 90% CAD', 'Z091 - 10% ADVANCE & BALANCE 90% TT', 'Z092 - 20% ADVANCE & BALANCE 80% CAD', 'Z093 - 20% ADVANCE & BALANCE 80% TT', 'Z094 - 25% ADVANCE & BALANCE 75% CAD', 'Z095 - 25% ADVANCE & BALANCE 75% TT', 'Z096 - 25% ADVANCE AND BALANCE 75% CAD', 'Z097 - 30% ADVANCE & BALANCE 70% TT', 'Z098 - 30% ADVANCE AND BALANCE 70% CAD', 'Z099 - LC AT SIGHT', 'Z100 - LC AT 30 DAYS FROM BL DATE', 'Z101 - LC AT 45 DAYS FROM BL DATE', 'Z102 - LC AT 60 DAYS FROM BL DATE', 'Z103 - LC AT 90 DAYS FROM BL/ LR DATE', 'Z104 - LC AT 120 DAYS FROM BL/ LR DATE', 'Z105 - LC AT 150 DAYS FROM BL DATE', 'Z106 - LC AT 170 DAYS FROM BL DATE', 'Z107 - DA 120 DAYS FORM BL DATE', 'Z108 - 1% Cash Discount 7 days From date of receipt', 'Z109 - In 7 Days from invoice date', 'Z110 - LC AT 40 DAYS FROM BL DATE', 'Z111 - 60 Days Bill to Bill Payment', 'Z112 - within 15 days Due net', 'Z113 - Within 45 days date of receipt of goods at plant', 'Z114 - Within 50 days date of receipt of goods at plant', 'Z115 - Within 55 days date of receipt of goods at plant', 'Z116 - within 30 days Due net', 'Z117 - Within 5 days date of receipt of goods at plant', 'Z118 - CD 4/- Per Kg 100% Advance Pay', 'Z119 - DOCUMENT AGAINST PAYMENT AT SIGHT', 'Z120 - 30%Adv & bal.70% after inspection before dispatch', 'Z121 - Ship.30%Adv. balance after 45 days of GRN'],
    'SORT KEY': ['', '001 - Allocation number', '002 - Posting date', '003 - Doc.no., fiscal year', '004 - Document date', '005 - Branch account', '006 - Loc.currency amount', '007 - Doc.currency amount', '008 - Bill/exch.due date', '009 - Cost center', '010 - External doc.number', '011 - Purchase order no.', '012 - Plant number', '013 - Vendor number', '014 - Purchase order', '015 - Personnel number', '016 - Settlement period', '017 - Settl.per., pers.no.', '018 - Asset number', '019 - Segment text', '020 - One-time name / city', '021 - One-time city / name', '022 - Document header text', '023 - CPU date', '024 - Pmnt per.bslne date', '025 - Value date', '026 - Asset number', '027 - Pstng month, vendor', '028 - Customer number', '029 - Pstng yr,month,curr.', '030 - Cost center', '031 - Month, cost center', '032 - Contract number', '033 - Order', '034 - Currency key', '035 - Project number', '036 - Fiscal year, month', '037 - Test0', '038 - Test1', '039 - Test5', '040 - Cash discnt clearing', '041 - Test'],
    'PLANNING GROUP': ['', 'A1 - Domestic payments (A/P)', 'A2 - Foreign payments (A/P)', 'A3 - Vendor-affiliated companies', 'A4 - Major vendors', 'A5 - Personnel costs', 'A6 - Tax', 'E1 - Customer receipts (A/R)', 'E2 - Domestic customers', 'E3 - Foreign customers', 'E4 - Customer-affiliated companies', 'E5 - High risk customer', 'E6 - Major customers', 'E7 - Rent received', 'E8 - Loan redemption (A/R)'],
    'PAYMENT TERMS2': ['', '0001 - Pay immediately w/o deduction', '0002 - 14 days 2%, 30 net', '0003 - 14 days 3%, 20/2%, 30 net', '0004 - as of end of month', '0005 - from the 10th of subs. month', '0006 - End of month 4%, Mid-month 2%', '0007 - 15th/31st subs. month 2%, ...', '0008 - 14 days 2%, 30/1,5%, 45 net', '0009 - Payable in 3 installments', 'A001 - 100% Advance', 'A101 - Against PDC', 'A102 - Part Advance Part PDC', 'A103 - 100% Through Bank', 'A104 - Against PDC 15 Days', 'B030 - L/C At 30 Days From B/L Date', 'B060 - L/C At 60 Days From B/L Date', 'B090 - L/C At 90 Days From B/L Date', 'B120 - L/C At 120 Days From B/L Date', 'B180 - L/C At 180 Days From B/L Date', 'B360 - L/C At 360 Days Fr B/L Dt (EU)', 'C001 - Cash Against Delivery', 'C002 - Advance 2% 7 Days 1%', 'C003 - Within 7 days 5 % cash discount', 'C003 - 7 Days 7%, 15 Days 5%, 30 Days 3%', 'C004 - Within 30 days 1 % cash discount', 'C005 - 3 Days From Delivery with 1% C', 'C006 - 3 Days From Delivery with 1% Cash Discount', 'C007 - 7 Days From Delivery with 2% Cash Discount', 'C008 - 7 Days From Delivery with 2% Cash Discount', 'C009 - Same Day From Delivery with 3% Cash Discount', 'C010 - 2% CD Payment within 6 Days From Date of Invoice', 'C011 - CD 0.50 Per KG Payment within 3 Day from Receipts', 'C012 - CD 1.00 Per KG Payment within 3 Day from Receipts', 'C013 - CD 1.00 Per KG On Next Day Payment', 'C014 - CD 0.50% On Next Day Payment', 'C015 - 1 days from delivery', 'D000 - Against Delivery', 'D001 - 2 Days From Delivery', 'D002 - 3 Days From Delivery', 'D003 - 4 Days From Delivery', 'D004 - 5 Days From Delivery', 'D005 - 6 Days From Delivery', 'D006 - 7 Days From Delivery', 'D007 - 8 days from delivery', 'D008 - 9 days from delivery', 'D009 - 10 Days From Delivery', 'D010 - 11 Days From Delivery', 'D011 - 12 Days From Delivery', 'D012 - 13 days from delivery', 'D013 - 14 days from delivery', 'D014 - 15 Days From Delivery', 'D015 - 16 days from delivery', 'D016 - 17 days from delivery', 'D017 - 18 days from delivery', 'D018 - 19 Days From Delivery', 'D019 - 20 days from delivery', 'D020 - 21 Days From Delivery', 'D021 - 22 days from delivery', 'D022 - 23 days from delivery', 'D023 - 24 days from delivery', 'D024 - 25 Days From Delivery', 'D025 - 26 days from delivery', 'D026 - 27 days from delivery', 'D027 - 28 days from delivery', 'D028 - 29 days from delivery', 'D029 - 30 Days From Delivery', 'D030 - 31 days from delivery', 'D031 - 32 days from delivery', 'D032 - 33 days from delivery', 'D033 - AGAINST LR COPY PAYMENT', 'Z036 - 25% ADV, REM. AFTER 3 DAYS FROM', 'Z037 - 100% ADVANCE, 1% CD', 'Z038 - Payment Within 5 Days, 0.75% C', 'Z039 - Rs 6.00 PER KG CD ON 100% ADV.', 'Z040 - Rs 2.00 PER KG CD, PAYMENT WITH', 'Z042 - Payment after 365 days', 'Z044 - 1% C.D. On Next Day Payment', 'Z046 - 0.5% C.D., Payment in 2 days fr', 'Z047 - 0.5% C.D., Payment in 2 days fr', 'Z049 - 0.5% C.D. On 6th Day Payment', 'Z050 - Rs 0.50 PER KG CD, PAYMENT 2nd', 'Z051 - CD Rs.1/- per kg. on 100% Adva', 'Z052 - Rs 1.25 PER KG QD, PAYMENT 2nd', 'Z053 - 2% C.D., Payment Within 10 Days', 'Z054 - 50 % with in 03 month, 30% six', 'Z055 - CD 1.50%, Payment within 6 Day', 'Z056 - 20% Advance, Rest by D/P', 'Z057 - 20% Advance, 80% 30 Days After', 'Z058 - 1% C.D. , Payment in 5 Days Fr', 'Z059 - QD Rs.1.85/Kg, Payment 2 Days', 'Z060 - QD Rs.1.60/Kg, Payment 2 Days', 'Z062 - 40% Adv, 40% After 1 Month fm Com', 'Z063 - 25% Adv, 50% Agst Installation,', 'Z064 - CD@2% against 15 days payment', 'Z068 - 50% Advance, Balance after 30', 'Z069 - 80% against PI & balance after', 'Z070 - 30% advance, 70% within 15 day', 'Z071 - Within 35 days date of receipt of', 'Z072 - 70% Agst. Proforma invoice 30% af', 'Z073 - AS MENTIONED IN BELOW REMARKS', 'Z074 - 50% advance & balance after si', 'Z075 - QD Rs.1.50/Kg, Payment 2 Days', 'Z076 - 1.50% Cash Discount, 100% Adva', 'Z078 - 1.50% Cash Discount, 100% Advance Payment', 'Z079 - 100% ADVANCE BEFORE DISPATCH', 'Z080 - 100% CASH AGAINST DOCUMENTS', 'Z081 - 100% TT', 'Z082 - 100% TT THRU UCO BANK', 'Z083 - 5000 ADVANCE & BALANCE CAD', 'Z084 - 5000 ADVANCE & BALANCE TT', 'Z085 - 10000 ADVANCE & BALANCE CAD', 'Z086 - 10000 ADVANCE & BALANCE TT', 'Z087 - 20,000 USD ADVANCE AND BAL CAD', 'Z088 - 20,000 USD ADVANCE AND BAL TT', 'Z089 - 15% ADVANCE PAYMENT + BALANCE CAD', 'Z090 - 10% ADVANCE & BALANCE 90% CAD', 'Z091 - 10% ADVANCE & BALANCE 90% TT', 'Z092 - 20% ADVANCE & BALANCE 80% CAD', 'Z093 - 20% ADVANCE & BALANCE 80% TT', 'Z094 - 25% ADVANCE & BALANCE 75% CAD', 'Z095 - 25% ADVANCE & BALANCE 75% TT', 'Z096 - 25% ADVANCE AND BALANCE 75% CAD', 'Z097 - 30% ADVANCE & BALANCE 70% TT', 'Z098 - 30% ADVANCE AND BALANCE 70% CAD', 'Z099 - LC AT SIGHT', 'Z100 - LC AT 30 DAYS FROM BL DATE', 'Z101 - LC AT 45 DAYS FROM BL DATE', 'Z102 - LC AT 60 DAYS FROM BL DATE', 'Z103 - LC AT 90 DAYS FROM BL/ LR DATE', 'Z104 - LC AT 120 DAYS FROM BL/ LR DATE', 'Z105 - LC AT 150 DAYS FROM BL DATE', 'Z106 - LC AT 170 DAYS FROM BL DATE', 'Z107 - DA 120 DAYS FORM BL DATE', 'Z108 - 1% Cash Discount 7 days From date of receipt', 'Z109 - In 7 Days from invoice date', 'Z110 - LC AT 40 DAYS FROM BL DATE', 'Z111 - 60 Days Bill to Bill Payment', 'Z112 - within 15 days Due net', 'Z113 - Within 45 days date of receipt of goods at plant', 'Z114 - Within 50 days date of receipt of goods at plant', 'Z115 - Within 55 days date of receipt of goods at plant', 'Z116 - within 30 days Due net', 'Z117 - Within 5 days date of receipt of goods at plant', 'Z118 - CD 4/- Per Kg 100% Advance Pay', 'Z119 - DOCUMENT AGAINST PAYMENT AT SIGHT', 'Z120 - 30%Adv & bal.70% after inspection before dispatch', 'Z121 - Ship.30%Adv. balance after 45 days of GRN'],
    'PAYMENT METHODS': ['', 'C - Cheque', 'E - Cash Payment', 'T - Bank Transfer'],
}

# Set up form data with retrieved values
form_data = {}

# Extract form_number from URL
params = st.query_params
form_number = params.get('form_number', '')

# Connect to MySQL database for fetching data
conn_fetch = connect_to_fetch_database()
if conn_fetch:
    result = fetch_company_email(conn_fetch, form_number)

    # If result is not None, extract company_name and email
    if result:
        (customer_account_group, company_code, sales_org, division, titles, name_1, name_2, search_1, search_2_old_customer_code,
        street_3, street_house_number, street_2, street, street_4, street_5, district, different_city, pin_code, city, country,
        region, telephone_number_1, mobile_number_1, contact_person_1_comments_of_mobile_number, email_1, department_1_notes_of_email,
        mobile_phone_2, contact_person_2_comments_of_mobile_number, email_2, department_2_notes_of_email, mobile_phone_3,
        contact_person_3_comments_of_mobile_number, email_3, department_3_notes_of_email, legal_form, bp_type, pan_card, gstin_no,
        annual_sales, currency, sales_year, sales_district, sales_office, sales_group, currency_2, delivering_plant, overdeliv_tolerance,
        incoterms, incoterms_location, payment_terms, agent_code, broker_agent_code, forwarding_agent_code, sales_person, sales_person_code,
        recon_account, sort_key, planning_group, payment_terms_2, payment_methods, dunning_procedure, relationship_category, distribution_channel,
        language, fax, extension, gst_category, price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions,
        underdel_tolerance, indicator_customer_is_rebate_relevant, relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category,
        tax_category_2, tax_category_3, tax_category_4) = result

        # Set fetched values in the form fields
        form_data = {
            'customer_account_group': customer_account_group or '',
            'company_code': company_code or '',
            'sales_org': sales_org or '',
            'division': division or '',
            'titles': titles or '',
            'name_1': name_1 or '',
            'name_2': name_2 or '',
            'search_1': search_1 or '',
            'search_2_old_customer_code': search_2_old_customer_code or '',
            'street_3': street_3 or '',
            'street_house_number': street_house_number or '',
            'street_2': street_2 or '',
            'street': street or '',
            'street_4': street_4 or '',
            'street_5': street_5 or '',
            'district': district or '',
            'different_city': different_city or '',
            'pin_code': pin_code or '',
            'city': city or '',
            'country': country or '',
            'region': region or '',
            'telephone_number_1': telephone_number_1 or '',
            'mobile_number_1': mobile_number_1 or '',
            'contact_person_1_comments_of_mobile_number': contact_person_1_comments_of_mobile_number or '',
            'email_1': email_1 or '',
            'department_1_notes_of_email': department_1_notes_of_email or '',
            'mobile_phone_2': mobile_phone_2 or '',
            'contact_person_2_comments_of_mobile_number': contact_person_2_comments_of_mobile_number or '',
            'email_2': email_2 or '',
            'department_2_notes_of_email': department_2_notes_of_email or '',
            'mobile_phone_3': mobile_phone_3 or '',
            'contact_person_3_comments_of_mobile_number': contact_person_3_comments_of_mobile_number or '',
            'email_3': email_3 or '',
            'department_3_notes_of_email': department_3_notes_of_email or '',
            'legal_form': legal_form or '',
            'bp_type': bp_type or '',
            'pan_card': pan_card or '',
            'gstin_no': gstin_no or '',
            'annual_sales': annual_sales or '',
            'currency': currency or '',
            'sales_year': sales_year or '',
            'sales_district': sales_district or '',
            'sales_office': sales_office or '',
            'sales_group': sales_group or '',
            'currency_2': currency_2 or '',
            'delivering_plant': delivering_plant or '',
            'overdeliv_tolerance': overdeliv_tolerance or '',
            'incoterms': incoterms or '',
            'incoterms_location': incoterms_location or '',
            'payment_terms': payment_terms or '',
            'agent_code': agent_code or '',
            # 'broker_agent': broker_agent or '',
            'broker_agent_code': broker_agent_code or '',
            # 'forwarding_agent': forwarding_agent or '',
            'forwarding_agent_code': forwarding_agent_code or '',
            'sales_person': sales_person or '',
            'sales_person_code': sales_person_code or '',
            'recon_account': recon_account or '',
            'sort_key': sort_key or '',
            'planning_group': planning_group or '',
            'payment_terms_2': payment_terms_2 or '',
            'payment_methods': payment_methods or '',
            'dunning_procedure': dunning_procedure or '',
            'relationship_category': relationship_category or '',
            'distribution_channel': distribution_channel or '',
            'language': language or '',
            'fax': fax or '',
            'extension': extension or '',
            'gst_category': gst_category or '',
            'price_group': price_group or '',
            'cust_pric_procedure': cust_pric_procedure or '',
            'order_combination_indicator': order_combination_indicator or '',
            'shipping_conditions': shipping_conditions or '',
            'underdel_tolerance': underdel_tolerance or '',
            'indicator_customer_is_rebate_relevant': indicator_customer_is_rebate_relevant or '',
            'relevant_for_price_determination_id': relevant_for_price_determination_id or '',
            'acct_assmt_grp_cust': acct_assmt_grp_cust or '',
            'tax_category': tax_category or '',
            'tax_category_2': tax_category_2 or '',
            'tax_category_3': tax_category_3 or '',
            'tax_category_4': tax_category_4 or '',
            # 'agent': agent or '',
        }
    else:
        st.error(f"No data found for form number {form_number}")
else:
    st.error("Failed to connect to the database.")

with col1:
    for label, field_name in list(fields.items())[:21]:
        if label in dropdown_options:
            form_data[field_name] = st.selectbox(label, dropdown_options[label], index=dropdown_options[label].index(
                form_data.get(field_name, '')) if form_data.get(field_name, '') in dropdown_options[label] else 0)
        elif label in ['NAME1', 'STREET 3', 'STREET 2', 'STREET / HOUSE NUMBER',
                       'TITLES']:  # Check if the field is 'company_name' or 'email'
            st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
        else:
            form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''),
                                                  max_chars=40)

with col2:
    for label, field_name in list(fields.items())[21:42]:
        if label in dropdown_options:
            form_data[field_name] = st.selectbox(label, dropdown_options[label], index=dropdown_options[label].index(
                form_data.get(field_name, '')) if form_data.get(field_name, '') in dropdown_options[label] else 0)
        elif label in ['CITY', 'DISTRICT', 'PIN CODE', 'COUNTRY', 'REGION', 'TELPHONE NUMBER 1', 'MOBILE NUMBER 1',
                       'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)',
                       'EMAIL 1']:  # Check if the field is 'company_name' or 'email'
            st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
        else:
            form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''),
                                                  max_chars=40)

with col3:
    for label, field_name in list(fields.items())[42:63]:
        if label in dropdown_options:
            form_data[field_name] = st.selectbox(label, dropdown_options[label], index=dropdown_options[label].index(
                form_data.get(field_name, '')) if form_data.get(field_name, '') in dropdown_options[label] else 0)
        elif label in ['PAN CARD', 'GSTIN NO']:  # Check if the field is 'company_name' or 'email'
            st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
        else:
            form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''),
                                                  max_chars=40)

with col4:
    for label, field_name in list(fields.items())[63:]:
        if label in dropdown_options:
            form_data[field_name] = st.selectbox(label, dropdown_options[label], index=dropdown_options[label].index(
                form_data.get(field_name, '')) if form_data.get(field_name, '') in dropdown_options[label] else 0)
        elif label in []:  # Check if the field is 'company_name' or 'email'
            st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
        else:
            form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''),
                                                  max_chars=40)

# Submission button
if st.button('Update'):
    valid_submission = True

    # Check for agent
    agent_code = form_data['agent_code'].strip()
    if agent_code and agent_code.lower() != 'none':
        agent = 'ZA'
    else:
        agent = 'None'

    # Check for broker agent
    broker_agent_code = form_data['broker_agent_code'].strip()
    if broker_agent_code and broker_agent_code.lower() != 'none':
        broker_agent = 'ZB'
    else:
        broker_agent = 'None'

    # Check for forwarding agent
    forwarding_agent_code = form_data['forwarding_agent_code'].strip()
    if forwarding_agent_code and forwarding_agent_code.lower() != 'none':
        forwarding_agent = 'CR'
    else:
        forwarding_agent = 'None'

    for label, field_name in fields.items():
        # Check if the field is required and not empty
        if field_name not in dropdown_options and not form_data[field_name]:
            st.error(f'Please enter a valid {label}.')
            valid_submission = False
            break

    if valid_submission:
        st.success('Changes Done successfully!')
        update_conn = connect_to_insert_database()
        if update_conn:
            # Construct data tuple
            data_tuple = tuple(form_data.get(field_name, '') for field_name in fields.values())
            update_database(update_conn, data_tuple, form_number)
            update_conn.close()

# Close the fetch connection
if conn_fetch:
    conn_fetch.close()

# import streamlit as st
# import re
# import mysql.connector
# from streamlit_pdf_viewer import pdf_viewer
# import base64
# import datetime
#
# # Function to validate field based on regular expression
# def validate_field(field_name, field_value):
#     validation_patterns = {
#         'CUSTOMER ACCOUNT GROUP': r'^[A-Z]+$',
#         'COMPANY CODE': r'^[0-9]+$',
#         'SALES ORG.': r'^[0-9]+$',
#         'DIVISION': r'^[0-9]+$',
#         'TITLES': r'^[0-9]+$',
#         'NAME1': r'^[a-zA-Z0-9\s.,()-]+$',
#         'NAME2': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SEARCH 1': r'^[a-zA-Z0-9\s.,()-]*$',
#         'SEARCH 2 (OLD CUSTOMER CODE)': r'^[a-zA-Z0-9\s.,()-]+$',
#         'STREET 3': r'^[a-zA-Z0-9\s.,()-]+$',
#         'STREET / HOUSE NUMBER': r'^[a-zA-Z0-9\s.,()-]+$',
#         'STREET 2': r'^[a-zA-Z0-9\s.,()-]+$',
#         'STREET': r'^[a-zA-Z0-9\s.,()-]+$',
#         'STREET4': r'^[a-zA-Z0-9\s.,()-]+$',
#         'STREET5': r'^[a-zA-Z0-9\s.,()-]+$',
#         'DISTRICT': r'^[a-zA-Z0-9\s.,()-]+$',
#         'DIFFERENT CITY': r'^[a-zA-Z0-9\s.,()-]+$',
#         'PIN CODE': r'^\d{6}$',
#         'CITY': r'^[a-zA-Z0-9\s.,()-]+$',
#         'COUNTRY': r'^[a-zA-Z0-9\s.,()-]+$',
#         'REGION': r'^[a-zA-Z0-9\s.,()-]+$',
#         'TELPHONE NUMBER 1': r'^\d{10}$',
#         'MOBILE NUMBER 1': r'^\d{10}$',
#         'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
#         'FAX': r'^\d{10}$',
#         'EXTENSION': r'^\d{3}$',
#         'EMAIL 1': r'^[\w\.-]+@[\w\.-]+\.\w+$',
#         'DEPARTMENT 1 (NOTES OF E-MAIL)': r'^[a-zA-Z0-9\s.,()-]+$',
#         'MOBILE PHONE-2': r'^\d{10}$',
#         'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
#         'EMAIL 2': r'^[\w\.-]+@[\w\.-]+\.\w+$',
#         'MOBILE PHONE-3': r'^\d{10}$',
#         'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
#         'EMAIL 3': r'^[\w\.-]+@[\w\.-]+\.\w+$',
#         'DEPARTMENT 3 (NOTES OF E-MAIL)': r'^[a-zA-Z0-9\s.,()-]+$',
#         'LEGAL FORM': r'^[a-zA-Z0-9\s.,()-]+$',
#         'BP TYPE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'PAN CARD': r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
#         'GSTIN NO': r'^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$',
#         'ANNUAL SALES': r'^[a-zA-Z0-9\s.,()-]+$',
#         'CURRENCY': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SALES YEAR': r'^\d{4}$',
#         'SALES DISTRICT': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SALES OFFICE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SALES GROUP': r'^[a-zA-Z0-9\s.,()-]+$',
#         'DELIVERING PLANT': r'^[a-zA-Z0-9\s.,()-]+$',
#         'OVERDELIV. TOLERANCE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'INCOTERMS': r'^[a-zA-Z0-9\s.,()-]+$',
#         'INCOTERMS LOCATION': r'^[a-zA-Z0-9\s.,()-]+$',
#         'PAYMENT TERMS': r'^[a-zA-Z0-9\s.,()-]+$',
#         'ACCT ASSMT GRP CUST.': r'^[a-zA-Z0-9\s.,()-]+$',
#         'AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'BROKER AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'FORWARDING AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SALES PERSON': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SALES PERSON-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'RECON ACCOUNT': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SORT KEY': r'^[a-zA-Z0-9\s.,()-]+$',
#         'PLANNING GROUP': r'^[a-zA-Z0-9\s.,()-]+$',
#         'PAYMENT METHODS': r'^[a-zA-Z0-9\s.,()-]+$',
#         'DUNNING PROCEDURE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'RELATIONSHIP CATEGORY': r'^[a-zA-Z0-9\s.,()-]+$',
#     }
#     pattern = validation_patterns.get(field_name)
#     if pattern:
#         return bool(re.match(pattern, field_value))
#     return False
#
# # Connect to MySQL database for inserting data
# def connect_to_insert_database():
#     try:
#         conn = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="",
#             database="formsubmitteddetails"
#         )
#         return conn
#     except mysql.connector.Error as err:
#         st.error(f"Error connecting to MySQL database: {err}")
#         return None
#
# # Connect to MySQL database for fetching data
# def connect_to_fetch_database():
#     try:
#         conn = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="",
#             database="formsubmitteddetails"
#         )
#         return conn
#     except mysql.connector.Error as err:
#         st.error(f"Error connecting to MySQL database: {err}")
#         return None
#
# # Function to fetch company name and email from the database
# def fetch_company_email(conn, form_number):
#     try:
#         cursor = conn.cursor()
#         cursor.execute(f"SELECT titles, name, email, company_name, country, state, city, street_address, street_address2, street_address3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, category FROM form_details WHERE form_number = '{form_number}'")
#         result = cursor.fetchone()
#         cursor.close()
#         return result if result else None
#     except mysql.connector.Error as err:
#         st.error(f"Error fetching data from database: {err}")
#         return None
#
# def pdf_download(pdf_data, filename):
#     with open(filename, "wb") as f:
#         f.write(base64.b64decode(pdf_data))
#
#     st.markdown(f'<a href="data:application/pdf;base64,{base64.b64encode(pdf_data).decode()}" download="{filename}">Download PDF</a>', unsafe_allow_html=True)
#
# # Function to insert form data into the database
# def update_database(conn, data, distribution_channel, language, fax, extension, gst_category, price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance, indicator_customer_is_rebate_relevant, relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category, tax_category2, tax_category3, tax_category4, agent, form_number):
#
#     try:
#         cursor = conn.cursor()
#
#         current_date = datetime.datetime.now().date()
#
#         cursor.execute("SELECT request_number FROM form_details WHERE form_number = %s", (form_number,))
#         result = cursor.fetchone()
#         if result:
#             request_number = result[0]
#         else:
#             st.error("Error fetching request number.")
#             return None
#
#         credit_control_area = int(data[2]) + int(data[3])
#
#         # Insert data into the database along with the form number
#         update_query = """
#             UPDATE marketing_submission
#             SET `credit_control_area` = %s, `customer_account_group` = %s, `company_code` = %s, `sales_org` = %s, `division` = %s, `titles` = %s, `name1` = %s, `name2` = %s, `search_1` = %s, `search_2_old_customer_code` = %s, `street_3` = %s, `street_house_number` = %s, `street_2` = %s, `street` = %s, `street4` = %s, `street5` = %s, `district` = %s, `different_city` = %s, `pin_code` = %s, `city` = %s, `country` = %s, `region` = %s, `telphone_number_1` = %s, `mobile_number_1` = %s, `contact_person_1_comments_of_mobile_number` = %s, `email_1` = %s, `department_1_notes_of_email` = %s, `mobile_phone_2` = %s, `contact_person_2_comments_of_mobile_number` = %s, `email_2` = %s, `department_2_notes_of_email` = %s, `mobile_phone_3` = %s, `contact_person_3_comments_of_mobile_number` = %s, `email_3` = %s, `department_3_notes_of_email` = %s, `legal_form` = %s, `bp_type` = %s, `pan_card` = %s, `gstin_no` = %s, `annual_sales` = %s, `currency` = %s, `sales_year` = %s, `sales_district` = %s, `sales_office` = %s, `sales_group` = %s, `currency2` = %s, `delivering_plant` = %s, `overdeliv_tolerance` = %s, `incoterms` = %s, `incoterms_location` = %s, `payment_terms` = %s, `agent_code` = %s, `broker_agent` = %s, `broker_agent_code` = %s, `forwarding_agent` = %s, `forwarding_agent_code` = %s, `sales_person` = %s, `sales_person_code` = %s, `recon_account` = %s, `sort_key` = %s, `planning_group` = %s, `payment_terms2` = %s, `payment_methods` = %s, `dunning_procedure` = %s, `relationship_category` = %s, `distribution_channel` = %s, `languange` = %s, `fax` = %s, `extension` = %s, `gst_category` = %s, `price_group` = %s, `cust_pric_procedure` = %s, `order_combination_indicator` = %s, `shipping_conditions` = %s, `underdel_tolerance` = %s, `indicator_customer_is_rebate_relevant` = %s, `relevant_for_price_determination_id` = %s, `acct_assmt_grp_cust` = %s, `tax_categry` = %s, `tax_categry2` = %s, `tax_categry3` = %s, `tax_categry4` = %s, `agent` = %s
#             WHERE `form_number` = %s
#         """
#         # Add values for 'DISTR. CHANNEL' and 'form_number' to data tuple
#         update_data = (credit_control_area,) + data + (distribution_channel, language, fax, extension, gst_category, price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance, indicator_customer_is_rebate_relevant, relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category, tax_category2, tax_category3, tax_category4, agent, form_number)
#
#         cursor.execute(update_query, update_data)
#
#         # Insert form_number into changesdoneby_marketing table
#         insert_query = "INSERT INTO changesdoneby_marketing (form_number, date_changed) VALUES (%s, %s)"
#         cursor.execute(insert_query, (form_number, current_date))
#
#         conn.commit()
#         cursor.close()
#
#         return form_number
#     except mysql.connector.Error as err:
#         st.error(f"Error inserting data into database: {err}")
#         return None
#
#
# # Set up the Streamlit app layout
# st.set_page_config(layout="wide")
#
# # Define columns for logo and title
# logo_col, title_col = st.columns([1, 3])
#
# # Display the logo and title
# with logo_col:
#     st.image('sangam logo.png', width=100)
#
# with title_col:
#     st.markdown("<h1 style='text-align: left;'>Please Fill The Below Details</h1>", unsafe_allow_html=True)
#
# # Define columns for form fields
# col1, col2, col3, col4 = st.columns(4)
#
# # Set up form fields
# fields = {
#     'CUSTOMER ACCOUNT GROUP': 'customer_account_group',  # 1
#     'COMPANY CODE': 'company_code',  # 2
#     'SALES ORG.': 'sales_org',  # 3
#     'DIVISION': 'division',  # 5
#     'TITLES': 'titles',  # 6
#     'NAME1': 'name1',  # 7
#     'NAME2': 'name2',  # 8
#     'SEARCH 1': 'search1',  # 9
#     'SEARCH 2 (OLD CUSTOMER CODE)': 'search2_old_customer_code',  # 10
#     'STREET 3': 'street3',  # 11
#     'STREET / HOUSE NUMBER': 'street_house_number',  # 12
#     'STREET 2': 'street2',  # 13
#     'STREET': 'street',  # 14
#     'STREET4': 'street4',  # 15
#     'STREET5': 'street5',  # 16
#     'DISTRICT': 'district',  # 17
#     'DIFFERENT CITY': 'different_city',  # 18
#     'PIN CODE': 'pin_code',  # 19
#     'CITY': 'city',  # 20
#     'COUNTRY': 'country',  # 21
#     'REGION': 'region',  # 22
#     'TELPHONE NUMBER 1': 'telephone_number1',  # 24
#     'MOBILE NUMBER 1': 'mobile_number1',  # 25
#     'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': 'contact_person1_comments_of_mobile_number',  # 26
#     # 'FAX': 'fax',  # 27
#     # 'EXTENSION': 'extension',  # 28
#     'EMAIL 1': 'email1',  # 29
#     'DEPARTMENT 1 (NOTES OF E-MAIL)': 'department1_notes_of_email',  # 30
#     'MOBILE PHONE-2': 'mobile_phone2',  # 31
#     'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': 'contact_person2_comments_of_mobile_number',  # 32
#     'EMAIL 2': 'email2',  # 33
#     'DEPARTMENT 2 (NOTES OF E-MAIL)': 'department2_notes_of_email',  # 34
#     'MOBILE PHONE-3': 'mobile_phone3',  # 35
#     'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': 'contact_person3_comments_of_mobile_number',  # 36
#     'EMAIL 3': 'email3',  # 37
#     'DEPARTMENT 3 (NOTES OF E-MAIL)': 'department3_notes_of_email',  # 38
#     'LEGAL FORM': 'legal_form',  # 39
#     'BP TYPE': 'bp_type',  # 40
#     'PAN CARD': 'pan_card',  # 41
#     'GSTIN NO': 'gstin_no',  # 43
#     'ANNUAL SALES': 'annual_sales',  # 44
#     'CURRENCY': 'currency',  # 45
#     'SALES YEAR': 'sales_year',  # 46
#     'SALES DISTRICT': 'sales_district',  # 47
#     'SALES OFFICE': 'sales_office',  # 48
#     'SALES GROUP': 'sales_group',  # 49
#     'CURRENCY2': 'currency2',  # 50
#     'DELIVERING PLANT': 'delivering_plant',  # 54
#     # 'UNDERDEL. TOLERANCE': 'underdel_tolerance',  # 56
#     'OVERDELIV. TOLERANCE': 'overdeliv_tolerance',  # 57
#     'INCOTERMS': 'incoterms',  # 60
#     'INCOTERMS LOCATION': 'incoterms_location',  # 61
#     'PAYMENT TERMS': 'payment_terms',  # 62
#     # 'CREDIT CONTROL AREA': 'credit_control_area',  # 63
#     # 'AGENT': 'agent',  # 69
#     'AGENT-CODE': 'agent_code',  # 70
#     'BROKER AGENT': 'broker_agent',  # 71
#     'BROKER AGENT-CODE': 'broker_agent_code',  # 72
#     'FORWARDING AGENT': 'forwarding_agent',  # 73
#     'FORWARDING AGENT-CODE': 'forwarding_agent_code',  # 74
#     'SALES PERSON': 'sales_person',  # 75
#     'SALES PERSON-CODE': 'sales_person_code',  # 76
#     'RECON ACCOUNT': 'recon_account',  # 77
#     'SORT KEY': 'sort_key',  # 78
#     'PLANNING GROUP': 'planning_group',  # 79
#     'PAYMENT TERMS2': 'payment_terms2',  # 80
#     'PAYMENT METHODS': 'payment_methods',  # 81
#     'DUNNING PROCEDURE': 'dunning_procedure',# 82
#     'RELATIONSHIP CATEGORY': 'relationship_category'# 83
#
# }
# dropdown_options = {
#     'COMPANY CODE': ['', '1000 - Sangam India Limited', '3000 - Sangam Ventures Limited'],
#     'SALES ORG.': ['', '1100 - Spinnig Sales Org', '1200 - Denim Sales Org', '1300 - Weaving Sales Org', '1400 - Processing Sales Org', '1500 - Seamless G Sales Org', '1600 - SIL Seamless', '3500 - SVL Seamless'],
#     'DIVISION': ['', '00 - Common Division', '01 - Asset', '02 - Scrap', '03 - Waste', '04 - Store Sales', '05 - Synthetic Yarn', '06 - Cotton Yarn', '07 - Texturized Yarn', '08 - Knitted Fabrics', '09 - Power/Fuel', '10 - Steam', '11 - Fabric (Claim)', '12 - Denim-Fabric', '13 - SurplusYarn', '14 - Process Job', '15 - Garments', '16 - Grey Fabric', '17 - Sangam Suiting', '18 - Anupam Brand', '19 - Export Brand', '20 - Institutional', '21 - Job Weaving', '22 - Fiber', '23 - Seamless Garments', '24 - Dyed Yarn', '25 - Sangam Shirting', '26 - Sizing Job'],
#     'LEGAL FORM': ['', '01 - Proprietorship', '02 - Partnership Firm', '03 - Pvt. Ltd.', '04 - Limited', '05 - LLP', '06 - INDIVIDUAL', '07 - Other'],
#     'BP TYPE': ['', '0001 - MANUFACTURER', '0002 - TRADER', '0003 - SUPPLIER', '0004 - SERVICE PROVIDER', '0005 - LEASING BUSINESS', '0006 - WAREHOUSE', '0007 - SEZ', '0008 - RETAILER', '0009 - ULTIMATE CONSUMER', '0010 - PARTNER TYPE 0001', '0011 - PARTNER TYPE 0002', '0011 - EMPLOYEE', '0013 - BROKER', '0014 - MANAGER', '0015 - SALES REPRESENTATIVE', '0016 - SALES AGENT', '0017 - STAKEHOLDER'],
#     'SALES OFFICE': ['', '0001 - Sales Office South', '1100 - City Office Bhilwara', '1110 - BSL GROUP', '1120 - Others (R, G, SK, Oth)', '1130 - MUMBAI', '1140 - Ludhiana & Amritsar', '1150 - Export', '1160 - Group_Inter division', '1170 - Ahmedabad', '1180 - Delhi', '1200 - Denim plant', '1300 - Atun sales office', '1400 - Processing Sales off'],
#     'SALES GROUP': ['', '001 - Sales Group 001', 'C01 - Central I', 'C02 - Central II', 'C03 - Corporate', 'D01 - Delhi/Noida/Gurgaon', 'D02 - Mumbai / Ulhasnagar', 'D03 - Kolkata', 'D04 - Ahmedabad', 'D05 - Brand Sale', 'D06 - Bangalore / Bellary', 'D07 - Ludhiana', 'D08 - Others', 'E01 - East', 'MSG - Miscellaneous sales', 'N01 - North I', 'N02 - North II', 'S01 - South I', 'S02 - South II', 'W01 - West', 'Y01 - City Office Sales G1', 'Y02 - City Office Sales G2', 'Y03 - City Office Sales G3'],
#     'CURRENCY': ['', 'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD', 'BDT', 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL', 'BSD', 'BTN', 'BWP', 'BYN', 'BZD', 'CAD', 'CDF', 'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF', 'DKK', 'DOP', 'DZD', 'EGP', 'ERN', 'ETB', 'EUR', 'FJD', 'FKP', 'FOK', 'GBP', 'GEL', 'GGP', 'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD', 'HKD', 'HNL', 'HRK', 'HTG', 'HUF', 'IDR', 'ILS', 'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD', 'JOD', 'JPY', 'KES', 'KGS', 'KHR', 'KID', 'KMF', 'KPW', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP', 'LKR', 'LRD', 'LSL', 'LYD', 'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR', 'MWK', 'MXN', 'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK', 'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR', 'SDG', 'SEK', 'SGD', 'SHP', 'SLL', 'SOS', 'SRD', 'SSP', 'STN', 'SYP', 'SZL', 'THB', 'TJS', 'TMT', 'TND', 'TOP', 'TRY', 'TTD', 'TVD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD', 'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST', 'XAF', 'XCD', 'XDR', 'XOF', 'XPF', 'YER', 'ZAR', 'ZMW', 'ZWL'],
#     'DELIVERING PLANT': ['', '1100 - Biliya', '1110 - Sareri', '1120 - Soniyana', '1200 - Denim', '1300 - Weaving', '1400 - Process', '1500 - Seamless', '3500 - SVL'],
#     'INCOTERMS': ['', 'CFR - Costs and freight', 'CIF - Costs, insurance & freight', 'CIP - Carriage and insurance paid to', 'CPT - Carriage paid to', 'DAF - Delivered at frontier', 'DDP - Delivered Duty Paid', 'DDU - Delivered Duty Unpaid', 'DEQ - Delivered ex quay (duty paid)', 'DES - Delivered ex ship', 'EXW - Ex Works', 'FAS - Free Alongside Ship', 'FCA - Free Carrier', 'FH - Free house', 'FOB - Free on board', 'FOR - FOR MILL', 'UN - Not Free'],
#     'INCOTERMS LOCATION': ['', 'Costs and freight', 'Costs, insurance & freight', 'Carriage and insurance paid to', 'Carriage paid to', 'Delivered at frontier', 'Delivered Duty Paid', 'Delivered Duty Unpaid', 'Delivered ex quay (duty paid)', 'Delivered ex ship', 'Ex Works', 'Free Alongside Ship', 'Free Carrier', 'Free house', 'Free on board', 'FOR MILL', 'Not Free'],
#     'PAYMENT TERMS': ['', '0001 - Pay immediately w/o deduction', '0002 - 14 days 2%, 30 net', '0003 - 14 days 3%, 20/2%, 30 net', '0004 - as of end of month', '0005 - from the 10th of subs. month', '0006 - End of month 4%, Mid-month 2%', '0007 - 15th/31st subs. month 2%, ...', '0008 - 14 days 2%, 30/1,5%, 45 net', '0009 - Payable in 3 installments', 'A001 - 100% Advance', 'A101 - Against PDC', 'A102 - Part Advance Part PDC', 'A103 - 100% Through Bank', 'A104 - Against PDC 15 Days', 'B030 - L/C At 30 Days From B/L Date', 'B060 - L/C At 60 Days From B/L Date', 'B090 - L/C At 90 Days From B/L Date', 'B120 - L/C At 120 Days From B/L Date', 'B180 - L/C At 180 Days From B/L Date', 'B360 - L/C At 360 Days Fr B/L Dt (EU)', 'C001 - Cash Against Delivery', 'C002 - Advance 2% 7 Days 1%', 'C003 - Within 7 days 5 % cash discount', 'C003 - 7 Days 7%, 15 Days 5%, 30 Days 3%', 'C004 - Within 30 days 1 % cash discount', 'C005 - 3 Days From Delivery with 1% C', 'C006 - 3 Days From Delivery with 1% Cash Discount', 'C007 - 7 Days From Delivery with 2% Cash Discount', 'C008 - 7 Days From Delivery with 2% Cash Discount', 'C009 - Same Day From Delivery with 3% Cash Discount', 'C010 - 2% CD Payment within 6 Days From Date of Invoice', 'C011 - CD 0.50 Per KG Payment within 3 Day from Receipts', 'C012 - CD 1.00 Per KG Payment within 3 Day from Receipts', 'C013 - CD 1.00 Per KG On Next Day Payment', 'C014 - CD 0.50% On Next Day Payment', 'C015 - 1 days from delivery', 'D000 - Against Delivery', 'D001 - 2 Days From Delivery', 'D002 - 3 Days From Delivery', 'D003 - 4 Days From Delivery', 'D004 - 5 Days From Delivery', 'D005 - 6 Days From Delivery', 'D006 - 7 Days From Delivery', 'D007 - 8 days from delivery', 'D008 - 9 days from delivery', 'D009 - 10 Days From Delivery', 'D010 - 11 Days From Delivery', 'D011 - 12 Days From Delivery', 'D012 - 13 days from delivery', 'D013 - 14 days from delivery', 'D014 - 15 Days From Delivery', 'D015 - 16 days from delivery', 'D016 - 17 days from delivery', 'D017 - 18 days from delivery', 'D018 - 19 Days From Delivery', 'D019 - 20 days from delivery', 'D020 - 21 Days From Delivery', 'D021 - 22 days from delivery', 'D022 - 23 days from delivery', 'D023 - 24 days from delivery', 'D024 - 25 Days From Delivery', 'D025 - 26 days from delivery', 'D026 - 27 days from delivery', 'D027 - 28 days from delivery', 'D028 - 29 days from delivery', 'D029 - 30 Days From Delivery', 'D030 - 31 days from delivery', 'D031 - 32 days from delivery', 'D032 - 33 days from delivery', 'D033 - AGAINST LR COPY PAYMENT', 'Z036 - 25% ADV, REM. AFTER 3 DAYS FROM', 'Z037 - 100% ADVANCE, 1% CD', 'Z038 - Payment Within 5 Days, 0.75% C', 'Z039 - Rs 6.00 PER KG CD ON 100% ADV.', 'Z040 - Rs 2.00 PER KG CD, PAYMENT WITH', 'Z042 - Payment after 365 days', 'Z044 - 1% C.D. On Next Day Payment', 'Z046 - 0.5% C.D., Payment in 2 days fr', 'Z047 - 0.5% C.D., Payment in 2 days fr', 'Z049 - 0.5% C.D. On 6th Day Payment', 'Z050 - Rs 0.50 PER KG CD, PAYMENT 2nd', 'Z051 - CD Rs.1/- per kg. on 100% Adva', 'Z052 - Rs 1.25 PER KG QD, PAYMENT 2nd', 'Z053 - 2% C.D., Payment Within 10 Days', 'Z054 - 50 % with in 03 month, 30% six', 'Z055 - CD 1.50%, Payment within 6 Day', 'Z056 - 20% Advance, Rest by D/P', 'Z057 - 20% Advance, 80% 30 Days After', 'Z058 - 1% C.D. , Payment in 5 Days Fr', 'Z059 - QD Rs.1.85/Kg, Payment 2 Days', 'Z060 - QD Rs.1.60/Kg, Payment 2 Days', 'Z062 - 40% Adv, 40% After 1 Month fm Com', 'Z063 - 25% Adv, 50% Agst Installation,', 'Z064 - CD@2% against 15 days payment', 'Z068 - 50% Advance, Balance after 30', 'Z069 - 80% against PI & balance after', 'Z070 - 30% advance, 70% within 15 day', 'Z071 - Within 35 days date of receipt of', 'Z072 - 70% Agst. Proforma invoice 30% af', 'Z073 - AS MENTIONED IN BELOW REMARKS', 'Z074 - 50% advance & balance after si', 'Z075 - QD Rs.1.50/Kg, Payment 2 Days', 'Z076 - 1.50% Cash Discount, 100% Adva', 'Z078 - 1.50% Cash Discount, 100% Advance Payment', 'Z079 - 100% ADVANCE BEFORE DISPATCH', 'Z080 - 100% CASH AGAINST DOCUMENTS', 'Z081 - 100% TT', 'Z082 - 100% TT THRU UCO BANK', 'Z083 - 5000 ADVANCE & BALANCE CAD', 'Z084 - 5000 ADVANCE & BALANCE TT', 'Z085 - 10000 ADVANCE & BALANCE CAD', 'Z086 - 10000 ADVANCE & BALANCE TT', 'Z087 - 20,000 USD ADVANCE AND BAL CAD', 'Z088 - 20,000 USD ADVANCE AND BAL TT', 'Z089 - 15% ADVANCE PAYMENT + BALANCE CAD', 'Z090 - 10% ADVANCE & BALANCE 90% CAD', 'Z091 - 10% ADVANCE & BALANCE 90% TT', 'Z092 - 20% ADVANCE & BALANCE 80% CAD', 'Z093 - 20% ADVANCE & BALANCE 80% TT', 'Z094 - 25% ADVANCE & BALANCE 75% CAD', 'Z095 - 25% ADVANCE & BALANCE 75% TT', 'Z096 - 25% ADVANCE AND BALANCE 75% CAD', 'Z097 - 30% ADVANCE & BALANCE 70% TT', 'Z098 - 30% ADVANCE AND BALANCE 70% CAD', 'Z099 - LC AT SIGHT', 'Z100 - LC AT 30 DAYS FROM BL DATE', 'Z101 - LC AT 45 DAYS FROM BL DATE', 'Z102 - LC AT 60 DAYS FROM BL DATE', 'Z103 - LC AT 90 DAYS FROM BL/ LR DATE', 'Z104 - LC AT 120 DAYS FROM BL/ LR DATE', 'Z105 - LC AT 150 DAYS FROM BL DATE', 'Z106 - LC AT 170 DAYS FROM BL DATE', 'Z107 - DA 120 DAYS FORM BL DATE', 'Z108 - 1% Cash Discount 7 days From date of receipt', 'Z109 - In 7 Days from invoice date', 'Z110 - LC AT 40 DAYS FROM BL DATE', 'Z111 - 60 Days Bill to Bill Payment', 'Z112 - within 15 days Due net', 'Z113 - Within 45 days date of receipt of goods at plant', 'Z114 - Within 50 days date of receipt of goods at plant', 'Z115 - Within 55 days date of receipt of goods at plant', 'Z116 - within 30 days Due net', 'Z117 - Within 5 days date of receipt of goods at plant', 'Z118 - CD 4/- Per Kg 100% Advance Pay', 'Z119 - DOCUMENT AGAINST PAYMENT AT SIGHT', 'Z120 - 30%Adv & bal.70% after inspection before dispatch', 'Z121 - Ship.30%Adv. balance after 45 days of GRN'],
#     'SORT KEY': ['', '001 - Allocation number', '002 - Posting date', '003 - Doc.no., fiscal year', '004 - Document date', '005 - Branch account', '006 - Loc.currency amount', '007 - Doc.currency amount', '008 - Bill/exch.due date', '009 - Cost center', '010 - External doc.number', '011 - Purchase order no.', '012 - Plant number', '013 - Vendor number', '014 - Purchase order', '015 - Personnel number', '016 - Settlement period', '017 - Settl.per., pers.no.', '018 - Asset number', '019 - Segment text', '020 - One-time name / city', '021 - One-time city / name', '022 - Document header text', '023 - CPU date', '024 - Pmnt per.bslne date', '025 - Value date', '026 - Asset number', '027 - Pstng month, vendor', '028 - Customer number', '029 - Pstng yr,month,curr.', '030 - Cost center', '031 - Month, cost center', '032 - Contract number', '033 - Order', '034 - Currency key', '035 - Project number', '036 - Fiscal year, month', '037 - Test0', '038 - Test1', '039 - Test5', '040 - Cash discnt clearing', '041 - Test'],
#     'PLANNING GROUP': ['', 'A1 - Domestic payments (A/P)', 'A2 - Foreign payments (A/P)', 'A3 - Vendor-affiliated companies', 'A4 - Major vendors', 'A5 - Personnel costs', 'A6 - Tax', 'E1 - Customer receipts (A/R)', 'E2 - Domestic customers', 'E3 - Foreign customers', 'E4 - Customer-affiliated companies', 'E5 - High risk customer', 'E6 - Major customers', 'E7 - Rent received', 'E8 - Loan redemption (A/R)'],
#     'PAYMENT TERMS2': ['', '0001 - Pay immediately w/o deduction', '0002 - 14 days 2%, 30 net', '0003 - 14 days 3%, 20/2%, 30 net', '0004 - as of end of month', '0005 - from the 10th of subs. month', '0006 - End of month 4%, Mid-month 2%', '0007 - 15th/31st subs. month 2%, ...', '0008 - 14 days 2%, 30/1,5%, 45 net', '0009 - Payable in 3 installments', 'A001 - 100% Advance', 'A101 - Against PDC', 'A102 - Part Advance Part PDC', 'A103 - 100% Through Bank', 'A104 - Against PDC 15 Days', 'B030 - L/C At 30 Days From B/L Date', 'B060 - L/C At 60 Days From B/L Date', 'B090 - L/C At 90 Days From B/L Date', 'B120 - L/C At 120 Days From B/L Date', 'B180 - L/C At 180 Days From B/L Date', 'B360 - L/C At 360 Days Fr B/L Dt (EU)', 'C001 - Cash Against Delivery', 'C002 - Advance 2% 7 Days 1%', 'C003 - Within 7 days 5 % cash discount', 'C003 - 7 Days 7%, 15 Days 5%, 30 Days 3%', 'C004 - Within 30 days 1 % cash discount', 'C005 - 3 Days From Delivery with 1% C', 'C006 - 3 Days From Delivery with 1% Cash Discount', 'C007 - 7 Days From Delivery with 2% Cash Discount', 'C008 - 7 Days From Delivery with 2% Cash Discount', 'C009 - Same Day From Delivery with 3% Cash Discount', 'C010 - 2% CD Payment within 6 Days From Date of Invoice', 'C011 - CD 0.50 Per KG Payment within 3 Day from Receipts', 'C012 - CD 1.00 Per KG Payment within 3 Day from Receipts', 'C013 - CD 1.00 Per KG On Next Day Payment', 'C014 - CD 0.50% On Next Day Payment', 'C015 - 1 days from delivery', 'D000 - Against Delivery', 'D001 - 2 Days From Delivery', 'D002 - 3 Days From Delivery', 'D003 - 4 Days From Delivery', 'D004 - 5 Days From Delivery', 'D005 - 6 Days From Delivery', 'D006 - 7 Days From Delivery', 'D007 - 8 days from delivery', 'D008 - 9 days from delivery', 'D009 - 10 Days From Delivery', 'D010 - 11 Days From Delivery', 'D011 - 12 Days From Delivery', 'D012 - 13 days from delivery', 'D013 - 14 days from delivery', 'D014 - 15 Days From Delivery', 'D015 - 16 days from delivery', 'D016 - 17 days from delivery', 'D017 - 18 days from delivery', 'D018 - 19 Days From Delivery', 'D019 - 20 days from delivery', 'D020 - 21 Days From Delivery', 'D021 - 22 days from delivery', 'D022 - 23 days from delivery', 'D023 - 24 days from delivery', 'D024 - 25 Days From Delivery', 'D025 - 26 days from delivery', 'D026 - 27 days from delivery', 'D027 - 28 days from delivery', 'D028 - 29 days from delivery', 'D029 - 30 Days From Delivery', 'D030 - 31 days from delivery', 'D031 - 32 days from delivery', 'D032 - 33 days from delivery', 'D033 - AGAINST LR COPY PAYMENT', 'Z036 - 25% ADV, REM. AFTER 3 DAYS FROM', 'Z037 - 100% ADVANCE, 1% CD', 'Z038 - Payment Within 5 Days, 0.75% C', 'Z039 - Rs 6.00 PER KG CD ON 100% ADV.', 'Z040 - Rs 2.00 PER KG CD, PAYMENT WITH', 'Z042 - Payment after 365 days', 'Z044 - 1% C.D. On Next Day Payment', 'Z046 - 0.5% C.D., Payment in 2 days fr', 'Z047 - 0.5% C.D., Payment in 2 days fr', 'Z049 - 0.5% C.D. On 6th Day Payment', 'Z050 - Rs 0.50 PER KG CD, PAYMENT 2nd', 'Z051 - CD Rs.1/- per kg. on 100% Adva', 'Z052 - Rs 1.25 PER KG QD, PAYMENT 2nd', 'Z053 - 2% C.D., Payment Within 10 Days', 'Z054 - 50 % with in 03 month, 30% six', 'Z055 - CD 1.50%, Payment within 6 Day', 'Z056 - 20% Advance, Rest by D/P', 'Z057 - 20% Advance, 80% 30 Days After', 'Z058 - 1% C.D. , Payment in 5 Days Fr', 'Z059 - QD Rs.1.85/Kg, Payment 2 Days', 'Z060 - QD Rs.1.60/Kg, Payment 2 Days', 'Z062 - 40% Adv, 40% After 1 Month fm Com', 'Z063 - 25% Adv, 50% Agst Installation,', 'Z064 - CD@2% against 15 days payment', 'Z068 - 50% Advance, Balance after 30', 'Z069 - 80% against PI & balance after', 'Z070 - 30% advance, 70% within 15 day', 'Z071 - Within 35 days date of receipt of', 'Z072 - 70% Agst. Proforma invoice 30% af', 'Z073 - AS MENTIONED IN BELOW REMARKS', 'Z074 - 50% advance & balance after si', 'Z075 - QD Rs.1.50/Kg, Payment 2 Days', 'Z076 - 1.50% Cash Discount, 100% Adva', 'Z078 - 1.50% Cash Discount, 100% Advance Payment', 'Z079 - 100% ADVANCE BEFORE DISPATCH', 'Z080 - 100% CASH AGAINST DOCUMENTS', 'Z081 - 100% TT', 'Z082 - 100% TT THRU UCO BANK', 'Z083 - 5000 ADVANCE & BALANCE CAD', 'Z084 - 5000 ADVANCE & BALANCE TT', 'Z085 - 10000 ADVANCE & BALANCE CAD', 'Z086 - 10000 ADVANCE & BALANCE TT', 'Z087 - 20,000 USD ADVANCE AND BAL CAD', 'Z088 - 20,000 USD ADVANCE AND BAL TT', 'Z089 - 15% ADVANCE PAYMENT + BALANCE CAD', 'Z090 - 10% ADVANCE & BALANCE 90% CAD', 'Z091 - 10% ADVANCE & BALANCE 90% TT', 'Z092 - 20% ADVANCE & BALANCE 80% CAD', 'Z093 - 20% ADVANCE & BALANCE 80% TT', 'Z094 - 25% ADVANCE & BALANCE 75% CAD', 'Z095 - 25% ADVANCE & BALANCE 75% TT', 'Z096 - 25% ADVANCE AND BALANCE 75% CAD', 'Z097 - 30% ADVANCE & BALANCE 70% TT', 'Z098 - 30% ADVANCE AND BALANCE 70% CAD', 'Z099 - LC AT SIGHT', 'Z100 - LC AT 30 DAYS FROM BL DATE', 'Z101 - LC AT 45 DAYS FROM BL DATE', 'Z102 - LC AT 60 DAYS FROM BL DATE', 'Z103 - LC AT 90 DAYS FROM BL/ LR DATE', 'Z104 - LC AT 120 DAYS FROM BL/ LR DATE', 'Z105 - LC AT 150 DAYS FROM BL DATE', 'Z106 - LC AT 170 DAYS FROM BL DATE', 'Z107 - DA 120 DAYS FORM BL DATE', 'Z108 - 1% Cash Discount 7 days From date of receipt', 'Z109 - In 7 Days from invoice date', 'Z110 - LC AT 40 DAYS FROM BL DATE', 'Z111 - 60 Days Bill to Bill Payment', 'Z112 - within 15 days Due net', 'Z113 - Within 45 days date of receipt of goods at plant', 'Z114 - Within 50 days date of receipt of goods at plant', 'Z115 - Within 55 days date of receipt of goods at plant', 'Z116 - within 30 days Due net', 'Z117 - Within 5 days date of receipt of goods at plant', 'Z118 - CD 4/- Per Kg 100% Advance Pay', 'Z119 - DOCUMENT AGAINST PAYMENT AT SIGHT', 'Z120 - 30%Adv & bal.70% after inspection before dispatch', 'Z121 - Ship.30%Adv. balance after 45 days of GRN'],
#     'PAYMENT METHODS': ['', 'C - Cheque', 'E - Cash Payment', 'T - Bank Transfer'],
# }
#
# fixed_values = {
#     'DISTR. CHANNEL': '00',
#     'LANGUANGE': 'EN',
#     'FAX': 'None',
#     'EXTENSION': 'None',
#     'GST CATEGORY': 'IN3',
#     'PRICE GROUP': '01',
#     'CUST.PRIC.PROCEDURE': '1',
#     'ORDER COMBINATION INDICATOR': 'X',
#     'SHIPPING CONDITIONS': '01',
#     'UNDERDEL. TOLERANCE': 'None',
#     'INDICATOR: CUSTOMER IS REBATE-RELEVANT': 'X',
#     'RELEVANT FOR PRICE DETERMINATION ID': 'X',
#     'ACCT ASSMT GRP CUST.': '01',
#     'TAX CATEGORY': '0',
#     'TAX CATEGORY2': '0',
#     'TAX CATEGORY3': '0',
#     'TAX CATEGORY4': '0',
#     'AGENT': 'ZA',
#     # Add more fields and their fixed values here
# }
#
# editable_fixed_values = {
#     'SEARCH 2 (OLD CUSTOMER CODE)': 'NEW CODE',
#     'NAME2': 'None',
#     'SEARCH 1': 'None',
#     'STREET / HOUSE NUMBER': 'None',
#     'STREET': 'None',
#     'STREET4': 'None',
#     'STREET5': 'None',
#     'DIFFERENT CITY': 'None',
#     'DEPARTMENT 1 (NOTES OF E-MAIL)': 'None',
#     'MOBILE PHONE-2': 'None',
#     'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': 'None',
#     'EMAIL 2': 'None',
#     'OVERDELIV. TOLERANCE': '5',
#     'DEPARTMENT 2 (NOTES OF E-MAIL)': 'None',
#     'MOBILE PHONE-3': 'None',
#     'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': 'None',
#     'EMAIL 3': 'None',
#     'DEPARTMENT 3 (NOTES OF E-MAIL)': 'None',
#     'ANNUAL SALES': 'None',
#     'CURRENCY2': 'None',
#     'SALES YEAR': 'None',
#     'SALES DISTRICT': 'None',
#     'AGENT-CODE': 'None',
#     'BROKER AGENT': 'None',
#     'BROKER AGENT-CODE': 'None',
#     'FORWARDING AGENT': 'None',
#     'FORWARDING AGENT-CODE': 'None',
#     'SALES PERSON': 'None',
#     'SALES PERSON-CODE': 'None',
#     'RECON ACCOUNT': 'None',
#     'DUNNING PROCEDURE': 'None',
#     'RELATIONSHIP CATEGORY': 'None'
# }
# # Set up form data with retrieved values
# form_data = {}
#
# # Extract form_number from URL
# params = st.query_params
# form_number = params.get('form_number', '')
#
# # Connect to MySQL database for fetching data
# conn_fetch = connect_to_fetch_database()
# if conn_fetch:
#     result = fetch_company_email(conn_fetch, form_number)
#
#     # If result is not None, extract company_name and email
#     if result:
#         (titles, name, email, company_name, country, state, city, street_address, street_address2, street_address3, postal_code,
#         phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, category) = result
#
#         # Set fetched values in the form fields
#         form_data = {
#             'titles': titles,
#             'contact_person1_comments_of_mobile_number': name,
#             'email1': email,
#             'name1': company_name,
#             'country': country,
#             'state': state,
#             'district': city,
#             'city': city,
#             'street3': street_address,
#             'street2': street_address2,
#             'street_house_number': street_address3,
#             'pin_code': postal_code,
#             'telephone_number1': phone_number,
#             'mobile_number1': mobile_number,
#             'gstin_no': gst_number,
#             'pan_card': pan_number,
#             'region': region,
#             'customer_account_group': category,
#         }
#     else:
#         st.error(f"No data found for form number {form_number}")
# else:
#     st.error("Failed to connect to the database.")
#
# with col1:
#     for label, field_name in list(fields.items())[:16]:
#         if label in dropdown_options:
#             form_data[field_name] = st.selectbox(label, dropdown_options[label])
#         elif label not in fixed_values:  # Exclude fields from fixed_values
#             if label in ['NAME1', 'STREET 3', 'STREET 2', 'STREET / HOUSE NUMBER', 'TITLES']:  # Check if the field is 'company_name' or 'email'
#                 st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
#             elif label in editable_fixed_values:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=editable_fixed_values[label], max_chars=40)
#             else:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''), max_chars=40)
#
# # col2
# with col2:
#     for label, field_name in list(fields.items())[16:32]:
#         if label in dropdown_options:
#             form_data[field_name] = st.selectbox(label, dropdown_options[label])
#         elif label not in fixed_values:  # Exclude fields from fixed_values
#             if label in ['CITY', 'DISTRICT', 'PIN CODE', 'COUNTRY', 'REGION', 'TELPHONE NUMBER 1', 'MOBILE NUMBER 1', 'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)', 'EMAIL 1']:  # Check if the field is 'company_name' or 'email'
#                 st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
#             elif label in editable_fixed_values:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=editable_fixed_values[label], max_chars=40)
#             else:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''), max_chars=40)
#
# # col3
# with col3:
#     for label, field_name in list(fields.items())[32:48]:
#         if label in dropdown_options:
#             form_data[field_name] = st.selectbox(label, dropdown_options[label])
#         elif label not in fixed_values:  # Exclude fields from fixed_values
#             if label in ['PAN CARD', 'GSTIN NO']:  # Check if the field is 'company_name' or 'email'
#                 st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
#             elif label in editable_fixed_values:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=editable_fixed_values[label], max_chars=40)
#             else:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''), max_chars=40)
#
# # col4
# with col4:
#     for label, field_name in list(fields.items())[48:]:
#         if label in dropdown_options:
#             form_data[field_name] = st.selectbox(label, dropdown_options[label])
#         elif label not in fixed_values:  # Exclude fields from fixed_values
#             if label in editable_fixed_values:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=editable_fixed_values[label], max_chars=40)
#             else:
#                 form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''), max_chars=40)
#
#     # Display buttons to view documents
# if gst_document:
#     if st.button('View GST Document'):
#         st.header("GST Document")
#         pdf_viewer(gst_document)
#         pdf_download(gst_document, 'GST_Document.pdf')
# else:
#     st.error("No GST document found.")
#
# if pan_document:
#     if st.button('View PAN Document'):
#         st.header("PAN Document")
#         pdf_viewer(pan_document)
#         pdf_download(pan_document, 'PAN_Document.pdf')
# else:
#     st.error("No PAN document found.")
#
# # Submission button
# if st.button('Update'):
#     valid_submission = True
#     for label, field_name in fields.items():
#         # Check if the field is required and not empty
#         if field_name not in dropdown_options and not form_data[field_name]:
#             st.error(f'Please enter a valid {label}.')
#             valid_submission = False
#             break
#         # If the field is in dropdown_options, it's not empty
#         elif field_name in dropdown_options:
#             # Validate the field if it's not in the fields_to_skip_validation list
#             if field_name not in fields_to_skip_validation:
#                 if not validate_field(field_name, form_data[field_name]):
#                     st.error(f'Please enter a valid {label}.')
#                     valid_submission = False
#                     break
#
#     if valid_submission:
#         st.success('Changes Done successfully!')
#         update_conn = connect_to_insert_database()
#         if update_conn:
#             # Construct data tuple
#             data_tuple = tuple(form_data.get(field_name, '') for field_name in fields.values() if field_name not in fixed_values)
#             distribution_channel = fixed_values['DISTR. CHANNEL']
#             language = fixed_values['LANGUANGE']
#             fax = fixed_values['FAX']
#             extension = fixed_values['EXTENSION']
#             gst_category = fixed_values['GST CATEGORY']
#             price_group = fixed_values['PRICE GROUP']
#             cust_pric_procedure = fixed_values['CUST.PRIC.PROCEDURE']
#             order_combination_indicator = fixed_values['ORDER COMBINATION INDICATOR']
#             shipping_conditions = fixed_values['SHIPPING CONDITIONS']
#             underdel_tolerance = fixed_values['UNDERDEL. TOLERANCE']
#             indicator_customer_is_rebate_relevant = fixed_values['INDICATOR: CUSTOMER IS REBATE-RELEVANT']
#             relevant_for_price_determination_id = fixed_values['RELEVANT FOR PRICE DETERMINATION ID']
#             acct_assmt_grp_cust = fixed_values['ACCT ASSMT GRP CUST.']
#             tax_category = fixed_values['TAX CATEGORY']
#             tax_category2 = fixed_values['TAX CATEGORY2']
#             tax_category3 = fixed_values['TAX CATEGORY3']
#             tax_category4 = fixed_values['TAX CATEGORY4']
#             agent = fixed_values['AGENT']
#             update_database(update_conn, data_tuple, distribution_channel, language, fax, extension, gst_category, price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance, indicator_customer_is_rebate_relevant, relevant_for_price_determination_id, acct_assmt_grp_cust, tax_category, tax_category2, tax_category3, tax_category4, agent, form_number)
