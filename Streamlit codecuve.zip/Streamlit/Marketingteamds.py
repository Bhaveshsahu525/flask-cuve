import streamlit as st
import re
import mysql.connector
from streamlit_pdf_viewer import pdf_viewer
import base64
import datetime

# Initialize session state variables
if 'viewed_gst' not in st.session_state:
    st.session_state.viewed_gst = False

if 'viewed_pan' not in st.session_state:
    st.session_state.viewed_pan = False


# Function to validate field based on regular expression
def validate_field(field_name, field_value):
    validation_patterns = {
        'CUSTOMER ACCOUNT GROUP': r'^[A-Z]+$',
        'COMPANY CODE': r'^[0-9]+$',
        'SALES ORG.': r'^[0-9]+$',
        'DIVISION': r'^[0-9]+$',
        'TITLES': r'^[0-9]+$',
        'NAME1': r'^[a-zA-Z0-9\s.,()-]+$',
        'NAME2': r'^[a-zA-Z0-9\s.,()-]+$',
        'SEARCH 1': r'^[a-zA-Z0-9\s.,()-]*$',
        'SEARCH 2 (OLD CUSTOMER CODE)': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET 3': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET / HOUSE NUMBER': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET 2': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET4': r'^[a-zA-Z0-9\s.,()-]+$',
        'STREET5': r'^[a-zA-Z0-9\s.,()-]+$',
        'DISTRICT': r'^[a-zA-Z0-9\s.,()-]+$',
        'DIFFERENT CITY': r'^[a-zA-Z0-9\s.,()-]+$',
        'PIN CODE': r'^\d{6}$',
        'CITY': r'^[a-zA-Z0-9\s.,()-]+$',
        'COUNTRY': r'^[a-zA-Z0-9\s.,()-]+$',
        'REGION': r'^[a-zA-Z0-9\s.,()-]+$',
        'TELPHONE NUMBER 1': r'^\d{10}$',
        'MOBILE NUMBER 1': r'^\d{10}$',
        'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
        'FAX': r'^\d{10}$',
        'EXTENSION': r'^\d{3}$',
        'EMAIL 1': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'DEPARTMENT 1 (NOTES OF E-MAIL)': r'^[a-zA-Z0-9\s.,()-]+$',
        'MOBILE PHONE-2': r'^\d{10}$',
        'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
        'EMAIL 2': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'MOBILE PHONE-3': r'^\d{10}$',
        'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': r'^[a-zA-Z0-9\s.,()-]+$',
        'EMAIL 3': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'DEPARTMENT 3 (NOTES OF E-MAIL)': r'^[a-zA-Z0-9\s.,()-]+$',
        'LEGAL FORM': r'^[a-zA-Z0-9\s.,()-]+$',
        'BP TYPE': r'^[a-zA-Z0-9\s.,()-]+$',
        'PAN CARD': r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
        'GSTIN NO': r'^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$',
        'ANNUAL SALES': r'^[a-zA-Z0-9\s.,()-]+$',
        'CURRENCY': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES YEAR': r'^\d{4}$',
        'SALES DISTRICT': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES OFFICE': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES GROUP': r'^[a-zA-Z0-9\s.,()-]+$',
        'DELIVERING PLANT': r'^[a-zA-Z0-9\s.,()-]+$',
        'OVERDELIV. TOLERANCE': r'^[a-zA-Z0-9\s.,()-]+$',
        'INCOTERMS': r'^[a-zA-Z0-9\s.,()-]+$',
        'INCOTERMS LOCATION': r'^[a-zA-Z0-9\s.,()-]+$',
        'PAYMENT TERMS': r'^[a-zA-Z0-9\s.,()-]+$',
        'ACCT ASSMT GRP CUST.': r'^[a-zA-Z0-9\s.,()-]+$',
        'AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'BROKER AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'FORWARDING AGENT-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES PERSON': r'^[a-zA-Z0-9\s.,()-]+$',
        'SALES PERSON-CODE': r'^[a-zA-Z0-9\s.,()-]+$',
        'RECON ACCOUNT': r'^[a-zA-Z0-9\s.,()-]+$',
        'SORT KEY': r'^[a-zA-Z0-9\s.,()-]+$',
        'PLANNING GROUP': r'^[a-zA-Z0-9\s.,()-]+$',
        'PAYMENT METHODS': r'^[a-zA-Z0-9\s.,()-]+$',
        'DUNNING PROCEDURE': r'^[a-zA-Z0-9\s.,()-]+$',
        'RELATIONSHIP CATEGORY': r'^[a-zA-Z0-9\s.,()-]+$',
    }
    pattern = validation_patterns.get(field_name)
    if pattern:
        return bool(re.match(pattern, field_value))
    return False


# Connect to MySQL database for inserting data
def connect_to_insert_database():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="formsubmitteddetails"
        )
        return conn
    except mysql.connector.Error as err:
        st.error(f"Error connecting to MySQL database: {err}")
        return None


# Connect to MySQL database for fetching data
def connect_to_fetch_database():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="formsubmitteddetails"
        )
        return conn
    except mysql.connector.Error as err:
        st.error(f"Error connecting to MySQL database: {err}")
        return None


# Function to fetch company name and email from the database
def fetch_company_email(conn, form_number):
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, category FROM form_details WHERE form_number = '{form_number}'")
        result = cursor.fetchone()
        cursor.close()
        return result if result else None
    except mysql.connector.Error as err:
        st.error(f"Error fetching data from database: {err}")
        return None


def pdf_download(pdf_data, filename):
    with open(filename, "wb") as f:
        f.write(base64.b64decode(pdf_data))

    st.markdown(
        f'<a href="data:application/pdf;base64,{base64.b64encode(pdf_data).decode()}" download="{filename}">Download PDF</a>',
        unsafe_allow_html=True)


# Function to insert form data into the database
def insert_into_database(conn, data, distribution_channel, name_2, search_2_old_customer_code, street, street_4,
                         street_5, language, fax, extension, gst_category, price_group, cust_pric_procedure,
                         order_combination_indicator, shipping_conditions, underdel_tolerance,
                         indicator_customer_is_rebate_relevant, relevant_for_price_determination_id,
                         acct_assmt_grp_cust, tax_category, tax_category_2, tax_category_3, tax_category_4,
                         sales_person, sales_person_code, relationship_category, agent, broker_agent, forwarding_agent,
                         form_number):
    try:
        cursor = conn.cursor()

        current_date = datetime.datetime.now().date()

        cursor.execute("SELECT request_number FROM form_details WHERE form_number = %s", (form_number,))
        result = cursor.fetchone()
        if result:
            request_number = result[0]
        else:
            st.error("Error fetching request number.")
            return None

        sales_org_numeric = int(re.search(r'\d+', data[2]).group())
        division_numeric = int(re.search(r'\d+', data[3]).group())
        credit_control_area = sales_org_numeric + division_numeric

        # Insert data into the database along with the form number
        query = """
            INSERT INTO marketing_submission (
                `customer_account_group`, `company_code`, `sales_org`, `division`, `titles`, `name_1`, `search_1`, 
                `street_3`, `street_house_number`, `street_2`,  
                `district`, `different_city`, `pin_code`, `city`, `country`, `region`, `telephone_number_1`, `mobile_number_1`, 
                `contact_person_1_comments_of_mobile_number`, `email_1`, `department_1_notes_of_email`, `mobile_phone_2`, 
                `contact_person_2_comments_of_mobile_number`, `email_2`, `department_2_notes_of_email`, `mobile_phone_3`, 
                `contact_person_3_comments_of_mobile_number`, `email_3`, `department_3_notes_of_email`, `legal_form`, `bp_type`, 
                `pan_card`, `gstin_no`, `annual_sales`, `currency`, `sales_year`, `sales_district`, `sales_office`, `sales_group`, 
                `currency_2`, `delivering_plant`, `overdeliv_tolerance`, `incoterms`, `incoterms_location`, `payment_terms`, 
                `agent_code`, `broker_agent_code`, `forwarding_agent_code`,
                `recon_account`, `sort_key`, `planning_group`, `payment_terms_2`, `payment_methods`, `dunning_procedure`, 
                `distribution_channel`, `name_2`, `search_2_old_customer_code`, `street`, `street_4`, `street_5`, `language`, `fax`, `extension`, `gst_category`, `price_group`, 
                `cust_pric_procedure`, `order_combination_indicator`, `shipping_conditions`, `underdel_tolerance`, `indicator_customer_is_rebate_relevant`, 
                `relevant_for_price_determination_id`, `acct_assmt_grp_cust`, `tax_category`, `tax_category_2`, `tax_category_3`, `tax_category_4`, `sales_person`, `sales_person_code`, `relationship_category`,  
                `agent`, `broker_agent`, `forwarding_agent`, `form_number`, `request_number`, `submission_date`, `credit_control_area`
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
        """

        # Ensure the `data` tuple has exactly 7 elements before appending additional fields
        if len(data) != 54:
            st.error(f"Unexpected number of fields in data tuple. Expected 54, got {len(data)}.")
            return None

        # Add values for 'DISTR. CHANNEL' and 'form_number' to data tuple
        data_with_additional_fields = data + (
        distribution_channel, name_2, search_2_old_customer_code, street, street_4, street_5, language, fax, extension,
        gst_category, price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions,
        underdel_tolerance, indicator_customer_is_rebate_relevant, relevant_for_price_determination_id,
        acct_assmt_grp_cust, tax_category, tax_category_2, tax_category_3, tax_category_4, sales_person,
        sales_person_code, relationship_category, agent, broker_agent, forwarding_agent, form_number, request_number,
        current_date, credit_control_area)

        # Ensure the length of data_with_additional_fields is 11
        if len(data_with_additional_fields) != 86:
            st.error(
                f"Unexpected number of fields in data_with_additional_fields tuple. Expected 86, got {len(data_with_additional_fields)}.")
            return None

        cursor.execute(query, data_with_additional_fields)
        conn.commit()
        cursor.close()

        return form_number
    except mysql.connector.Error as err:
        st.error(f"Error inserting data into database: {err}")
        return None


# Set up the Streamlit app layout
st.set_page_config(layout="wide")

# Define columns for logo and title
logo_col, title_col = st.columns([1, 3])

# Display the logo and title
with logo_col:
    st.image('sangam logo.png', width=100)

with title_col:
    st.markdown("<h1 style='text-align: left;'>Please Fill The Below Details</h1>", unsafe_allow_html=True)

# Define columns for form fields
col1, col2, col3, col4 = st.columns(4)

# Set up form fields
fields = {
    'CUSTOMER ACCOUNT GROUP': 'customer_account_group',  # 1
    'COMPANY CODE': 'company_code',  # 2
    'SALES ORG.': 'sales_org',  # 3
    'DIVISION': 'division',  # 5
    'TITLES': 'titles',  # 6
    'NAME1': 'name_1',  # 7
    # 'NAME2': 'name_2',  # 8
    'SEARCH 1': 'search_1',  # 9
    # 'SEARCH 2 (OLD CUSTOMER CODE)': 'search_2_old_customer_code',  # 10
    'STREET 3': 'street_3',  # 11
    'STREET / HOUSE NUMBER': 'street_house_number',  # 12
    'STREET 2': 'street_2',  # 13
    # 'STREET': 'street',  # 14
    # 'STREET4': 'street_4',  # 15
    # 'STREET5': 'street_5',  # 16
    'DISTRICT': 'district',  # 17
    'DIFFERENT CITY': 'different_city',  # 18
    'PIN CODE': 'pin_code',  # 19
    'CITY': 'city',  # 20
    'COUNTRY': 'country',  # 21
    'REGION': 'region',  # 22
    'TELPHONE NUMBER 1': 'telephone_number_1',  # 24
    'MOBILE NUMBER 1': 'mobile_number_1',  # 25
    'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': 'contact_person_1_comments_of_mobile_number',  # 26
    # 'FAX': 'fax',  # 27
    # 'EXTENSION': 'extension',  # 28
    'EMAIL 1': 'email_1',  # 29
    'DEPARTMENT 1 (NOTES OF E-MAIL)': 'department_1_notes_of_email',  # 30
    'MOBILE PHONE-2': 'mobile_phone_2',  # 31
    'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': 'contact_person_2_comments_of_mobile_number',  # 32
    'EMAIL 2': 'email_2',  # 33
    'DEPARTMENT 2 (NOTES OF E-MAIL)': 'department_2_notes_of_email',  # 34
    'MOBILE PHONE-3': 'mobile_phone_3',  # 35
    'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': 'contact_person_3_comments_of_mobile_number',  # 36
    'EMAIL 3': 'email_3',  # 37
    'DEPARTMENT 3 (NOTES OF E-MAIL)': 'department_3_notes_of_email',  # 38
    'LEGAL FORM': 'legal_form',  # 39
    'BP TYPE': 'bp_type',  # 40
    'PAN CARD': 'pan_card',  # 41
    'GSTIN NO': 'gstin_no',  # 43
    'ANNUAL SALES': 'annual_sales',  # 44
    'CURRENCY': 'currency',  # 45
    'SALES YEAR': 'sales_year',  # 46
    'SALES DISTRICT': 'sales_district',  # 47
    'SALES OFFICE': 'sales_office',  # 48
    'SALES GROUP': 'sales_group',  # 49
    'CURRENCY2': 'currency_2',  # 50
    'DELIVERING PLANT': 'delivering_plant',  # 54
    # 'UNDERDEL. TOLERANCE': 'underdel_tolerance',  # 56
    'OVERDELIV. TOLERANCE': 'overdeliv_tolerance',  # 57
    'INCOTERMS': 'incoterms',  # 60
    'INCOTERMS LOCATION': 'incoterms_location',  # 61
    'PAYMENT TERMS': 'payment_terms',  # 62
    # 'CREDIT CONTROL AREA': 'credit_control_area',  # 63
    # 'AGENT': 'agent',  # 69
    'AGENT-CODE': 'agent_code',  # 70
    # 'BROKER AGENT': 'broker_agent',  # 71
    'BROKER AGENT-CODE': 'broker_agent_code',  # 72
    # 'FORWARDING AGENT': 'forwarding_agent',  # 73
    'FORWARDING AGENT-CODE': 'forwarding_agent_code',  # 74
    # 'SALES PERSON': 'sales_person',  # 75
    # 'SALES PERSON-CODE': 'sales_person_code',  # 76
    'RECON ACCOUNT': 'recon_account',  # 77
    'SORT KEY': 'sort_key',  # 78
    'PLANNING GROUP': 'planning_group',  # 79
    'PAYMENT TERMS2': 'payment_terms_2',  # 80
    'PAYMENT METHODS': 'payment_methods',  # 81
    'DUNNING PROCEDURE': 'dunning_procedure'  # 82
    # 'RELATIONSHIP CATEGORY': 'relationship_category'# 83
}
dropdown_options = {
    'COMPANY CODE': ['', '1000 - Sangam India Limited', '3000 - Sangam Ventures Limited'],
    'SALES ORG.': ['', '1100 - Spinnig Sales Org', '1200 - Denim Sales Org', '1300 - Weaving Sales Org',
                   '1400 - Processing Sales Org', '1500 - Seamless G Sales Org', '1600 - SIL Seamless',
                   '3500 - SVL Seamless'],
    'DIVISION': ['', '00 - Common Division', '01 - Asset', '02 - Scrap', '03 - Waste', '04 - Store Sales',
                 '05 - Synthetic Yarn', '06 - Cotton Yarn', '07 - Texturized Yarn', '08 - Knitted Fabrics',
                 '09 - Power/Fuel', '10 - Steam', '11 - Fabric (Claim)', '12 - Denim-Fabric', '13 - SurplusYarn',
                 '14 - Process Job', '15 - Garments', '16 - Grey Fabric', '17 - Sangam Suiting', '18 - Anupam Brand',
                 '19 - Export Brand', '20 - Institutional', '21 - Job Weaving', '22 - Fiber', '23 - Seamless Garments',
                 '24 - Dyed Yarn', '25 - Sangam Shirting', '26 - Sizing Job'],
    'LEGAL FORM': ['', '01 - Proprietorship', '02 - Partnership Firm', '03 - Pvt. Ltd.', '04 - Limited', '05 - LLP',
                   '06 - INDIVIDUAL', '07 - Other'],
    'BP TYPE': ['', '0001 - MANUFACTURER', '0002 - TRADER', '0003 - SUPPLIER', '0004 - SERVICE PROVIDER',
                '0005 - LEASING BUSINESS', '0006 - WAREHOUSE', '0007 - SEZ', '0008 - RETAILER',
                '0009 - ULTIMATE CONSUMER', '0010 - PARTNER TYPE 0001', '0011 - PARTNER TYPE 0002', '0011 - EMPLOYEE',
                '0013 - BROKER', '0014 - MANAGER', '0015 - SALES REPRESENTATIVE', '0016 - SALES AGENT',
                '0017 - STAKEHOLDER'],
    'SALES OFFICE': ['', '0001 - Sales Office South', '1100 - City Office Bhilwara', '1110 - BSL GROUP',
                     '1120 - Others (R, G, SK, Oth)', '1130 - MUMBAI', '1140 - Ludhiana & Amritsar', '1150 - Export',
                     '1160 - Group_Inter division', '1170 - Ahmedabad', '1180 - Delhi', '1200 - Denim plant',
                     '1300 - Atun sales office', '1400 - Processing Sales off'],
    'SALES GROUP': ['', '001 - Sales Group 001', 'C01 - Central I', 'C02 - Central II', 'C03 - Corporate',
                    'D01 - Delhi/Noida/Gurgaon', 'D02 - Mumbai / Ulhasnagar', 'D03 - Kolkata', 'D04 - Ahmedabad',
                    'D05 - Brand Sale', 'D06 - Bangalore / Bellary', 'D07 - Ludhiana', 'D08 - Others', 'E01 - East',
                    'MSG - Miscellaneous sales', 'N01 - North I', 'N02 - North II', 'S01 - South I', 'S02 - South II',
                    'W01 - West', 'Y01 - City Office Sales G1', 'Y02 - City Office Sales G2',
                    'Y03 - City Office Sales G3'],
    'CURRENCY': ['', 'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD', 'BDT',
                 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL', 'BSD', 'BTN', 'BWP', 'BYN', 'BZD', 'CAD', 'CDF',
                 'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF', 'DKK', 'DOP', 'DZD', 'EGP', 'ERN',
                 'ETB', 'EUR', 'FJD', 'FKP', 'FOK', 'GBP', 'GEL', 'GGP', 'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD',
                 'HKD', 'HNL', 'HRK', 'HTG', 'HUF', 'IDR', 'ILS', 'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD',
                 'JOD', 'JPY', 'KES', 'KGS', 'KHR', 'KID', 'KMF', 'KPW', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP',
                 'LKR', 'LRD', 'LSL', 'LYD', 'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR',
                 'MWK', 'MXN', 'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK',
                 'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR', 'SDG', 'SEK',
                 'SGD', 'SHP', 'SLL', 'SOS', 'SRD', 'SSP', 'STN', 'SYP', 'SZL', 'THB', 'TJS', 'TMT', 'TND', 'TOP',
                 'TRY', 'TTD', 'TVD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD', 'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST',
                 'XAF', 'XCD', 'XDR', 'XOF', 'XPF', 'YER', 'ZAR', 'ZMW', 'ZWL'],
    'CURRENCY2': ['', 'None', 'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD', 'BDT',
                  'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL', 'BSD', 'BTN', 'BWP', 'BYN', 'BZD', 'CAD', 'CDF',
                  'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF', 'DKK', 'DOP', 'DZD', 'EGP', 'ERN',
                  'ETB', 'EUR', 'FJD', 'FKP', 'FOK', 'GBP', 'GEL', 'GGP', 'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD',
                  'HKD', 'HNL', 'HRK', 'HTG', 'HUF', 'IDR', 'ILS', 'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD',
                  'JOD', 'JPY', 'KES', 'KGS', 'KHR', 'KID', 'KMF', 'KPW', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP',
                  'LKR', 'LRD', 'LSL', 'LYD', 'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR',
                  'MWK', 'MXN', 'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK',
                  'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR', 'SDG', 'SEK',
                  'SGD', 'SHP', 'SLL', 'SOS', 'SRD', 'SSP', 'STN', 'SYP', 'SZL', 'THB', 'TJS', 'TMT', 'TND', 'TOP',
                  'TRY', 'TTD', 'TVD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD', 'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST',
                  'XAF', 'XCD', 'XDR', 'XOF', 'XPF', 'YER', 'ZAR', 'ZMW', 'ZWL'],
    'SALES YEAR': ['', '2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010',
                   '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022',
                   '2023', '2024'],
    'DELIVERING PLANT': ['', '1100 - Biliya', '1110 - Sareri', '1120 - Soniyana', '1200 - Denim',
                         '1300 - Weaving', '1400 - Process', '1500 - Seamless', '3500 - SVL'],
    'INCOTERMS': ['', 'CFR - Costs and freight', 'CIF - Costs, insurance & freight',
                  'CIP - Carriage and insurance paid to', 'CPT - Carriage paid to', 'DAF - Delivered at frontier',
                  'DDP - Delivered Duty Paid', 'DDU - Delivered Duty Unpaid', 'DEQ - Delivered ex quay (duty paid)',
                  'DES - Delivered ex ship', 'EXW - Ex Works', 'FAS - Free Alongside Ship', 'FCA - Free Carrier',
                  'FH - Free house', 'FOB - Free on board', 'FOR - FOR MILL', 'UN - Not Free'],
    'INCOTERMS LOCATION': ['', 'Other', 'Costs and freight', 'Costs, insurance & freight',
                           'Carriage and insurance paid to', 'Carriage paid to', 'Delivered at frontier',
                           'Delivered Duty Paid', 'Delivered Duty Unpaid', 'Delivered ex quay (duty paid)',
                           'Delivered ex ship', 'Ex Works', 'Free Alongside Ship', 'Free Carrier', 'Free house',
                           'Free on board', 'FOR MILL', 'Not Free'],
    'PAYMENT TERMS': ['', '0001 - Pay immediately w/o deduction', '0002 - 14 days 2%, 30 net',
                      '0003 - 14 days 3%, 20/2%, 30 net', '0004 - as of end of month',
                      '0005 - from the 10th of subs. month', '0006 - End of month 4%, Mid-month 2%',
                      '0007 - 15th/31st subs. month 2%, ...', '0008 - 14 days 2%, 30/1,5%, 45 net',
                      '0009 - Payable in 3 installments', 'A001 - 100% Advance', 'A101 - Against PDC',
                      'A102 - Part Advance Part PDC', 'A103 - 100% Through Bank', 'A104 - Against PDC 15 Days',
                      'B030 - L/C At 30 Days From B/L Date', 'B060 - L/C At 60 Days From B/L Date',
                      'B090 - L/C At 90 Days From B/L Date', 'B120 - L/C At 120 Days From B/L Date',
                      'B180 - L/C At 180 Days From B/L Date', 'B360 - L/C At 360 Days Fr B/L Dt (EU)',
                      'C001 - Cash Against Delivery', 'C002 - Advance 2% 7 Days 1%',
                      'C003 - Within 7 days 5 % cash discount', 'C003 - 7 Days 7%, 15 Days 5%, 30 Days 3%',
                      'C004 - Within 30 days 1 % cash discount', 'C005 - 3 Days From Delivery with 1% C',
                      'C006 - 3 Days From Delivery with 1% Cash Discount',
                      'C007 - 7 Days From Delivery with 2% Cash Discount',
                      'C008 - 7 Days From Delivery with 2% Cash Discount',
                      'C009 - Same Day From Delivery with 3% Cash Discount',
                      'C010 - 2% CD Payment within 6 Days From Date of Invoice',
                      'C011 - CD 0.50 Per KG Payment within 3 Day from Receipts',
                      'C012 - CD 1.00 Per KG Payment within 3 Day from Receipts',
                      'C013 - CD 1.00 Per KG On Next Day Payment', 'C014 - CD 0.50% On Next Day Payment',
                      'C015 - 1 days from delivery', 'D000 - Against Delivery', 'D001 - 2 Days From Delivery',
                      'D002 - 3 Days From Delivery', 'D003 - 4 Days From Delivery', 'D004 - 5 Days From Delivery',
                      'D005 - 6 Days From Delivery', 'D006 - 7 Days From Delivery', 'D007 - 8 days from delivery',
                      'D008 - 9 days from delivery', 'D009 - 10 Days From Delivery', 'D010 - 11 Days From Delivery',
                      'D011 - 12 Days From Delivery', 'D012 - 13 days from delivery', 'D013 - 14 days from delivery',
                      'D014 - 15 Days From Delivery', 'D015 - 16 days from delivery', 'D016 - 17 days from delivery',
                      'D017 - 18 days from delivery', 'D018 - 19 Days From Delivery', 'D019 - 20 days from delivery',
                      'D020 - 21 Days From Delivery', 'D021 - 22 days from delivery', 'D022 - 23 days from delivery',
                      'D023 - 24 days from delivery', 'D024 - 25 Days From Delivery', 'D025 - 26 days from delivery',
                      'D026 - 27 days from delivery', 'D027 - 28 days from delivery', 'D028 - 29 days from delivery',
                      'D029 - 30 Days From Delivery', 'D030 - 31 days from delivery', 'D031 - 32 days from delivery',
                      'D032 - 33 days from delivery', 'D033 - AGAINST LR COPY PAYMENT',
                      'Z036 - 25% ADV, REM. AFTER 3 DAYS FROM', 'Z037 - 100% ADVANCE, 1% CD',
                      'Z038 - Payment Within 5 Days, 0.75% C', 'Z039 - Rs 6.00 PER KG CD ON 100% ADV.',
                      'Z040 - Rs 2.00 PER KG CD, PAYMENT WITH', 'Z042 - Payment after 365 days',
                      'Z044 - 1% C.D. On Next Day Payment', 'Z046 - 0.5% C.D., Payment in 2 days fr',
                      'Z047 - 0.5% C.D., Payment in 2 days fr', 'Z049 - 0.5% C.D. On 6th Day Payment',
                      'Z050 - Rs 0.50 PER KG CD, PAYMENT 2nd', 'Z051 - CD Rs.1/- per kg. on 100% Adva',
                      'Z052 - Rs 1.25 PER KG QD, PAYMENT 2nd', 'Z053 - 2% C.D., Payment Within 10 Days',
                      'Z054 - 50 % with in 03 month, 30% six', 'Z055 - CD 1.50%, Payment within 6 Day',
                      'Z056 - 20% Advance, Rest by D/P', 'Z057 - 20% Advance, 80% 30 Days After',
                      'Z058 - 1% C.D. , Payment in 5 Days Fr', 'Z059 - QD Rs.1.85/Kg, Payment 2 Days',
                      'Z060 - QD Rs.1.60/Kg, Payment 2 Days', 'Z062 - 40% Adv, 40% After 1 Month fm Com',
                      'Z063 - 25% Adv, 50% Agst Installation,', 'Z064 - CD@2% against 15 days payment',
                      'Z068 - 50% Advance, Balance after 30', 'Z069 - 80% against PI & balance after',
                      'Z070 - 30% advance, 70% within 15 day', 'Z071 - Within 35 days date of receipt of',
                      'Z072 - 70% Agst. Proforma invoice 30% af', 'Z073 - AS MENTIONED IN BELOW REMARKS',
                      'Z074 - 50% advance & balance after si', 'Z075 - QD Rs.1.50/Kg, Payment 2 Days',
                      'Z076 - 1.50% Cash Discount, 100% Adva', 'Z078 - 1.50% Cash Discount, 100% Advance Payment',
                      'Z079 - 100% ADVANCE BEFORE DISPATCH', 'Z080 - 100% CASH AGAINST DOCUMENTS', 'Z081 - 100% TT',
                      'Z082 - 100% TT THRU UCO BANK', 'Z083 - 5000 ADVANCE & BALANCE CAD',
                      'Z084 - 5000 ADVANCE & BALANCE TT', 'Z085 - 10000 ADVANCE & BALANCE CAD',
                      'Z086 - 10000 ADVANCE & BALANCE TT', 'Z087 - 20,000 USD ADVANCE AND BAL CAD',
                      'Z088 - 20,000 USD ADVANCE AND BAL TT', 'Z089 - 15% ADVANCE PAYMENT + BALANCE CAD',
                      'Z090 - 10% ADVANCE & BALANCE 90% CAD', 'Z091 - 10% ADVANCE & BALANCE 90% TT',
                      'Z092 - 20% ADVANCE & BALANCE 80% CAD', 'Z093 - 20% ADVANCE & BALANCE 80% TT',
                      'Z094 - 25% ADVANCE & BALANCE 75% CAD', 'Z095 - 25% ADVANCE & BALANCE 75% TT',
                      'Z096 - 25% ADVANCE AND BALANCE 75% CAD', 'Z097 - 30% ADVANCE & BALANCE 70% TT',
                      'Z098 - 30% ADVANCE AND BALANCE 70% CAD', 'Z099 - LC AT SIGHT',
                      'Z100 - LC AT 30 DAYS FROM BL DATE', 'Z101 - LC AT 45 DAYS FROM BL DATE',
                      'Z102 - LC AT 60 DAYS FROM BL DATE', 'Z103 - LC AT 90 DAYS FROM BL/ LR DATE',
                      'Z104 - LC AT 120 DAYS FROM BL/ LR DATE', 'Z105 - LC AT 150 DAYS FROM BL DATE',
                      'Z106 - LC AT 170 DAYS FROM BL DATE', 'Z107 - DA 120 DAYS FORM BL DATE',
                      'Z108 - 1% Cash Discount 7 days From date of receipt', 'Z109 - In 7 Days from invoice date',
                      'Z110 - LC AT 40 DAYS FROM BL DATE', 'Z111 - 60 Days Bill to Bill Payment',
                      'Z112 - within 15 days Due net', 'Z113 - Within 45 days date of receipt of goods at plant',
                      'Z114 - Within 50 days date of receipt of goods at plant',
                      'Z115 - Within 55 days date of receipt of goods at plant', 'Z116 - within 30 days Due net',
                      'Z117 - Within 5 days date of receipt of goods at plant', 'Z118 - CD 4/- Per Kg 100% Advance Pay',
                      'Z119 - DOCUMENT AGAINST PAYMENT AT SIGHT',
                      'Z120 - 30%Adv & bal.70% after inspection before dispatch',
                      'Z121 - Ship.30%Adv. balance after 45 days of GRN'],
    'SORT KEY': ['', '001 - Allocation number', '002 - Posting date', '003 - Doc.no., fiscal year',
                 '004 - Document date', '005 - Branch account', '006 - Loc.currency amount',
                 '007 - Doc.currency amount', '008 - Bill/exch.due date', '009 - Cost center',
                 '010 - External doc.number', '011 - Purchase order no.', '012 - Plant number', '013 - Vendor number',
                 '014 - Purchase order', '015 - Personnel number', '016 - Settlement period',
                 '017 - Settl.per., pers.no.', '018 - Asset number', '019 - Segment text', '020 - One-time name / city',
                 '021 - One-time city / name', '022 - Document header text', '023 - CPU date',
                 '024 - Pmnt per.bslne date', '025 - Value date', '026 - Asset number', '027 - Pstng month, vendor',
                 '028 - Customer number', '029 - Pstng yr,month,curr.', '030 - Cost center', '031 - Month, cost center',
                 '032 - Contract number', '033 - Order', '034 - Currency key', '035 - Project number',
                 '036 - Fiscal year, month', '037 - Test0', '038 - Test1', '039 - Test5', '040 - Cash discnt clearing',
                 '041 - Test'],
    'PLANNING GROUP': ['', 'A1 - Domestic payments (A/P)', 'A2 - Foreign payments (A/P)',
                       'A3 - Vendor-affiliated companies', 'A4 - Major vendors', 'A5 - Personnel costs', 'A6 - Tax',
                       'E1 - Customer receipts (A/R)', 'E2 - Domestic customers', 'E3 - Foreign customers',
                       'E4 - Customer-affiliated companies', 'E5 - High risk customer', 'E6 - Major customers',
                       'E7 - Rent received', 'E8 - Loan redemption (A/R)'],
    'PAYMENT TERMS2': ['', '0001 - Pay immediately w/o deduction', '0002 - 14 days 2%, 30 net',
                       '0003 - 14 days 3%, 20/2%, 30 net', '0004 - as of end of month',
                       '0005 - from the 10th of subs. month', '0006 - End of month 4%, Mid-month 2%',
                       '0007 - 15th/31st subs. month 2%, ...', '0008 - 14 days 2%, 30/1,5%, 45 net',
                       '0009 - Payable in 3 installments', 'A001 - 100% Advance', 'A101 - Against PDC',
                       'A102 - Part Advance Part PDC', 'A103 - 100% Through Bank', 'A104 - Against PDC 15 Days',
                       'B030 - L/C At 30 Days From B/L Date', 'B060 - L/C At 60 Days From B/L Date',
                       'B090 - L/C At 90 Days From B/L Date', 'B120 - L/C At 120 Days From B/L Date',
                       'B180 - L/C At 180 Days From B/L Date', 'B360 - L/C At 360 Days Fr B/L Dt (EU)',
                       'C001 - Cash Against Delivery', 'C002 - Advance 2% 7 Days 1%',
                       'C003 - Within 7 days 5 % cash discount', 'C003 - 7 Days 7%, 15 Days 5%, 30 Days 3%',
                       'C004 - Within 30 days 1 % cash discount', 'C005 - 3 Days From Delivery with 1% C',
                       'C006 - 3 Days From Delivery with 1% Cash Discount',
                       'C007 - 7 Days From Delivery with 2% Cash Discount',
                       'C008 - 7 Days From Delivery with 2% Cash Discount',
                       'C009 - Same Day From Delivery with 3% Cash Discount',
                       'C010 - 2% CD Payment within 6 Days From Date of Invoice',
                       'C011 - CD 0.50 Per KG Payment within 3 Day from Receipts',
                       'C012 - CD 1.00 Per KG Payment within 3 Day from Receipts',
                       'C013 - CD 1.00 Per KG On Next Day Payment', 'C014 - CD 0.50% On Next Day Payment',
                       'C015 - 1 days from delivery', 'D000 - Against Delivery', 'D001 - 2 Days From Delivery',
                       'D002 - 3 Days From Delivery', 'D003 - 4 Days From Delivery', 'D004 - 5 Days From Delivery',
                       'D005 - 6 Days From Delivery', 'D006 - 7 Days From Delivery', 'D007 - 8 days from delivery',
                       'D008 - 9 days from delivery', 'D009 - 10 Days From Delivery', 'D010 - 11 Days From Delivery',
                       'D011 - 12 Days From Delivery', 'D012 - 13 days from delivery', 'D013 - 14 days from delivery',
                       'D014 - 15 Days From Delivery', 'D015 - 16 days from delivery', 'D016 - 17 days from delivery',
                       'D017 - 18 days from delivery', 'D018 - 19 Days From Delivery', 'D019 - 20 days from delivery',
                       'D020 - 21 Days From Delivery', 'D021 - 22 days from delivery', 'D022 - 23 days from delivery',
                       'D023 - 24 days from delivery', 'D024 - 25 Days From Delivery', 'D025 - 26 days from delivery',
                       'D026 - 27 days from delivery', 'D027 - 28 days from delivery', 'D028 - 29 days from delivery',
                       'D029 - 30 Days From Delivery', 'D030 - 31 days from delivery', 'D031 - 32 days from delivery',
                       'D032 - 33 days from delivery', 'D033 - AGAINST LR COPY PAYMENT',
                       'Z036 - 25% ADV, REM. AFTER 3 DAYS FROM', 'Z037 - 100% ADVANCE, 1% CD',
                       'Z038 - Payment Within 5 Days, 0.75% C', 'Z039 - Rs 6.00 PER KG CD ON 100% ADV.',
                       'Z040 - Rs 2.00 PER KG CD, PAYMENT WITH', 'Z042 - Payment after 365 days',
                       'Z044 - 1% C.D. On Next Day Payment', 'Z046 - 0.5% C.D., Payment in 2 days fr',
                       'Z047 - 0.5% C.D., Payment in 2 days fr', 'Z049 - 0.5% C.D. On 6th Day Payment',
                       'Z050 - Rs 0.50 PER KG CD, PAYMENT 2nd', 'Z051 - CD Rs.1/- per kg. on 100% Adva',
                       'Z052 - Rs 1.25 PER KG QD, PAYMENT 2nd', 'Z053 - 2% C.D., Payment Within 10 Days',
                       'Z054 - 50 % with in 03 month, 30% six', 'Z055 - CD 1.50%, Payment within 6 Day',
                       'Z056 - 20% Advance, Rest by D/P', 'Z057 - 20% Advance, 80% 30 Days After',
                       'Z058 - 1% C.D. , Payment in 5 Days Fr', 'Z059 - QD Rs.1.85/Kg, Payment 2 Days',
                       'Z060 - QD Rs.1.60/Kg, Payment 2 Days', 'Z062 - 40% Adv, 40% After 1 Month fm Com',
                       'Z063 - 25% Adv, 50% Agst Installation,', 'Z064 - CD@2% against 15 days payment',
                       'Z068 - 50% Advance, Balance after 30', 'Z069 - 80% against PI & balance after',
                       'Z070 - 30% advance, 70% within 15 day', 'Z071 - Within 35 days date of receipt of',
                       'Z072 - 70% Agst. Proforma invoice 30% af', 'Z073 - AS MENTIONED IN BELOW REMARKS',
                       'Z074 - 50% advance & balance after si', 'Z075 - QD Rs.1.50/Kg, Payment 2 Days',
                       'Z076 - 1.50% Cash Discount, 100% Adva', 'Z078 - 1.50% Cash Discount, 100% Advance Payment',
                       'Z079 - 100% ADVANCE BEFORE DISPATCH', 'Z080 - 100% CASH AGAINST DOCUMENTS', 'Z081 - 100% TT',
                       'Z082 - 100% TT THRU UCO BANK', 'Z083 - 5000 ADVANCE & BALANCE CAD',
                       'Z084 - 5000 ADVANCE & BALANCE TT', 'Z085 - 10000 ADVANCE & BALANCE CAD',
                       'Z086 - 10000 ADVANCE & BALANCE TT', 'Z087 - 20,000 USD ADVANCE AND BAL CAD',
                       'Z088 - 20,000 USD ADVANCE AND BAL TT', 'Z089 - 15% ADVANCE PAYMENT + BALANCE CAD',
                       'Z090 - 10% ADVANCE & BALANCE 90% CAD', 'Z091 - 10% ADVANCE & BALANCE 90% TT',
                       'Z092 - 20% ADVANCE & BALANCE 80% CAD', 'Z093 - 20% ADVANCE & BALANCE 80% TT',
                       'Z094 - 25% ADVANCE & BALANCE 75% CAD', 'Z095 - 25% ADVANCE & BALANCE 75% TT',
                       'Z096 - 25% ADVANCE AND BALANCE 75% CAD', 'Z097 - 30% ADVANCE & BALANCE 70% TT',
                       'Z098 - 30% ADVANCE AND BALANCE 70% CAD', 'Z099 - LC AT SIGHT',
                       'Z100 - LC AT 30 DAYS FROM BL DATE', 'Z101 - LC AT 45 DAYS FROM BL DATE',
                       'Z102 - LC AT 60 DAYS FROM BL DATE', 'Z103 - LC AT 90 DAYS FROM BL/ LR DATE',
                       'Z104 - LC AT 120 DAYS FROM BL/ LR DATE', 'Z105 - LC AT 150 DAYS FROM BL DATE',
                       'Z106 - LC AT 170 DAYS FROM BL DATE', 'Z107 - DA 120 DAYS FORM BL DATE',
                       'Z108 - 1% Cash Discount 7 days From date of receipt', 'Z109 - In 7 Days from invoice date',
                       'Z110 - LC AT 40 DAYS FROM BL DATE', 'Z111 - 60 Days Bill to Bill Payment',
                       'Z112 - within 15 days Due net', 'Z113 - Within 45 days date of receipt of goods at plant',
                       'Z114 - Within 50 days date of receipt of goods at plant',
                       'Z115 - Within 55 days date of receipt of goods at plant', 'Z116 - within 30 days Due net',
                       'Z117 - Within 5 days date of receipt of goods at plant',
                       'Z118 - CD 4/- Per Kg 100% Advance Pay', 'Z119 - DOCUMENT AGAINST PAYMENT AT SIGHT',
                       'Z120 - 30%Adv & bal.70% after inspection before dispatch',
                       'Z121 - Ship.30%Adv. balance after 45 days of GRN'],
    'PAYMENT METHODS': ['', 'C - Cheque', 'E - Cash Payment', 'T - Bank Transfer'],
    'RECON ACCOUNT': ['', '1180170 - ADVANCE INTEREST CUSTOMER', '1200205 - SECURITY DEPOSIT FROM CUSTOMER',
                      '2160010 - Sundry Debt.-Domestic', '2160020 - Sundry Debt.-Export',
                      '2160030 - Sundry Debt.-Others', '2160040 - Intercompany-Debtors', '2160200 - CUSTO EXCH. FLUC',
                      '2180523 - TDS Certificate Receivable'],
}

fixed_values = {
    'DISTR. CHANNEL': '00',
    'LANGUANGE': 'EN',
    'FAX': 'None',
    'EXTENSION': 'None',
    'NAME2': 'None',  # 8
    'SEARCH 2 (OLD CUSTOMER CODE)': 'NEW CODE',
    'STREET': 'None',
    'STREET4': 'None',
    'STREET5': 'None',
    'GST CATEGORY': 'IN3',
    'PRICE GROUP': '01',
    'CUST.PRIC.PROCEDURE': '1',
    'ORDER COMBINATION INDICATOR': 'X',
    'SHIPPING CONDITIONS': '01',
    'UNDERDEL. TOLERANCE': 'None',
    'INDICATOR: CUSTOMER IS REBATE-RELEVANT': 'X',
    'RELEVANT FOR PRICE DETERMINATION ID': 'X',
    'ACCT ASSMT GRP CUST.': '01',
    'TAX CATEGORY': '0',
    'TAX CATEGORY2': '0',
    'TAX CATEGORY3': '0',
    'TAX CATEGORY4': '0',
    'SALES PERSON': 'None',
    'SALES PERSON-CODE': 'None',
    'RELATIONSHIP CATEGORY': 'None',
    # Add more fields and their fixed values here
}

editable_fixed_values = {
    'OVERDELIV. TOLERANCE': '5',
}
# Set up form data with retrieved values
form_data = {}

# Extract form_number from URL
params = st.query_params
form_number = params.get('form_number', '')

# Connect to MySQL database for fetching data
conn_fetch = connect_to_fetch_database()

# Construct SQL query to fetch company_name and email for the given request_number
query = (
    f"SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, "
    f"phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, "
    f"category, request_number FROM form_details WHERE form_number = '{form_number}'")

# Execute the query
cur = conn_fetch.cursor()
cur.execute(query)

# Fetch the results
result = cur.fetchone()

# If result is not None, extract company_name and email
if result:
    titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, category, request_number = result

    # Set fetched values in the form fields
    form_data = {
        'titles': titles,
        'contact_person_1_comments_of_mobile_number': name,
        'email_1': email,
        'name_1': company_name,
        'country': country,
        'state': state,
        'city': city,
        'street_3': street_address,
        'street_2': street_address_2,
        'street_house_number': street_address_3,
        'pin_code': postal_code,
        'telephone_number_1': phone_number,
        'mobile_number_1': mobile_number,
        'gstin_no': gst_number,
        'pan_card': pan_number,
        'region': region,
        'customer_account_group': category,
        'request_number': request_number,
    }

    # col1
    with col1:
        for label, field_name in list(fields.items())[:14]:
            if label in dropdown_options:
                form_data[field_name] = st.selectbox(label, dropdown_options[label], key=f"col1_{field_name}_select")
            elif label not in fixed_values:  # Exclude fields from fixed_values
                if label in ['CUSTOMER ACCOUNT GROUP', 'NAME1', 'STREET 3', 'STREET 2', 'STREET / HOUSE NUMBER', 'CITY', 'PIN CODE', 'TITLES']:  # Check if the field is 'company_name' or 'email'
                    st.text_input(label, key=f"col1_{field_name}_input", value=form_data.get(field_name, ''),
                                  disabled=True)
                else:
                    form_data[field_name] = st.text_input(label, key=f"col1_{field_name}_input",
                                                          value=form_data.get(field_name, ''), max_chars=40)

    # col2
    with col2:
        for label, field_name in list(fields.items())[14:28]:
            if label in dropdown_options:
                form_data[field_name] = st.selectbox(label, dropdown_options[label], key=f"col2_{field_name}_select")
            elif label not in fixed_values:  # Exclude fields from fixed_values
                if label in ['COUNTRY', 'REGION', 'TELPHONE NUMBER 1',
                             'MOBILE NUMBER 1', 'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)',
                             'EMAIL 1']:  # Check if the field is 'company_name' or 'email'
                    st.text_input(label, key=f"col2_{field_name}_input", value=form_data.get(field_name, ''),
                                  disabled=True)
                else:
                    form_data[field_name] = st.text_input(label, key=f"col2_{field_name}_input",
                                                          value=form_data.get(field_name, ''), max_chars=40)

    # col3
    with col3:
        for label, field_name in list(fields.items())[28:42]:
            if label in dropdown_options:
                form_data[field_name] = st.selectbox(label, dropdown_options[label], key=f"col3_{field_name}_select")
            elif label not in fixed_values:  # Exclude fields from fixed_values
                if label in ['PAN CARD', 'GSTIN NO']:  # Check if the field is 'company_name' or 'email'
                    st.text_input(label, key=f"col3_{field_name}_input", value=form_data.get(field_name, ''),
                                  disabled=True)
                else:
                    form_data[field_name] = st.text_input(label, key=f"col3_{field_name}_input",
                                                          value=form_data.get(field_name, ''), max_chars=40)

    # col4
    with col4:
        for label, field_name in list(fields.items())[42:]:
            if label == 'INCOTERMS LOCATION':
                selected_option = st.selectbox(label, dropdown_options.get(label, []), key=f"{field_name}_select")
                if selected_option == 'Other':
                    form_data[field_name] = st.text_input("Other INCOTERMS LOCATION")
                else:
                    form_data[field_name] = selected_option
            elif label in dropdown_options:
                form_data[field_name] = st.selectbox(label, dropdown_options[label], key=f"{field_name}_select")
            elif label not in fixed_values:  # Exclude fields from fixed_values
                if label in ['INCOTERMS']:  # Check if the field is 'company_name' or 'email'
                    st.text_input(label, key=f"{field_name}_input", value=form_data.get(field_name, ''), disabled=True)
                else:
                    form_data[field_name] = st.text_input(label, key=f"{field_name}_input",
                                                          value=form_data.get(field_name, ''),
                                                          max_chars=40)
    # Display buttons to view documents
    if gst_document:
        if st.button('View GST Document'):
            st.session_state.viewed_gst = True
            st.header("GST Document")
            pdf_viewer(gst_document)
            pdf_download(gst_document, 'GST_Document.pdf')
    else:
        st.error("No GST document found.")

    if pan_document:
        if st.button('View PAN Document'):
            st.session_state.viewed_pan = True
            st.header("PAN Document")
            pdf_viewer(pan_document)
            pdf_download(pan_document, 'PAN_Document.pdf')
    else:
        st.error("No PAN document found.")

    if not st.session_state.viewed_gst or not st.session_state.viewed_pan:
        st.warning("Please view both GST and PAN documents before submitting.")
    else:
        if st.button('Submit'):
            valid_submission = True

            # Check for agent
            agent_code = form_data['agent_code'].strip()
            if agent_code and agent_code.lower() != 'none':
                agent = 'ZA'
            else:
                agent = 'None'

            # Check for broker agent
            broker_agent_code = form_data['broker_agent_code'].strip()
            if broker_agent_code and broker_agent_code.lower() != 'none':
                broker_agent = 'ZB'
            else:
                broker_agent = 'None'

            # Check for forwarding agent
            forwarding_agent_code = form_data['forwarding_agent_code'].strip()
            if forwarding_agent_code and forwarding_agent_code.lower() != 'none':
                forwarding_agent = 'CR'
            else:
                forwarding_agent = 'None'

            # Check and set default value for DUNNING PROCEDURE if it's empty
            if form_data['dunning_procedure'] == "":
                form_data['dunning_procedure'] = 'None'
            if form_data['street_house_number'] == "":
                form_data['street_house_number'] = 'None'
            if form_data['district'] == "":
                form_data['district'] = 'None'
            if form_data['different_city'] == "":
                form_data['different_city'] = 'None'
            if form_data['department_1_notes_of_email'] == "":
                form_data['department_1_notes_of_email'] = 'None'
            if form_data['mobile_phone_2'] == "":
                form_data['mobile_phone_2'] = 'None'
            if form_data['contact_person_2_comments_of_mobile_number'] == "":
                form_data['contact_person_2_comments_of_mobile_number'] = 'None'
            if form_data['email_2'] == "":
                form_data['email_2'] = 'None'
            if form_data['department_2_notes_of_email'] == "":
                form_data['department_2_notes_of_email'] = 'None'
            if form_data['mobile_phone_3'] == "":
                form_data['mobile_phone_3'] = 'None'
            if form_data['contact_person_3_comments_of_mobile_number'] == "":
                form_data['contact_person_3_comments_of_mobile_number'] = 'None'
            if form_data['email_3'] == "":
                form_data['email_3'] = 'None'
            if form_data['department_3_notes_of_email'] == "":
                form_data['department_3_notes_of_email'] = 'None'
            if form_data['sales_district'] == "":
                form_data['sales_district'] = 'None'
            if form_data['delivering_plant'] == "":
                form_data['delivering_plant'] = 'None'
            if form_data['agent_code'] == "":
                form_data['agent_code'] = 'None'
            if form_data['broker_agent_code'] == "":
                form_data['broker_agent_code'] = 'None'
            if form_data['forwarding_agent_code'] == "":
                form_data['forwarding_agent_code'] = 'None'

            # Validate annual sales, currency, and sales year
            annual_sales = form_data.get('annual_sales', '').strip()
            currency = form_data.get('currency', '').strip()
            sales_year = form_data.get('sales_year', '').strip()

            if (annual_sales and (not currency or not sales_year)) or (
                    currency and (not annual_sales or not sales_year)) or (
                    sales_year and (not annual_sales or not currency)):
                st.error('Please fill all fields: Annual Sales, Currency, and Sales Year, or leave them all empty.')
                valid_submission = False
            elif not annual_sales and not currency and not sales_year:
                form_data['annual_sales'] = 'None'
                form_data['currency'] = 'None'
                form_data['sales_year'] = 'None'

            for label, field_name in fields.items():
                # Check if the field is required and not empty
                if field_name not in dropdown_options and not form_data[field_name]:
                    st.error(f'Please enter a valid {label}.')
                    valid_submission = False
                    break
                # If the field is in dropdown_options, it's not empty
                elif field_name in dropdown_options:
                    if not validate_field(field_name, form_data[field_name]):
                        st.error(f'Please enter a valid {label}.')
                        valid_submission = False
                        break

            if valid_submission:
                st.success('Form submitted successfully!')
                insert_conn = connect_to_insert_database()
                if insert_conn:
                    # Construct data tuple including 'DISTR. CHANNEL'
                    data_tuple = tuple(form_data.get(field_name, '') for field_name in fields.values() if
                                       field_name not in fixed_values)
                    distribution_channel = fixed_values['DISTR. CHANNEL']
                    name_2 = fixed_values['NAME2']
                    search_2_old_customer_code = fixed_values['SEARCH 2 (OLD CUSTOMER CODE)']
                    street = fixed_values['STREET']
                    street_4 = fixed_values['STREET4']
                    street_5 = fixed_values['STREET5']
                    language = fixed_values['LANGUANGE']
                    fax = fixed_values['FAX']
                    extension = fixed_values['EXTENSION']
                    gst_category = fixed_values['GST CATEGORY']
                    price_group = fixed_values['PRICE GROUP']
                    cust_pric_procedure = fixed_values['CUST.PRIC.PROCEDURE']
                    order_combination_indicator = fixed_values['ORDER COMBINATION INDICATOR']
                    shipping_conditions = fixed_values['SHIPPING CONDITIONS']
                    underdel_tolerance = fixed_values['UNDERDEL. TOLERANCE']
                    indicator_customer_is_rebate_relevant = fixed_values['INDICATOR: CUSTOMER IS REBATE-RELEVANT']
                    relevant_for_price_determination_id = fixed_values['RELEVANT FOR PRICE DETERMINATION ID']
                    acct_assmt_grp_cust = fixed_values['ACCT ASSMT GRP CUST.']
                    tax_category = fixed_values['TAX CATEGORY']
                    tax_category_2 = fixed_values['TAX CATEGORY2']
                    tax_category_3 = fixed_values['TAX CATEGORY3']
                    tax_category_4 = fixed_values['TAX CATEGORY4']
                    sales_person = fixed_values['SALES PERSON']
                    sales_person_code = fixed_values['SALES PERSON-CODE']
                    relationship_category = fixed_values['RELATIONSHIP CATEGORY']
                    insert_into_database(insert_conn, data_tuple, distribution_channel, name_2,
                                         search_2_old_customer_code, street, street_4, street_5, language, fax,
                                         extension, gst_category, price_group, cust_pric_procedure,
                                         order_combination_indicator, shipping_conditions, underdel_tolerance,
                                         indicator_customer_is_rebate_relevant, relevant_for_price_determination_id,
                                         acct_assmt_grp_cust, tax_category, tax_category_2, tax_category_3,
                                         tax_category_4, sales_person, sales_person_code, relationship_category, agent,
                                         broker_agent, forwarding_agent, form_number)




# import streamlit as st
# import re
# import mysql.connector
# from streamlit_pdf_viewer import pdf_viewer
# import base64
# import datetime
#
# # Initialize session state variables
# if 'viewed_gst' not in st.session_state:
#     st.session_state.viewed_gst = False
#
# if 'viewed_pan' not in st.session_state:
#     st.session_state.viewed_pan = False
#
# # Function to validate field based on regular expression
# def validate_field(field_name, field_value):
#     validation_patterns = {
#         'CUSTOMER ACCOUNT GROUP': r'^[A-Z]+$',
#         'ANNUAL SALES': r'^[a-zA-Z0-9\s.,()-]+$',
#         'CURRENCY': r'^[a-zA-Z0-9\s.,()-]+$',
#         'SALES YEAR': r'^\d{4}$',
#         'INCOTERMS LOCATION': r'^[a-zA-Z0-9\s.,()-]+$',
#         'PAYMENT METHODS': r'^[a-zA-Z0-9\s.,()-]+$',
#         'DUNNING PROCEDURE': r'^[a-zA-Z0-9\s.,()-]+$',
#         'RELATIONSHIP CATEGORY': r'^[a-zA-Z0-9\s.,()-]+$',
#     }
#     pattern = validation_patterns.get(field_name)
#     if pattern:
#         return bool(re.match(pattern, field_value))
#     return False
#
# # Connect to MySQL database for inserting data
# def connect_to_insert_database():
#     try:
#         conn = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="",
#             database="formsubmitteddetails"
#         )
#         return conn
#     except mysql.connector.Error as err:
#         st.error(f"Error connecting to MySQL database: {err}")
#         return None
#
# # Connect to MySQL database for fetching data
# def connect_to_fetch_database():
#     try:
#         conn = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="",
#             database="formsubmitteddetails"
#         )
#         return conn
#     except mysql.connector.Error as err:
#         st.error(f"Error connecting to MySQL database: {err}")
#         return None
#
# # Function to fetch company name and email from the database
# def fetch_company_email(conn, form_number):
#     try:
#         cursor = conn.cursor()
#         cursor.execute(f"SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, category FROM form_details WHERE form_number = '{form_number}'")
#         result = cursor.fetchone()
#         cursor.close()
#         return result if result else None
#     except mysql.connector.Error as err:
#         st.error(f"Error fetching data from database: {err}")
#         return None
#
# def pdf_download(pdf_data, filename):
#     with open(filename, "wb") as f:
#         f.write(base64.b64decode(pdf_data))
#
#     st.markdown(f'<a href="data:application/pdf;base64,{base64.b64encode(pdf_data).decode()}" download="{filename}">Download PDF</a>', unsafe_allow_html=True)
#
# # Function to insert form data into the database
# def insert_into_database(conn, data, relationship_category, form_number):
#     try:
#         cursor = conn.cursor()
#
#         current_date = datetime.datetime.now().date()
#
#         cursor.execute("SELECT request_number FROM form_details WHERE form_number = %s", (form_number,))
#         result = cursor.fetchone()
#         if result:
#             request_number = result[0]
#         else:
#             st.error("Error fetching request number.")
#             return None
#
#         # Insert data into the database along with the form number
#         query = """
#             INSERT INTO marketing_submission (
#                 customer_account_group, annual_sales, currency, sales_year, incoterms_location, payment_methods, dunning_procedure,
#                 relationship_category, form_number, request_number, submission_date
#             ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
#         """
#
#         # Ensure the `data` tuple has exactly 7 elements before appending additional fields
#         if len(data) != 7:
#             st.error(f"Unexpected number of fields in data tuple. Expected 7, got {len(data)}.")
#             return None
#
#         # Append the additional fields to the data tuple
#         data_with_additional_fields = data + (relationship_category, form_number, request_number, current_date)
#
#         # Log the lengths for debugging
#         st.write(f"Length of data tuple: {len(data)}")
#         st.write(f"Length of data_with_additional_fields tuple: {len(data_with_additional_fields)}")
#
#         # Ensure the length of data_with_additional_fields is 11
#         if len(data_with_additional_fields) != 11:
#             st.error(f"Unexpected number of fields in data_with_additional_fields tuple. Expected 11, got {len(data_with_additional_fields)}.")
#             return None
#
#         cursor.execute(query, data_with_additional_fields)
#         conn.commit()
#         cursor.close()
#
#         return form_number
#     except mysql.connector.Error as err:
#         st.error(f"Error inserting data into database: {err}")
#         return None
#
# # Set up the Streamlit app layout
# st.set_page_config(layout="wide")
#
# # Define columns for logo and title
# logo_col, title_col = st.columns([1, 3])
#
# # Display the logo and title
# with logo_col:
#     st.image('sangam logo.png', width=100)
#
# with title_col:
#     st.markdown("<h1 style='text-align: left;'>Please Fill The Below Details</h1>", unsafe_allow_html=True)
#
# # Define columns for form fields
# col1, col2, col3, col4, col5 = st.columns(5)
#
# # Set up form fields
# fields = {
#     'CUSTOMER ACCOUNT GROUP': 'customer_account_group',  # 1
#     'ANNUAL SALES': 'annual_sales',  # 44
#     'CURRENCY': 'currency',  # 45
#     'SALES YEAR': 'sales_year',  # 46
#     'INCOTERMS LOCATION': 'incoterms_location',  # 61
#     'PAYMENT METHODS': 'payment_methods',  # 81
#     'DUNNING PROCEDURE': 'dunning_procedure' # 82
# }
# dropdown_options = {
#     'CURRENCY': ['', 'None', 'INR', 'AED', 'AFN', 'ALL', 'AMD'],
#     'SALES YEAR': ['', 'None', '2000', '2001', '2002', '2003'],
#     'INCOTERMS LOCATION': ['', 'Other', 'Costs and freight', 'Costs, insurance & freight', 'Carriage and insurance paid to',
#                            'Carriage paid to', 'Delivered at frontier', 'Delivered Duty Paid', 'Delivered Duty Unpaid',
#                            'Delivered ex quay (duty paid)', 'Delivered ex ship', 'Ex Works', 'Free Alongside Ship',
#                            'Free Carrier', 'Free house', 'Free on board', 'FOR MILL', 'Not Free'],
#     'PAYMENT METHODS': ['', 'C - Cheque', 'E - Cash Payment', 'T - Bank Transfer'],
# }
#
# fixed_values = {
#     'RELATIONSHIP CATEGORY': 'None',
#     # Add more fields and their fixed values here
# }
#
# # Set up form data with retrieved values
# form_data = {}
#
# # Extract form_number from URL
# params = st.query_params
# form_number = params.get('form_number', '')
#
# # Connect to MySQL database for fetching data
# conn_fetch = connect_to_fetch_database()
#
# # Construct SQL query to fetch company_name and email for the given request_number
# query = (f"SELECT titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, "
#          f"phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, "
#          f"category, request_number FROM form_details WHERE form_number = '{form_number}'")
#
# # Execute the query
# cur = conn_fetch.cursor()
# cur.execute(query)
#
# # Fetch the results
# result = cur.fetchone()
#
# # If result is not None, extract company_name and email
# if result:
#     titles, name, email, company_name, country, state, city, street_address, street_address_2, street_address_3, postal_code, phone_number, mobile_number, gst_number, pan_number, region, gst_document, pan_document, category, request_number = result
#
#     # Set fetched values in the form fields
#     form_data = {
#         'titles': titles,
#         'contact_person_1_comments_of_mobile_number': name,
#         'email_1': email,
#         'name_1': company_name,
#         'country': country,
#         'state': state,
#         'district': city,
#         'city': city,
#         'street_3': street_address,
#         'street_2': street_address_2,
#         'street_house_number': street_address_3,
#         'pin_code': postal_code,
#         'telephone_number_1': phone_number,
#         'mobile_number_1': mobile_number,
#         'gstin_no': gst_number,
#         'pan_card': pan_number,
#         'region': region,
#         'customer_account_group': category,
#         'request_number': request_number,
#     }
#
#     with col1:
#         for label, field_name in list(fields.items())[:11]:
#             if label == 'INCOTERMS LOCATION':
#                 selected_option = st.selectbox(label, dropdown_options.get(label, []))
#                 if selected_option == 'Other':
#                     form_data[field_name] = st.text_input("Other INCOTERMS LOCATION")
#                 else:
#                     form_data[field_name] = selected_option
#             elif label in dropdown_options:
#                 form_data[field_name] = st.selectbox(label, dropdown_options[label])
#             elif label not in fixed_values:  # Exclude fields from fixed_values
#                 if label in ['NAME1', 'STREET 3', 'STREET 2', 'STREET / HOUSE NUMBER',
#                              'TITLES']:  # Check if the field is 'company_name' or 'email'
#                     st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
#                 else:
#                     form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''),
#                                                           max_chars=40)
#
#     # Display buttons to view documents
#     if gst_document:
#         if st.button('View GST Document'):
#             st.session_state.viewed_gst = True
#             st.header("GST Document")
#             pdf_viewer(gst_document)
#             pdf_download(gst_document, 'GST_Document.pdf')
#     else:
#         st.error("No GST document found.")
#
#     if pan_document:
#         if st.button('View PAN Document'):
#             st.session_state.viewed_pan = True
#             st.header("PAN Document")
#             pdf_viewer(pan_document)
#             pdf_download(pan_document, 'PAN_Document.pdf')
#     else:
#         st.error("No PAN document found.")
#
#     if not st.session_state.viewed_gst or not st.session_state.viewed_pan:
#         st.warning("Please view both GST and PAN documents before submitting.")
#     else:
#         if st.button('Submit'):
#             valid_submission = True
#
#             # Check and set default value for DUNNING PROCEDURE if it's empty
#             if form_data['dunning_procedure'] == "":
#                 form_data['dunning_procedure'] = 'None'
#
#             # Validate annual sales, currency, and sales year
#             annual_sales = form_data.get('annual_sales', '').strip()
#             currency = form_data.get('currency', '').strip()
#             sales_year = form_data.get('sales_year', '').strip()
#
#             if (annual_sales and (not currency or not sales_year)) or (
#                     currency and (not annual_sales or not sales_year)) or (
#                     sales_year and (not annual_sales or not currency)):
#                 st.error('Please fill all fields: Annual Sales, Currency, and Sales Year, or leave them all empty.')
#                 valid_submission = False
#             elif not annual_sales and not currency and not sales_year:
#                 form_data['annual_sales'] = 'None'
#                 form_data['currency'] = 'None'
#                 form_data['sales_year'] = 'None'
#
#             for label, field_name in fields.items():
#                 # Check if the field is required and not empty
#                 if field_name not in dropdown_options and not form_data[field_name]:
#                     st.error(f'Please enter a valid {label}.')
#                     valid_submission = False
#                     break
#                 # If the field is in dropdown_options, it's not empty
#                 elif field_name in dropdown_options:
#                     if not validate_field(field_name, form_data[field_name]):
#                         st.error(f'Please enter a valid {label}.')
#                         valid_submission = False
#                         break
#
#             if valid_submission:
#                 st.success('Form submitted successfully!')
#                 insert_conn = connect_to_insert_database()
#                 if insert_conn:
#                     # Construct data tuple including 'DISTR. CHANNEL'
#                     data_tuple = tuple(form_data.get(field_name, '') for field_name in fields.values() if
#                                        field_name not in fixed_values)
#                     relationship_category = fixed_values['RELATIONSHIP CATEGORY']
#                     insert_into_database(insert_conn, data_tuple, relationship_category, form_number)
