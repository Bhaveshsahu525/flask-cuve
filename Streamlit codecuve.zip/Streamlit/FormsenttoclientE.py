import streamlit as st
import re
import mysql.connector
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import uuid
import ssl
import os
import datetime

# Function to validate field based on regular expression
def validate_field(field_name, field_value):
    validation_patterns = {
        'titles': r'^[a-zA-Z\s.,/()-]+$',
        'name': r'^[a-zA-Z\s.,()-]+$',
        'email': r'^[\w\.-]+@[\w\.-]+\.\w+$',
        'company_name': r'^[a-zA-Z0-9\s.,()-]+$',
        'country': r'^[a-zA-Z\s.,()-]+$',
        'state': r'^[a-zA-Z\s.,()-]+$',
        'city': r'^[a-zA-Z\s.,()-]+$',
        'street_address': r'^[a-zA-Z0-9\s.,/-]+$',
        'street_address_2': r'^[a-zA-Z0-9\s.,/-]+$',
        'street_address_3': r'^[a-zA-Z0-9\s.,/-]*$',  # Allow empty input
        'postal_code': r'^\d{6}$',
        'phone_number': r'^\d{10}$',
        'mobile_number': r'^\d{10}$',
    }
    pattern = validation_patterns.get(field_name)
    if pattern:
        return bool(re.match(pattern, field_value))
    return False

# Connect to MySQL database for inserting data
def connect_to_insert_database():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="formsubmitteddetails"
    )
    return conn

# Connect to MySQL database for fetching data
def connect_to_fetch_database():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="emailssenttocustomer"
    )
    return conn

# Connect to MySQL database for submitted forms
def connect_to_submitted_forms_database():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="formsubmitteddetails"  # Corrected database name
    )
    return conn

# Function to check if a request_number exists in submitted forms
def is_request_number_submitted(conn, request_number):
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM submitted_forms WHERE request_number = '{request_number}'")
    result = cursor.fetchone()
    cursor.close()
    return result[0] > 0 if result else False

# Function to insert request_number into submitted forms
def insert_into_submitted_forms(conn, request_number):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO submitted_forms (request_number) VALUES (%s)", (request_number,))
    conn.commit()
    cursor.close()

# Function to fetch company name and email from the database
def fetch_company_email(conn, request_number):
    cursor = conn.cursor()
    cursor.execute(f"SELECT company_name, email FROM customerrequested WHERE request_number = '{request_number}'")
    result = cursor.fetchone()
    cursor.close()
    return result if result else None

# Function to insert form data into the database
def insert_into_database(conn, data, request_number):
    cursor = conn.cursor()

    # Generate a unique form number
    form_number = generate_unique_form_number()

    # Get the current date
    current_date = datetime.datetime.now().date()

    # Modify the titles field if "Ms." is selected
    titles = data[0]
    if titles == "Ms.": titles = "0001"
    if titles == "Mr.": titles = "0002"
    if titles == "Company": titles = "3000"
    if titles == "Mr. and Mrs": titles = "4000"
    if titles == "M/S": titles = "5000"

    street_address3 = data[9] if data[9] else "None"

    # Insert data into the database along with the form number, request number, and current date
    query = """
        INSERT INTO form_details (
            titles, name, email, company_name, country, state, city, street_address,
            street_address_2, street_address_3, postal_code, phone_number, mobile_number, category, form_number, request_number, submission_date, region
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, '00'
        )
    """
    # Include the current date in the SQL query
    cursor.execute(query, (titles, *data[1:9], street_address3, *data[10:], "ZEXP", form_number, request_number, current_date))
    conn.commit()
    cursor.close()

    return form_number

# Function to generate a unique form number
def generate_unique_form_number():
    # Generate a unique UUID
    unique_id = uuid.uuid4().hex[:6].upper()

    # Concatenate with a prefix
    form_number = f'{unique_id}'

    return form_number

# Function to send email with the form number
def send_email(sender_email, sender_password, recipient_email, subject, body):
    # Set up the MIME
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = recipient_email
    message['Subject'] = subject

    # Add body to email
    message.attach(MIMEText(body, 'plain'))

    # Connect to the SMTP server securely using SSL/TLS
    smtp_server = 'mail.sangamgroup.com'  # Update SMTP server address
    port = 465  # Default port for SSL/TLS
    context = ssl.create_default_context()

    try:
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            # Login to the SMTP server using authentication
            server.login(sender_email, sender_password)

            # Send email
            server.sendmail(sender_email, recipient_email, message.as_string())
        return  True
    except Exception as e:
        print(f"Failed to send email: {e}")
        import traceback
        traceback.print_exc()  # Print full traceback
        return False

st.set_page_config(layout="wide")

# Define columns for logo and title
logo_col, title_col = st.columns([1, 3])

# Display the logo and title
with logo_col:
    st.image('sangam logo.png', width=100)

with title_col:
    st.markdown("<h1 style='text-align: left;'>Please Fill The Below Details</h1>", unsafe_allow_html=True)

# Extract request_number from URL
request_number = st.query_params.get('request_number', '')

# st.write(f"Request Number: {request_number}")  # Debug output to ensure request_number is obtained

# Connect to MySQL database for inserting data
conn_insert = connect_to_insert_database()

# Connect to MySQL database for submitted forms
conn_submitted_forms = connect_to_submitted_forms_database()

# is already submitted
request_number_submitted = is_request_number_submitted(conn_submitted_forms, request_number)

# If the request number is already submitted, don't display the form again
if request_number_submitted:
    st.write("This form has already been submitted.")
else:
    # Define columns for form fields
    col1, col2, col3 = st.columns(3)

    # Set up form fields
    fields = {
        'Title': 'titles',
        'Contact Person*': 'name',
        'Email ID': 'email',
        'Company Name': 'company_name',
        'Country': 'country',
        'State*': 'state',
        'City*': 'city',
        'Street Address*': 'street_address',
        'Street Address2*': 'street_address_2',
        'Street Address3': 'street_address_3',
        'Postal Code*': 'postal_code',
        'Phone Number*': 'phone_number',
        'Mobile Number*': 'mobile_number',
    }

    # Set up form data with retrieved values
    form_data = {}

    # Connect to MySQL database for fetching data
    conn_fetch = connect_to_fetch_database()

    try:
        # Fetch company name and email from the database
        company_email_data = fetch_company_email(conn_fetch, request_number)

        if company_email_data:
            company_name, email = company_email_data
            # Set fetched company_name and email in the text input fields
            form_data['company_name'] = company_name
            form_data['email'] = email
    except Exception as e:
        st.error(f"Error fetching company name and email: {e}")

    # Set up form fields in columns 1, 2, and 3
    with col1:
        titles = ["Mr.", "Ms.", "Company", "Mr. and Mrs", "M/S"]
        form_data['titles'] = st.selectbox("Title", titles, key='titles')

        for label, field_name in list(fields.items())[1:4]:
            if field_name == 'company_name' or field_name == 'email':
                st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
            else:
                form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''))


    with col2:
        for label, field_name in list(fields.items())[4:8]:
            if field_name == 'country':
                countries = [
                    "India", "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia",
                    "Australia", "Austria", "Austrian Empire", "Azerbaijan", "Baden", "Bahamas", "Bahrain", "Bangladesh",
                    "Barbados", "Bavaria", "Belarus", "Belgium", "Belize", "Benin (Dahomey)", "Bolivia", "Bosnia and Herzegovina",
                    "Botswana", "Brazil", "Brunei", "Brunswick and Lüneburg", "Bulgaria", "Burkina Faso (Upper Volta)", "Burma",
                    "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Cayman Islands", "Central African Republic",
                    "Central American Federation", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo Free State", "Costa Rica",
                    "Cote d’Ivoire (Ivory Coast)", "Croatia", "Cuba", "Cyprus", "Czechia", "Czechoslovakia",
                    "Democratic Republic of the Congo", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Duchy of Parma",
                    "East Germany (German Democratic Republic)", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea",
                    "Estonia", "Eswatini", "Ethiopia", "Federal Government of Germany (1848-49)", "Fiji", "Finland", "France", "Gabon",
                    "Gambia", "Georgia", "Germany", "Ghana", "Grand Duchy of Tuscany", "Greece", "Grenada", "Guatemala", "Guinea",
                    "Guinea-Bissau", "Guyana", "Haiti", "Hanover", "Hanseatic Republics", "Hawaii", "Hesse*", "Holy See", "Honduras",
                    "Hungary", "Iceland", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan",
                    "Kazakhstan", "Kenya", "Kingdom of Serbia/Yugoslavia", "Kiribati", "Korea", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos",
                    "Latvia", "Lebanon", "Lesotho", "Lew Chew (Loochoo)", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg",
                    "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius",
                    "Mecklenburg-Schwerin", "Mecklenburg-Strelitz", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro",
                    "Morocco", "Mozambique", "Namibia", "Nassau", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger",
                    "Nigeria", "North German Confederation", "North German Union", "North Macedonia", "Norway", "Oldenburg", "Oman",
                    "Orange Free State", "Pakistan", "Palau", "Panama", "Papal States", "Papua New Guinea", "Paraguay", "Peru",
                    "Philippines", "Piedmont-Sardinia", "Poland", "Portugal", "Qatar", "Republic of Genoa",
                    "Republic of Korea (South Korea)", "Republic of the Congo", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis",
                    "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia",
                    "Schaumburg-Lippe", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia",
                    "Solomon Islands", "Somalia", "South Africa", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden",
                    "Switzerland", "Syria", "Tajikistan", "Tanzania", "Texas", "Thailand", "Timor-Leste", "Togo", "Tonga",
                    "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Two Sicilies", "Uganda", "Ukraine",
                    "Union of Soviet Socialist Republics", "United States", "United Arab Emirates", "United Kingdom", "Uruguay",
                    "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Württemberg", "Yemen", "Zambia", "Zimbabwe",
                ]
                form_data[field_name] = st.selectbox(label, countries, key=field_name)
            else:
                form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''), max_chars=40)

    with col3:
        for label, field_name in list(fields.items())[8:]:
            form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''))

    # Submission button
    if st.button('Submit'):
        valid_submission = True
        for label, field_name in fields.items():
            if not validate_field(field_name, form_data[field_name]):
                st.error(f'Please enter a valid {label}.')
                valid_submission = False
                break

        if valid_submission:
            st.success('Form submitted successfully!')
            # Convert form data to a tuple
            data_tuple = tuple(form_data[field_name] for field_name in fields.values())
            # Insert data into the database and get the generated form number
            form_number = insert_into_database(conn_insert, data_tuple, request_number)

            # Insert request_number into submitted forms
            insert_into_submitted_forms(conn_submitted_forms, request_number)

            # Send email with the generated form number
            sender_email = 'testit@sangamgroup.com'  # Your email
            sender_password = 'Krishna@123'  # Your email password
            recipient_email = form_data['email']
            subject = 'Form Submission Confirmation'
            body = f'Hello,\n\nYour form submission was successful. Your form number is: {form_number}'
            if send_email(sender_email, sender_password, recipient_email, subject, body):
                st.success('Email sent successfully!')
            else:
                st.error('Failed to send email.')

            # Display the form number
            st.write(f'Your form number is: {form_number}')
