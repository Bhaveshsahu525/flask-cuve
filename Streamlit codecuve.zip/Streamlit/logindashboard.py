from flask import Flask, request, render_template, redirect, url_for
import mysql.connector
import uuid
import datetime
import logging

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.DEBUG)


# Function to authenticate users and determine redirection URL
def authenticate_and_redirect(cursor, conn, username, password):
    cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
    user_in_users = cursor.fetchone()

    cursor.execute("SELECT * FROM users_ar WHERE username = %s AND password = %s", (username, password))
    user_in_users_ar = cursor.fetchone()

    cursor.execute("SELECT * FROM users_it WHERE username = %s AND password = %s", (username, password))
    user_in_users_it = cursor.fetchone()

    if user_in_users:
        login_number = generate_login_number()
        save_login_details(cursor, conn, login_number, username)
        return f"http://localhost:8503/?login_number={login_number}"
    elif user_in_users_ar:
        login_number = generate_login_number()
        save_login_details(cursor, conn, login_number, username)
        return f"http://localhost:8516/?login_number={login_number}"
    elif user_in_users_it:
        login_number = generate_login_number()
        save_login_details(cursor, conn, login_number, username)
        return f"http://localhost:8520/?login_number={login_number}"
    else:
        return None


def save_login_details(cursor, conn, login_number, email):
    cursor.execute("INSERT INTO logged_in_user (login_number, email) VALUES (%s, %s)", (login_number, email))
    conn.commit()


def generate_login_number():
    return str(uuid.uuid4())


def delete_old_records(cursor, conn, hours):
    try:
        cutoff_time = datetime.datetime.now() - datetime.timedelta(hours=hours)
        cutoff_time_str = cutoff_time.strftime('%Y-%m-%d %H:%M:%S')  # Ensure the format is correct
        logging.debug(f"Deleting records older than: {cutoff_time_str}")
        cursor.execute("DELETE FROM logged_in_user WHERE login_time < %s", (cutoff_time_str,))
        conn.commit()
    except Exception as e:
        logging.error(f"Error deleting old records: {e}")


def create_logged_in_user_table(cursor):
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logged_in_user (
            id INT AUTO_INCREMENT PRIMARY KEY,
            login_number VARCHAR(40) NOT NULL,
            email VARCHAR(40) NOT NULL,
            login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)


conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="Logindashboard"
)
cursor = conn.cursor()
create_logged_in_user_table(cursor)


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        redirect_url = authenticate_and_redirect(cursor, conn, username, password)
        if redirect_url:
            return redirect(redirect_url)
        else:
            return render_template('login.html', error="Invalid username or password. Please try again.")
    return render_template('login.html')


@app.route('/dashboard')
def dashboard():
    login_number = request.args.get('login_number')
    return render_template('dashboard.html', login_number=login_number)


if __name__ == '__main__':
    # Example call to delete_old_records, delete records older than 24 hours
    delete_old_records(cursor, conn, 12)
    app.run(debug=True)
    app.run(port=5000)



# import streamlit as st
# import mysql.connector
# import webbrowser
# import uuid
# import datetime
#
#
# # Function to authenticate users and determine redirection URL
# def authenticate_and_redirect(cursor, username, password):
#     # Check if the user is in the 'users' table
#     cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
#     user_in_users = cursor.fetchone()
#
#     # Check if the user is in the 'users_ar' table
#     cursor.execute("SELECT * FROM users_ar WHERE username = %s AND password = %s", (username, password))
#     user_in_users_ar = cursor.fetchone()
#
#     cursor.execute("SELECT * FROM users_it WHERE username = %s AND password = %s", (username, password))
#     user_in_users_it = cursor.fetchone()
#
#     if user_in_users:
#         # Generate login number
#         login_number = generate_login_number()
#         # Save login details
#         save_login_details(cursor, login_number, username)
#         conn.commit()
#         # Redirect to URL for users
#         redirect_to_url_with_login_number("http://localhost:8503/", login_number)
#     elif user_in_users_ar:
#         # Generate login number
#         login_number = generate_login_number()
#         # Save login details
#         save_login_details(cursor, login_number, username)
#         conn.commit()
#         # Redirect to URL for users_ar
#         redirect_to_url_with_login_number("http://localhost:8513/", login_number)
#     elif user_in_users_it:
#         # Generate login number
#         login_number = generate_login_number()
#         # Save login details
#         save_login_details(cursor, login_number, username)
#         conn.commit()
#         # Redirect to URL for users_ar
#         redirect_to_url_with_login_number("http://localhost:8515/", login_number)
#     else:
#         st.error("Invalid username or password. Please try again.")
#
#
# # Function to save login details into the 'logged_in_user' table
# def save_login_details(cursor, login_number, email):
#     cursor.execute("INSERT INTO logged_in_user (login_number, email) VALUES (%s, %s)", (login_number, email))
#
#
# # Function to generate a login number
# def generate_login_number():
#     return str(uuid.uuid4())
#
#
# # Function to redirect to a URL with a login number
# def redirect_to_url_with_login_number(url, login_number):
#     webbrowser.open_new_tab(f"{url}?login_number={login_number}")
#
#
# # Function to delete old records from the 'logged_in_user' table
# def delete_old_records(cursor, hours):
#     cutoff_time = datetime.datetime.now() - datetime.timedelta(hours=hours)
#     cursor.execute("DELETE FROM logged_in_user WHERE login_time < %s", (cutoff_time,))
#     conn.commit()
#
#
# # Streamlit UI components
# st.set_page_config(layout="wide")
#
# # Define columns for logo and title
# logo_col, title_col, _ = st.columns([1, 3, 1])
#
# # Display the logo and title
# with logo_col:
#     st.image('sangam logo.png', width=120)
#
# with title_col:
#     st.markdown("<h1 style='text-align: center;'>Login Dashboard</h1>", unsafe_allow_html=True)
#
# # Establish MySQL connection
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="",
#     database="Logindashboard"
# )
# cursor = conn.cursor()
#
#
# # Function to create the table 'logged_in_user' if it doesn't exist
# def create_logged_in_user_table(cursor):
#     cursor.execute("""
#         CREATE TABLE IF NOT EXISTS logged_in_user (
#             id INT AUTO_INCREMENT PRIMARY KEY,
#             login_number VARCHAR(40) NOT NULL,
#             email VARCHAR(40) NOT NULL,
#             login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#         )
#     """)
#
#
# # Create the 'logged_in_user' table if it doesn't exist
# create_logged_in_user_table(cursor)
#
# # Function to handle login and redirection
# def login_and_redirect():
#     username = st.text_input("Email id")
#     password = st.text_input("Password", type="password")
#
#     if st.button("Login"):
#         authenticate_and_redirect(cursor, username, password)
#
#
# # Input fields for username and password
# with st.columns([1, 1, 1])[1]:
#     login_and_redirect()
#
# # Delete old records every 6 hours
# delete_old_records(cursor, 12)
#
# # Close MySQL connection
# cursor.close()
# conn.close()
