import streamlit as st
import mysql.connector
from datetime import datetime, timedelta

# Function to fetch the logged-in user's email from the database based on login number
def fetch_logged_in_user_email(conn, login_number):
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM logged_in_user WHERE login_number = %s", (login_number,))
    result = cursor.fetchone()
    cursor.close()
    return result[0] if result else None

# Function to fetch the form details from MySQL database based on date range and logged-in user's email
def fetch_form_details_by_date_range_and_email(conn, start_date, end_date, logged_in_user_email):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT cr.logged_in_user_email, fd.name_1, fd.customer_account_group, fd.form_number
        FROM formsubmitteddetails.marketing_submission AS fd
        JOIN emailssenttocustomer.customerrequested AS cr ON fd.request_number = cr.request_number
        WHERE fd.submission_date BETWEEN %s AND %s
        ORDER BY fd.submit_timestamp DESC
    """, (start_date, end_date))
    form_details = cursor.fetchall()
    cursor.close()
    return form_details

# Function to fetch the form details from MySQL database based on form number
def fetch_form_details_by_marketing_submission_and_email(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT name_1, form_number, form_data
        FROM marketing_submission
        WHERE form_number = %s
    """, (form_number,))
    form_details = cursor.fetchone()
    cursor.close()
    return form_details

# Function to check if form number exists in account_final table
def form_number_exists_in_account_final(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM it_final WHERE form_number = %s", (form_number,))
    result = cursor.fetchone()[0]
    cursor.close()
    return result > 0

# Function to check if form number exists in changes_required table and get details
def get_changes_required_details(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("SELECT details FROM changes_requestedtoar WHERE form_number = %s", (form_number,))
    result = cursor.fetchone()
    cursor.close()
    return result[0] if result else None

# Function to check if form number exists in changesdoneby_marketing table
def get_changesdoneby_marketing_status(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM changesdoneby_ar WHERE form_number = %s", (form_number,))
    result = cursor.fetchone()[0]
    cursor.close()
    return "Changes done" if result > 0 else ""

def redirect_to_url(url):
    st.markdown(f'<meta http-equiv="refresh" content="0;URL={url}">', unsafe_allow_html=True)

# Streamlit app
def main():
    st.title('Form Submitted by Marketing Team')

    # Retrieve login number from URL
    query_params = st.query_params
    login_number = query_params.get('login_number', '')

    # Sidebar
    st.sidebar.title("Logged-in User")

    # Connect to the database for logged-in users
    conn_login = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="logindashboard"
    )

    # Fetch logged-in user's email
    logged_in_user_email = fetch_logged_in_user_email(conn_login, login_number)
    conn_login.close()

    if logged_in_user_email:
        st.sidebar.markdown(f"**{logged_in_user_email}**")

        # Logout button
        if st.sidebar.button("Logout"):
            conn_work_done = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="logindashboard"
            )
            cursor = conn_work_done.cursor()
            cursor.execute("DELETE FROM logged_in_user WHERE login_number = %s", (login_number,))
            conn_work_done.commit()
            cursor.close()
            conn_work_done.close()
            redirect_to_url("http://127.0.0.1:5000/")  # Redirect to the login page
    else:
        st.error("User not logged in. Please log in to view the dashboard.")
        st.stop()

    if st.sidebar.button('Changes Requested By IT'):
        # Specify the URL to redirect to with login_number as a parameter
        redirect_url = f"http://localhost:8519/?login_number={login_number}"
        redirect_to_url(redirect_url)
        return

    # Sidebar options
    st.sidebar.title("Options")
    start_date = st.sidebar.date_input("Start Date", datetime.now() - timedelta(days=2))
    end_date = st.sidebar.date_input("End Date", datetime.now())

    # Create an empty element to hold the table
    table_placeholder = st.empty()

    conn_form_details = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="formsubmitteddetails"
    )

    # Fetch the form details from the database based on date range and logged-in user's email
    form_details = fetch_form_details_by_date_range_and_email(conn_form_details, start_date, end_date, logged_in_user_email)

    # Display the form details in a table
    if form_details:
        data = {
            "User": [],
            "Company Name": [],
            "Category": [],
            "Form Link": [],
            "Status/Details": [],  # Existing column
            "Market Changes": []   # New column
        }
        for detail in form_details:
            logged_in_user_email, name_1, customer_account_group, form_number = detail
            data["User"].append(logged_in_user_email)
            data["Company Name"].append(name_1)
            data["Category"].append(customer_account_group)
            if form_number_exists_in_account_final(conn_form_details, form_number):
                status_details = "Form sent to the IT Team"
            else:
                changes_required_details = get_changes_required_details(conn_form_details, form_number)
                status_details = changes_required_details if changes_required_details else "N/A"
            data["Status/Details"].append(status_details)
            # Generate form link based on category
            if customer_account_group == "ZEXP":
                form_link = f'[View Form](http://localhost:8522/?form_number={form_number})'
            elif customer_account_group in ["ZDOM", "ZDSH"]:
                form_link = f'[View Form](http://localhost:8521/?form_number={form_number})'
            else:
                form_link = "Wrong category selected"

            data["Form Link"].append(form_link)

            # Get market changes status
            if get_changesdoneby_marketing_status(conn_form_details, form_number):
                market_changes_status = "Changes done"
            elif get_changes_required_details(conn_form_details, form_number):
                market_changes_status = "Still pending"
            else:
                market_changes_status = ""
            data["Market Changes"].append(market_changes_status)

        table_markdown = "| User | Company Name | Category | Form Link | Market Changes | Status/Details |\n| --- | --- | --- | --- | --- | --- |\n"
        for i in range(len(data["User"])):
            table_markdown += f"| {data['User'][i]} | {data['Company Name'][i]} | {data['Category'][i]} | {data['Form Link'][i]} | {data['Market Changes'][i]} | {data['Status/Details'][i]}|\n"
        table_placeholder.markdown(table_markdown)

    conn_form_details.close()

if __name__ == "__main__":
    main()
