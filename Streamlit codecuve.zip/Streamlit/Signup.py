import streamlit as st
import mysql.connector
import pandas as pd
import re
import webbrowser

# Function to create the users table
def create_users_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')

# Function to create the users_ar table
def create_users_ar_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_ar
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')

# Function to create the users_it table
def create_users_it_table(cursor):
    cursor.execute('''CREATE TABLE IF NOT EXISTS users_it
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(40) UNIQUE,
                      password VARCHAR(40))''')

# Function to add a new user to the database
def add_user(cursor, table_name, username, password):
    cursor.execute(f"INSERT INTO {table_name} (username, password) VALUES (%s, %s)", (username, password))

# Function to fetch all user details (excluding ID)
def fetch_all_users(cursor, table_name):
    cursor.execute(f"SELECT username, password FROM {table_name}")
    return cursor.fetchall()

# Function to delete a user from the database
def delete_user(cursor, table_name, username):
    cursor.execute(f"DELETE FROM {table_name} WHERE username = %s", (username,))
    return cursor.rowcount

# Function to validate email format
def validate_email(email):
    email_regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(email_regex, email))

# Function to validate password format (for demonstration purposes, let's assume password must be at least 6 characters)
def validate_password(password):
    return len(password) >= 6

# Function to redirect to a URL
def redirect_to_url(url):
    webbrowser.open_new_tab(url)

# Streamlit UI
st.set_page_config(layout="wide")

# Sidebar
st.sidebar.title("Select Department")
selected_department = st.sidebar.radio("Department", ["Marketing", "AR", "IT"])

# Sidebar for User Deletion
st.sidebar.title("User Deletion")
username_to_delete = st.sidebar.text_input("Enter the username to delete:")
delete_button = st.sidebar.button("Delete User")

# Define columns for logo and title
logo_col, title_col, _ = st.columns([1, 3, 1])

# Display the logo and title
with logo_col:
    st.image('sangam logo.png', width=120)

with title_col:
    st.markdown("<h1 style='text-align: center;'>User Management</h1>", unsafe_allow_html=True)

# Center the dashboard in the middle column
with st.columns([1, 1, 1])[1]:
    new_username = st.text_input("Email Id")
    new_password = st.text_input("Create Password", type="password")

    # Sign-up button below text inputs
    if st.button("Create User", key="signup_button"):
        if not validate_email(new_username):
            st.error("Please enter a valid email address.")
        elif not validate_password(new_password):
            st.error("Password must be at least 6 characters.")
        else:
            # Establish MySQL connection
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",  # Enter your password here
                database="Logindashboard"
            )
            cursor = conn.cursor()

            # Initialize the appropriate table based on the selected department
            if selected_department == "Marketing":
                create_users_table(cursor)
                add_user(cursor, "users", new_username, new_password)
            elif selected_department == "AR":
                create_users_ar_table(cursor)
                add_user(cursor, "users_ar", new_username, new_password)
            elif selected_department == "IT":
                create_users_it_table(cursor)
                add_user(cursor, "users_it", new_username, new_password)

            conn.commit()

            # Close MySQL connection
            cursor.close()
            conn.close()

            st.success("User created successfully.")
            # Redirect to the specified URL
            redirect_to_url("http://127.0.0.1:5000/")

    # Button to show all users
    if st.button("Show All Users"):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Enter your password here
            database="Logindashboard"
        )
        cursor = conn.cursor()

        # Fetch all user details based on the selected department
        if selected_department == "Marketing":
            users_data = fetch_all_users(cursor, "users")
        elif selected_department == "AR":
            users_data = fetch_all_users(cursor, "users_ar")
        elif selected_department == "IT":
            users_data = fetch_all_users(cursor, "users_it")

        # Close MySQL connection
        cursor.close()
        conn.close()

        # Display user details (excluding ID) in tabular format
        if users_data:
            df = pd.DataFrame(users_data, columns=["Username", "Password"])
            st.write(df)
        else:
            st.warning("No users found.")

    # Perform user deletion
    if delete_button:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Enter your password here
            database="Logindashboard"
        )
        cursor = conn.cursor()

        # Delete user based on the selected department
        if selected_department == "Marketing":
            rows_deleted = delete_user(cursor, "users", username_to_delete)
        elif selected_department == "AR":
            rows_deleted = delete_user(cursor, "users_ar", username_to_delete)
        elif selected_department == "IT":
            rows_deleted = delete_user(cursor, "users_it", username_to_delete)

        conn.commit()
        cursor.close()
        conn.close()

        if rows_deleted > 0:
            st.success(f"User '{username_to_delete}' deleted successfully.")
        else:
            st.warning(f"No user with username '{username_to_delete}' found.")
