import streamlit as st
import mysql.connector
import base64
import pandas as pd
from io import BytesIO

def value_before_hyphen(value):
    return value.split(' - ')[0] if ' - ' in value else value

# Connect to MySQL database for fetching data
def connect_to_fetch_database():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="formsubmitteddetails"
        )
        return conn
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")
        return None

# Function to download PDF
def pdf_download(pdf_data, filename):
    with open(filename, "wb") as f:
        f.write(base64.b64decode(pdf_data))

    st.markdown(f'<a href="data:application/pdf;base64,{base64.b64encode(pdf_data).decode()}" download="{filename}">Download PDF</a>', unsafe_allow_html=True)

# Function to insert form number into account_final table
def insert_form_number(conn, form_number):
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO it_final (form_number) VALUES (%s)", (form_number,))
        conn.commit()
        cursor.close()
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")

def save_changes_required(conn, form_number, details):
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO changes_requestedtoar (form_number, details) VALUES (%s, %s)", (form_number, details))
        conn.commit()
        cursor.close()
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")

def export_to_excel(data, filename):
    output = BytesIO()
    df = pd.DataFrame(data, index=[0])
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Form Data')
    processed_data = output.getvalue()
    b64 = base64.b64encode(processed_data).decode()
    link = f'<a href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{b64}" download="{filename}">Download Excel file</a>'
    st.markdown(link, unsafe_allow_html=True)

# Set up the Streamlit app layout
st.set_page_config(layout="wide")

# Define columns for logo and title
logo_col, title_col = st.columns([1, 3])

# Display the logo and title
with logo_col:
    st.image('sangam logo.png', width=100)

with title_col:
    st.markdown("<h1 style='text-align: left;'>Please Check The Below Details</h1>", unsafe_allow_html=True)

# Define columns for form fields
col1, col2, col3, col4 = st.columns(4)

# Set up form fields
fields = {
    'CUSTOMER ACCOUNT GROUP': 'customer_account_group',  # 1
    'COMPANY CODE': 'company_code',  # 2
    'SALES ORG.': 'sales_org',  # 3
    'DISTR. CHANNEL': 'distribution_channel', #4
    'DIVISION': 'division',  # 5
    'TITLES': 'titles',  # 6
    'NAME1': 'name_1',  # 7
    'NAME2': 'name_2',  # 8
    'SEARCH 1': 'search_1',  # 9
    'SEARCH 2 (OLD CUSTOMER CODE)': 'search_2_old_customer_code',  # 10
    'STREET 3': 'street_3',  # 11
    'STREET / HOUSE NUMBER': 'street_house_number',  # 12
    'STREET 2': 'street_2',  # 13
    'STREET': 'street',  # 14
    'STREET4': 'street_4',  # 15
    'STREET5': 'street_5',  # 16
    'DISTRICT': 'district',  # 17
    'DIFFERENT CITY': 'different_city',  # 18
    'PIN CODE': 'pin_code',  # 19
    'CITY': 'city',  # 20
    'COUNTRY': 'country',  # 21
    'REGION': 'region',  # 22
    'LANGUANGE': 'language', #23
    'TELPHONE NUMBER 1': 'telephone_number_1',  # 24
    'MOBILE NUMBER 1': 'mobile_number_1',  # 25
    'CONTACT PERSON 1 (COMMENTS OF MOBILE NUMBER)': 'contact_person_1_comments_of_mobile_number',  # 26
    'FAX': 'fax',  # 27
    'EXTENSION': 'extension',  # 28
    'EMAIL 1': 'email_1',  # 29
    'DEPARTMENT 1 (NOTES OF E-MAIL)': 'department_1_notes_of_email',  # 30
    'MOBILE PHONE-2': 'mobile_phone_2',  # 31
    'CONTACT PERSON 2 (COMMENTS OF MOBILE NUMBER)': 'contact_person_2_comments_of_mobile_number',  # 32
    'EMAIL 2': 'email_2',  # 33
    'DEPARTMENT 2 (NOTES OF E-MAIL)': 'department_2_notes_of_email',  # 34
    'MOBILE PHONE-3': 'mobile_phone_3',  # 35
    'CONTACT PERSON 3 (COMMENTS OF MOBILE NUMBER)': 'contact_person_3_comments_of_mobile_number',  # 36
    'EMAIL 3': 'email_3',  # 37
    'DEPARTMENT 3 (NOTES OF E-MAIL)': 'department_3_notes_of_email',  # 38
    'LEGAL FORM': 'legal_form',  # 39
    'BP TYPE': 'bp_type',  # 40
    'PAN CARD': 'pan_card',  # 41
    'GST CATEGORY': 'gst_category', #42
    'GSTIN NO': 'gstin_no',  # 43
    'ANNUAL SALES': 'annual_sales',  # 44
    'CURRENCY': 'currency',  # 45
    'SALES YEAR': 'sales_year',  # 46
    'SALES DISTRICT': 'sales_district',  # 47
    'SALES OFFICE': 'sales_office',  # 48
    'SALES GROUP': 'sales_group',  # 49
    'CURRENCY2': 'currency_2',  # 50
    'PRICE GROUP': 'price_group',  # 51
    'CUST.PRIC.PROCEDURE': 'cust_pric_procedure',  # 52
    'ORDER COMBINATION INDICATOR': 'order_combination_indicator',  # 53
    'DELIVERING PLANT': 'delivering_plant',  # 54
    'SHIPPING CONDITIONS': 'shipping_conditions', #55
    'UNDERDEL. TOLERANCE': 'underdel_tolerance',  # 56
    'OVERDELIV. TOLERANCE': 'overdeliv_tolerance',  # 57
    'INDICATOR: CUSTOMER IS REBATE-RELEVANT': 'indicator_customer_is_rebate_relevant',  #58
    'RELEVANT FOR PRICE DETERMINATION ID': 'relevant_for_price_determination_id',  #59
    'INCOTERMS': 'incoterms',  # 60
    'INCOTERMS LOCATION': 'incoterms_location',  # 61
    'PAYMENT TERMS': 'payment_terms',  # 62
    'CREDIT CONTROL AREA': 'credit_control_area',  # 63
    'ACCT ASSMT GRP CUST.': 'acct_assmt_grp_cust',  #64
    'TAX CATEGORY': 'tax_category',  #65
    'TAX CATEGORY2': 'tax_category_2',  #66
    'TAX CATEGORY3': 'tax_category_3',  #67
    'TAX CATEGORY4': 'tax_category_4',  #68
    'AGENT': 'agent',  # 69
    'AGENT-CODE': 'agent_code',  # 70
    'BROKER AGENT': 'broker_agent',  # 71
    'BROKER AGENT-CODE': 'broker_agent_code',  # 72
    'FORWARDING AGENT': 'forwarding_agent',  # 73
    'FORWARDING AGENT-CODE': 'forwarding_agent_code',  # 74
    'SALES PERSON': 'sales_person',  # 75
    'SALES PERSON-CODE': 'sales_person_code',  # 76
    'RECON ACCOUNT': 'recon_account',  # 77
    'SORT KEY': 'sort_key',  # 78
    'PLANNING GROUP': 'planning_group',  # 79
    'PAYMENT TERMS2': 'payment_terms_2',  # 80
    'PAYMENT METHODS': 'payment_methods',  # 81
    'DUNNING PROCEDURE': 'dunning_procedure',# 82
    'RELATIONSHIP CATEGORY': 'relationship_category',# 83
}

# Set up form data with retrieved values
form_data = {}

# Extract form_number from URL
params = st.query_params
form_number = params.get('form_number', None)

# Connect to MySQL database for fetching data
conn_fetch = connect_to_fetch_database()

if conn_fetch and form_number:
    # Construct SQL query to fetch form data for the given form number
    query = """
        SELECT
            ms.customer_account_group, ms.company_code, ms.sales_org, ms.division, ms.titles, ms.name_1, ms.name_2, ms.search_1,
            ms.search_2_old_customer_code, ms.street_3, ms.street_house_number, ms.street_2, ms.street, ms.street_4, ms.street_5,
            ms.district, ms.different_city, ms.pin_code, ms.city, ms.country, ms.region, ms.telephone_number_1, ms.mobile_number_1,
            ms.contact_person_1_comments_of_mobile_number, ms.email_1, ms.department_1_notes_of_email, ms.mobile_phone_2,
            ms.contact_person_2_comments_of_mobile_number, ms.email_2, ms.department_2_notes_of_email, ms.mobile_phone_3,
            ms.contact_person_3_comments_of_mobile_number, ms.email_3, ms.department_3_notes_of_email, ms.legal_form, ms.bp_type,
            ms.pan_card, ms.gstin_no, ms.annual_sales, ms.currency, ms.sales_year, ms.sales_district, ms.sales_office,
            ms.sales_group, ms.currency_2, ms.delivering_plant, ms.overdeliv_tolerance, ms.incoterms, ms.incoterms_location,
            ms.payment_terms, ms.credit_control_area, ms.agent_code, ms.broker_agent, ms.broker_agent_code, ms.forwarding_agent,
            ms.forwarding_agent_code, ms.sales_person, ms.sales_person_code, ms.recon_account, ms.sort_key, ms.planning_group,
            ms.payment_terms_2, ms.payment_methods, ms.dunning_procedure, ms.relationship_category, ms.distribution_channel,
            ms.language, ms.fax, ms.extension, ms.gst_category, ms.price_group, ms.cust_pric_procedure, ms.order_combination_indicator,
            ms.shipping_conditions, ms.underdel_tolerance, ms.indicator_customer_is_rebate_relevant, ms.relevant_for_price_determination_id,
            ms.acct_assmt_grp_cust, ms.tax_category, ms.tax_category_2, ms.tax_category_3, ms.tax_category_4, ms.agent
        FROM
            marketing_submission ms
        LEFT JOIN
            form_details fd
        ON
            ms.form_number = fd.form_number
        WHERE
            ms.form_number = %s
    """
    # Execute the query
    cur = conn_fetch.cursor()
    cur.execute(query, (form_number,))

    # Fetch all rows
    results = cur.fetchall()

    # Process the results
    for row in results:
        (
            customer_account_group, company_code, sales_org, division, titles, name_1, name_2, search_1,
            search_2_old_customer_code, street_3, street_house_number, street_2, street, street_4, street_5, district,
            different_city, pin_code, city, country, region, telephone_number_1, mobile_number_1,
            contact_person_1_comments_of_mobile_number, email_1, department_1_notes_of_email, mobile_phone_2,
            contact_person_2_comments_of_mobile_number, email_2, department_2_notes_of_email, mobile_phone_3,
            contact_person_3_comments_of_mobile_number, email_3, department_3_notes_of_email, legal_form, bp_type,
            pan_card, gstin_no, annual_sales, currency, sales_year, sales_district, sales_office, sales_group,
            currency_2, delivering_plant, overdeliv_tolerance, incoterms, incoterms_location, payment_terms,
            credit_control_area, agent_code, broker_agent, broker_agent_code, forwarding_agent, forwarding_agent_code,
            sales_person, sales_person_code, recon_account, sort_key, planning_group, payment_terms_2, payment_methods,
            dunning_procedure, relationship_category, distribution_channel, language, fax, extension, gst_category,
            price_group, cust_pric_procedure, order_combination_indicator, shipping_conditions, underdel_tolerance,
            indicator_customer_is_rebate_relevant, relevant_for_price_determination_id, acct_assmt_grp_cust,
            tax_category, tax_category_2, tax_category_3, tax_category_4, agent
        ) = row

        # Replace 'None' strings with blank strings for relevant fields
        customer_account_group = customer_account_group if customer_account_group != 'None' else ''
        company_code = company_code if company_code != 'None' else ''
        sales_org = sales_org if sales_org != 'None' else ''
        division = division if division != 'None' else ''
        titles = titles if titles != 'None' else ''
        name_1 = name_1 if name_1 != 'None' else ''
        name_2 = name_2 if name_2 != 'None' else ''
        search_1 = search_1 if search_1 != 'None' else ''
        search_2_old_customer_code = search_2_old_customer_code if search_2_old_customer_code != 'None' else ''
        street_3 = street_3 if street_3 != 'None' else ''
        street_house_number = street_house_number if street_house_number != 'None' else ''
        street_2 = street_2 if street_2 != 'None' else ''
        street = street if street != 'None' else ''
        street_4 = street_4 if street_4 != 'None' else ''
        street_5 = street_5 if street_5 != 'None' else ''
        district = district if district != 'None' else ''
        different_city = different_city if different_city != 'None' else ''
        pin_code = pin_code if pin_code != 'None' else ''
        city = city if city != 'None' else ''
        country = country if country != 'None' else ''
        region = region if region != 'None' else ''
        telephone_number_1 = telephone_number_1 if telephone_number_1 != 'None' else ''
        mobile_number_1 = mobile_number_1 if mobile_number_1 != 'None' else ''
        contact_person_1_comments_of_mobile_number = contact_person_1_comments_of_mobile_number if contact_person_1_comments_of_mobile_number != 'None' else ''
        email_1 = email_1 if email_1 != 'None' else ''
        department_1_notes_of_email = department_1_notes_of_email if department_1_notes_of_email != 'None' else ''
        mobile_phone_2 = mobile_phone_2 if mobile_phone_2 != 'None' else ''
        contact_person_2_comments_of_mobile_number = contact_person_2_comments_of_mobile_number if contact_person_2_comments_of_mobile_number != 'None' else ''
        email_2 = email_2 if email_2 != 'None' else ''
        department_2_notes_of_email = department_2_notes_of_email if department_2_notes_of_email != 'None' else ''
        mobile_phone_3 = mobile_phone_3 if mobile_phone_3 != 'None' else ''
        contact_person_3_comments_of_mobile_number = contact_person_3_comments_of_mobile_number if contact_person_3_comments_of_mobile_number != 'None' else ''
        email_3 = email_3 if email_3 != 'None' else ''
        department_3_notes_of_email = department_3_notes_of_email if department_3_notes_of_email != 'None' else ''
        legal_form = legal_form if legal_form != 'None' else ''
        bp_type = bp_type if bp_type != 'None' else ''
        pan_card = pan_card if pan_card != 'None' else ''
        gstin_no = gstin_no if gstin_no != 'None' else ''
        annual_sales = annual_sales if annual_sales != 'None' else ''
        currency = currency if currency != 'None' else ''
        sales_year = sales_year if sales_year != 'None' else ''
        sales_district = sales_district if sales_district != 'None' else ''
        sales_office = sales_office if sales_office != 'None' else ''
        sales_group = sales_group if sales_group != 'None' else ''
        currency_2 = currency_2 if currency_2 != 'None' else ''
        delivering_plant = delivering_plant if delivering_plant != 'None' else ''
        overdeliv_tolerance = overdeliv_tolerance if overdeliv_tolerance != 'None' else ''
        incoterms = incoterms if incoterms != 'None' else ''
        incoterms_location = incoterms_location if incoterms_location != 'None' else ''
        payment_terms = payment_terms if payment_terms != 'None' else ''
        credit_control_area = credit_control_area if credit_control_area != 'None' else ''
        agent_code = agent_code if agent_code != 'None' else ''
        broker_agent = broker_agent if broker_agent != 'None' else ''
        broker_agent_code = broker_agent_code if broker_agent_code != 'None' else ''
        forwarding_agent = forwarding_agent if forwarding_agent != 'None' else ''
        forwarding_agent_code = forwarding_agent_code if forwarding_agent_code != 'None' else ''
        sales_person = sales_person if sales_person != 'None' else ''
        sales_person_code = sales_person_code if sales_person_code != 'None' else ''
        recon_account = recon_account if recon_account != 'None' else ''
        sort_key = sort_key if sort_key != 'None' else ''
        planning_group = planning_group if planning_group != 'None' else ''
        payment_terms_2 = payment_terms_2 if payment_terms_2 != 'None' else ''
        payment_methods = payment_methods if payment_methods != 'None' else ''
        dunning_procedure = dunning_procedure if dunning_procedure != 'None' else ''
        relationship_category = relationship_category if relationship_category != 'None' else ''
        distribution_channel = distribution_channel if distribution_channel != 'None' else ''
        language = language if language != 'None' else ''
        fax = fax if fax != 'None' else ''
        extension = extension if extension != 'None' else ''
        gst_category = gst_category if gst_category != 'None' else ''
        price_group = price_group if price_group != 'None' else ''
        cust_pric_procedure = cust_pric_procedure if cust_pric_procedure != 'None' else ''
        order_combination_indicator = order_combination_indicator if order_combination_indicator != 'None' else ''
        shipping_conditions = shipping_conditions if shipping_conditions != 'None' else ''
        underdel_tolerance = underdel_tolerance if underdel_tolerance != 'None' else ''
        indicator_customer_is_rebate_relevant = indicator_customer_is_rebate_relevant if indicator_customer_is_rebate_relevant != 'None' else ''
        relevant_for_price_determination_id = relevant_for_price_determination_id if relevant_for_price_determination_id != 'None' else ''
        acct_assmt_grp_cust = acct_assmt_grp_cust if acct_assmt_grp_cust != 'None' else ''
        tax_category = tax_category if tax_category != 'None' else ''
        tax_category_2 = tax_category_2 if tax_category_2 != 'None' else ''
        tax_category_3 = tax_category_3 if tax_category_3 != 'None' else ''
        tax_category_4 = tax_category_4 if tax_category_4 != 'None' else ''
        agent = agent if agent != 'None' else ''


        # Extract values before hyphen
        company_code = value_before_hyphen(company_code)
        sales_org = value_before_hyphen(sales_org)
        division = value_before_hyphen(division)
        legal_form = value_before_hyphen(legal_form)
        bp_type = value_before_hyphen(bp_type)
        sales_office = value_before_hyphen(sales_office)
        sales_group = value_before_hyphen(sales_group)
        delivering_plant = value_before_hyphen(delivering_plant)
        incoterms = value_before_hyphen(incoterms)
        payment_terms = value_before_hyphen(payment_terms)
        sort_key = value_before_hyphen(sort_key)
        planning_group = value_before_hyphen(planning_group)
        payment_terms_2 = value_before_hyphen(payment_terms_2)
        payment_methods = value_before_hyphen(payment_methods)


        # Set fetched values in the form fields
        form_data = {
            'customer_account_group': customer_account_group or '',
            'company_code': company_code or '',
            'sales_org': sales_org or '',
            'division': division or '',
            'titles': titles or '',
            'name_1': name_1 or '',
            'name_2': name_2 or '',
            'search_1': search_1 or '',
            'search_2_old_customer_code': search_2_old_customer_code or '',
            'street_3': street_3 or '',
            'street_house_number': street_house_number or '',
            'street_2': street_2 or '',
            'street': street or '',
            'street_4': street_4 or '',
            'street_5': street_5 or '',
            'district': district or '',
            'different_city': different_city or '',
            'pin_code': pin_code or '',
            'city': city or '',
            'country': country or '',
            'region': region or '',
            'telephone_number_1': telephone_number_1 or '',
            'mobile_number_1': mobile_number_1 or '',
            'contact_person_1_comments_of_mobile_number': contact_person_1_comments_of_mobile_number or '',
            'email_1': email_1 or '',
            'department_1_notes_of_email': department_1_notes_of_email or '',
            'mobile_phone_2': mobile_phone_2 or '',
            'contact_person_2_comments_of_mobile_number': contact_person_2_comments_of_mobile_number or '',
            'email_2': email_2 or '',
            'department_2_notes_of_email': department_2_notes_of_email or '',
            'mobile_phone_3': mobile_phone_3 or '',
            'contact_person_3_comments_of_mobile_number': contact_person_3_comments_of_mobile_number or '',
            'email_3': email_3 or '',
            'department_3_notes_of_email': department_3_notes_of_email or '',
            'legal_form': legal_form or '',
            'bp_type': bp_type or '',
            'pan_card': pan_card or '',
            'gstin_no': gstin_no or '',
            'annual_sales': annual_sales or '',
            'currency': currency or '',
            'sales_year': sales_year or '',
            'sales_district': sales_district or '',
            'sales_office': sales_office or '',
            'sales_group': sales_group or '',
            'currency_2': currency_2 or '',
            'delivering_plant': delivering_plant or '',
            'overdeliv_tolerance': overdeliv_tolerance or '',
            'incoterms': incoterms or '',
            'incoterms_location': incoterms_location or '',
            'payment_terms': payment_terms or '',
            'credit_control_area': credit_control_area or '',
            'agent_code': agent_code or '',
            'broker_agent': broker_agent or '',
            'broker_agent_code': broker_agent_code or '',
            'forwarding_agent': forwarding_agent or '',
            'forwarding_agent_code': forwarding_agent_code or '',
            'sales_person': sales_person or '',
            'sales_person_code': sales_person_code or '',
            'recon_account': recon_account or '',
            'sort_key': sort_key or '',
            'planning_group': planning_group or '',
            'payment_terms_2': payment_terms_2 or '',
            'payment_methods': payment_methods or '',
            'dunning_procedure': dunning_procedure or '',
            'relationship_category': relationship_category or '',
            'distribution_channel': distribution_channel or '',
            'language': language or '',
            'fax': fax or '',
            'extension': extension or '',
            'gst_category': gst_category or '',
            'price_group': price_group or '',
            'cust_pric_procedure': cust_pric_procedure or '',
            'order_combination_indicator': order_combination_indicator or '',
            'shipping_conditions': shipping_conditions or '',
            'underdel_tolerance': underdel_tolerance or '',
            'indicator_customer_is_rebate_relevant': indicator_customer_is_rebate_relevant or '',
            'relevant_for_price_determination_id': relevant_for_price_determination_id or '',
            'acct_assmt_grp_cust': acct_assmt_grp_cust or '',
            'tax_category': tax_category or '',
            'tax_category_2': tax_category_2 or '',
            'tax_category_3': tax_category_3 or '',
            'tax_category_4': tax_category_4 or '',
            'agent': agent or ''
        }

    cur.close()
    conn_fetch.close()

with col1:
    for label, field_name in list(fields.items())[:21]:
        st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)

with col2:
    for label, field_name in list(fields.items())[21:42]:
        st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)

with col3:
    for label, field_name in list(fields.items())[42:63]:
        st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)

with col4:
    for label, field_name in list(fields.items())[63:]:
        st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)

# Submission button
if st.button('Submit'):
    st.success('Form submitted successfully!')
    insert_conn = connect_to_fetch_database()
    if insert_conn:
        insert_form_number(insert_conn, form_number)
        insert_conn.close()

# Export to Excel button
if st.button('Export to Excel'):
    if form_data:
        exportable_data = {k: v for k, v in form_data.items() if k not in ['gst_document', 'pan_document']}
        export_to_excel(exportable_data, 'Form_Data.xlsx')
    else:
        st.error("No data to export.")

changes_required_details = st.text_area("Details for Changes Required")
# Save changes required when button is clicked
if st.button('Changes Required'):
    changes_required_conn = connect_to_fetch_database()
    if changes_required_conn:
        save_changes_required(changes_required_conn, form_number, changes_required_details)
        changes_required_conn.close()
        st.success('Changes required details saved successfully!')

