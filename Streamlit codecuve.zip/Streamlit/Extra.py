# streamlit run checkfile.py
# streamlit run signup.py
# streamlit run autoemailsending.py
# streamlit run totalnewrowsinserted.py
# streamlit run changesrequestedbyar.py
# streamlit run changesrequestedbyitforM.py
# streamlit run formsenttoclientd.py
# streamlit run formsenttocliente.py
# streamlit run formsenttoclients.py
# streamlit run marketingteamds.py
# streamlit run marketingteame.py
# streamlit run marketingteamchangesDSforAR.py
# streamlit run marketingteamchangesEforAR.py
# streamlit run marketingteamchangesDSforIT.py
# streamlit run marketingteamchangesEforIT.py
# streamlit run marketcheckbyar.py
# streamlit run arteamformds.py
# streamlit run arteamforme.py
# streamlit run changesrequestedbyitforAR.py
# streamlit run archeckbyIT.py
# streamlit run itteamformds.py
# streamlit run itteamforme.py
# python logindashboard.py




Extra code

1. in the below code the sign up and login dashboard both are on the same page:-

# import streamlit as st
# import mysql.connector
# import re
# import webbrowser
#
# # Function to create the users table
# def create_users_table(cursor):
#     cursor.execute('''CREATE TABLE IF NOT EXISTS users
#                       (id INT AUTO_INCREMENT PRIMARY KEY,
#                       username VARCHAR(255) UNIQUE,
#                       password VARCHAR(255))''')
#
# # Function to add a new user to the database
# def add_user(cursor, username, password):
#     cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
#
# # Function to authenticate users
# def authenticate(cursor, username, password):
#     cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
#     result = cursor.fetchone()
#     if result:
#         return True
#     else:
#         return False
#
# # Function to redirect to a URL
# def redirect_to_url(url):
#     webbrowser.open_new_tab(url)
#
# # Function to validate email format
# def validate_email(email):
#     email_regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
#     return bool(re.match(email_regex, email))
#
# # Function to validate password format (for demonstration purposes, let's assume password must be at least 6 characters)
# def validate_password(password):
#     return len(password) >= 6
#
#
# # Streamlit UI components
# st.title("Login Dashboard")
#
# # Establish MySQL connection
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="",
#     database="Logindashboard"
# )
# cursor = conn.cursor()
#
# # Initialize the users table
# create_users_table(cursor)
# conn.commit()
#
# # Input fields for username and password
# username = st.text_input("Email id")
# password = st.text_input("Password", type="password")
#
# # Login button
# if st.button("Login"):
#     if authenticate(cursor, username, password):
#         st.success("Login Successful!")
#         # Redirect to another page upon successful login
#         redirect_to_url("http://localhost:8502/")  # Replace with your desired URL
#     else:
#         st.error("Invalid username or password. Please try again.")
#
# # Sign-up section
# st.sidebar.title("Sign Up")
# new_username = st.sidebar.text_input("Email Id")
# new_password = st.sidebar.text_input("Create Password", type="password")
#
# if st.sidebar.button("Sign Up"):
#     if not validate_email(new_username):
#         st.sidebar.error("Please enter a valid email address.")
#     elif not validate_password(new_password):
#         st.sidebar.error("Password must be at least 6 characters.")
#     else:
#         add_user(cursor, new_username, new_password)
#         conn.commit()
#         st.sidebar.success("Sign Up Successful! You can now login.")
#
# # Close MySQL connection
# cursor.close()
# conn.close()


2. More optimized code of autoemailsending


# import streamlit as st
# import re
#
# def validate_field(field_name, field_value):
#     # Dictionary mapping field names to regular expressions
#     validation_patterns = {
#         'name': r'^[a-zA-Z\s.,()-]+$',
#         'email': r'^[\w\.-]+@[\w\.-]+\.\w+$',
#         'company_name': r'^[a-zA-Z0-9\s.,()-]+$',
#         'country': r'^[a-zA-Z\s.,()-]+$',
#         'state': r'^[a-zA-Z\s.,()-]+$',
#         'city': r'^[a-zA-Z\s.,()-]+$',
#         'postal_code': r'^\d{6}$',
#         'street_address': r'^[a-zA-Z0-9\s.,/-]+$',
#         'phone_number': r'^\d{10}$',
#         'mobile_number': r'^\d{10}$',
#         'gst_number': r'^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$',
#         'pan_number': r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
#         'bank_name': r'^[a-zA-Z\s.,()-]+$',
#         'ifsc_code': r'^[A-Z0-9]{11}$',
#         'bank_account_number': r'^\d{9,18}$',
#         'bank_account_holder_name': r'^[a-zA-Z\s.,()-]+$'
#     }
#
#     # Get the validation pattern for the specified field
#     pattern = validation_patterns.get(field_name)
#
#     # If pattern exists, validate the field value
#     if pattern:
#         if re.match(pattern, field_value):
#             return True
#         else:
#             return False
#     else:
#         return False
#
# def main():
#     st.title('Please Fill The Below Details')
#
#     name = st.text_input('Name: ')
#     email = st.text_input('Email ID: ')
#     company_name = st.text_input('Company Name: ')
#     country = st.text_input('Country: ')
#     state = st.text_input('State: ')
#     city = st.text_input('City: ')
#     street_address = st.text_input('Street Address: ')
#     postal_code = st.text_input('Postal Code: ')
#     phone_number = st.text_input('Phone Number: ')
#     mobile_number = st.text_input('Mobile Number: ')
#     gst_number = st.text_input('GST Number: ')
#     pan_number = st.text_input('PAN Number: ')
#     bank_name = st.text_input('Bank Name: ')
#     ifsc_code = st.text_input('IFSC Code: ')
#     bank_account_number = st.text_input('Bank Account Number: ')
#     bank_account_holder_name = st.text_input('Bank Account Holder Name: ')
#
#     if st.button('Submit'):
#         if not validate_field('name', name):
#             st.error('Please enter a valid name.')
#         elif not validate_field('email', email):
#             st.error('Please enter a valid email address.')
#         elif not validate_field('company_name',company_name):
#             st.error('Please enter the Company name.')
#         elif not validate_field('country', country):
#             st.error('Please enter the Country.')
#         elif not validate_field('state', state):
#             st.error('Please enter the State.')
#         elif not validate_field('city', city):
#             st.error('Please enter the city.')
#         elif not validate_field('street_address', street_address):
#             st.error('Please enter a valid street address.')
#         elif not validate_field('postal_code', postal_code):
#             st.error('Please enter a valid postal code.')
#         elif not validate_field('phone_number', phone_number):
#             st.error('Please enter a valid phone number.')
#         elif not validate_field('mobile_number', mobile_number):
#             st.error('Please enter a valid mobile number.')
#         elif not validate_field('gst_number', gst_number):
#             st.error('Please enter a valid GST number in capital letters.')
#         elif not validate_field('pan_number', pan_number):
#             st.error('Please enter a valid PAN number.')
#         elif not validate_field('bank_name', bank_name):
#             st.error('Please enter the Bank name.')
#         elif not validate_field('ifsc_code', ifsc_code):
#             st.error('Please enter a valid IFSC code.')
#         elif not validate_field('bank_account_number', bank_account_number):
#             st.error('Please enter a valid bank account number.')
#         elif not validate_field('bank_account_holder_name', bank_account_holder_name):
#             st.error('Please enter a valid Bank account holder name.')
#         else:
#             st.success('Form submitted successfully!')
#
# if __name__ == "__main__":
#     main()


3. Login dasboard file intial long code

# import streamlit as st
# import mysql.connector
# import webbrowser
#
# # Function to create the users table
# def create_users_table(cursor):
#     cursor.execute('''CREATE TABLE IF NOT EXISTS users
#                       (id INT AUTO_INCREMENT PRIMARY KEY,
#                       username VARCHAR(255) UNIQUE,
#                       password VARCHAR(255))''')
#
# # Function to add a new user to the database
# def add_user(cursor, username, password):
#     cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
#
# # Function to authenticate users
# def authenticate(cursor, username, password):
#     cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
#     result = cursor.fetchone()
#     if result:
#         return True
#     else:
#         return False
#
# def redirect_to_url(url):
#     webbrowser.open_new_tab(url)
#
# # Streamlit UI components
# st.title("Login Dashboard")
#
# # Establish MySQL connection
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="",
#     database="sangam master sheet"
# )
# cursor = conn.cursor()
#
# # Initialize the users table
# create_users_table(cursor)
# conn.commit()
#
# # Input fields for username and password
# username = st.text_input("Email id")
# password = st.text_input("Password", type="password")
#
# # Login button
# if st.button("Login"):
#     if authenticate(cursor, username, password):
#         st.success("Login Successful!")
#         # Redirect to another page upon successful login
#         redirect_to_url("http://localhost:8501/")  # Replace with your desired URL
#     else:
#         st.error("Invalid username or password. Please try again.")
#
# # Sign-up section
# st.sidebar.title("Sign Up")
# new_username = st.sidebar.text_input("Email Id")
# new_password = st.sidebar.text_input("Create Password", type="password")
# if st.sidebar.button("Sign Up"):
#     add_user(cursor, new_username, new_password)
#     conn.commit()
#     st.sidebar.success("Sign Up Successful! You can now login.")
#
# # Close MySQL connection
# cursor.close()
# conn.close()


4. Auto emailsending code (Use this code in realtime when the email is not sent the details will not save in the database):-

# import streamlit as st
# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# import re
# import mysql.connector
# import uuid
# import ssl
# import traceback
#
#
# # Function to connect to the MySQL database
# def connect_to_database(host, user, password, database):
#     conn = mysql.connector.connect(
#         host=host,
#         user=user,
#         password=password,
#         database=database
#     )
#     return conn
#
#
# # Function to create a table if it doesn't exist
# def create_table_if_not_exists(conn, table_name):
#     cursor = conn.cursor()
#     cursor.execute(f"""
#         CREATE TABLE IF NOT EXISTS {table_name} (
#             id INT AUTO_INCREMENT PRIMARY KEY,
#             request_number VARCHAR(50) NOT NULL,
#             company_name VARCHAR(40) NOT NULL,
#             email VARCHAR(40) NOT NULL
#         );
#     """)
#     conn.commit()
#
#
# # Function to insert data into the table
# def insert_data(conn, table_name, request_number, company_name, email):
#     cursor = conn.cursor()
#     cursor.execute(f"""
#         INSERT INTO {table_name} (request_number, company_name, email) VALUES (%s, %s, %s)
#     """, (request_number, company_name, email))
#     conn.commit()
#
#
# # Function to get the total number of rows in the table
# def get_total_rows(conn, table_name):
#     cursor = conn.cursor()
#     cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
#     total_rows = cursor.fetchone()[0]
#     return total_rows
#
#
# # Function to send email
# def send_email(sender_email, sender_password, recipient_email, subject, body):
#     # Set up the MIME
#     message = MIMEMultipart()
#     message['From'] = sender_email
#     message['To'] = recipient_email
#     message['Subject'] = subject
#
#     # Add body to email
#     message.attach(MIMEText(body, 'plain'))
#
#     # Connect to the SMTP server securely using SSL/TLS
#     smtp_server = 'mail.sangamgroup.com'  # Update SMTP server address
#     port = 465  # Default port for SSL/TLS
#     context = ssl.create_default_context()
#
#     try:
#         with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
#             # Login to the SMTP server using authentication
#             server.login(sender_email, sender_password)
#
#             # Send email
#             server.sendmail(sender_email, recipient_email, message.as_string())
#         return True
#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         traceback.print_exc()  # Print full traceback
#         return False
#
#
# # Function to validate email
# def validate_email(email):
#     # Regular expression for email validation
#     pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
#     return bool(re.match(pattern, email))
#
#
# # Function to validate company name
# def validate_company_name(company_name):
#     # Regular expression for company name validation (allowing alphabets, spaces, dots, and parentheses)
#     pattern = r'^[a-zA-Z\s.()]+$'
#     return bool(re.match(pattern, company_name))
#
#
# def main():
#     st.title('Sangam Customer Email sending')
#
#     # Connect to the database
#     host = "localhost"
#     user = "root"
#     password = ""
#     database = "emailssenttocustomer"
#     table = "Customerrequested"
#     conn = connect_to_database(host, user, password, database)
#
#     # Create table if it doesn't exist
#     create_table_if_not_exists(conn, table)
#
#     # Get total rows in the database
#     total_rows = get_total_rows(conn, table)
#
#     # Display total rows in the database on the sidebar
#     total_rows_display = st.sidebar.text("Total rows in database: " + str(total_rows))
#
#     company_name = st.text_input('Company Name: ')
#     email = st.text_input('Company Email ID: ')
#
#     if st.button("Submit"):
#         if not validate_company_name(company_name):
#             st.error("Please enter a valid company name.")
#         elif not validate_email(email):
#             st.error("Please enter a valid email address.")
#         else:
#             st.success("Company name and email are valid!")
#
#             # Generate a unique request number
#             request_number = str(uuid.uuid4())
#
#             # Email sending parameters
#             sender_email = 'testit@sangamgroup.com'  # Your email
#             sender_password = 'Krishna@123'  # Your email password
#             recipient_email = email  # Recipient's email
#             subject = 'Welcome to Sangam Vendor!'  # Email subject
#             body = f'Hello {company_name},\n\nWelcome to Sangam Vendor. Please click on the following link to complete your registration: http://localhost:8503/?request_number={request_number}'
#
#             # Send email
#             try:
#                 if send_email(sender_email, sender_password, recipient_email, subject, body):
#                     st.success("Email sent successfully!")
#
#                     # Insert data into the database only if email is sent successfully
#                     insert_data(conn, table, request_number, company_name, email)
#
#                     # Update total rows after insertion
#                     total_rows = get_total_rows(conn, table)
#                     total_rows_display.text("Total rows in database: " + str(total_rows))
#                 else:
#                     st.error("Failed to send email.")
#             except Exception as e:
#                 st.error(f"Failed to send email: {e}")
#
#     # Close database connection
#     conn.close()
#
#
# if __name__ == "__main__":
#     main()


5. Inrealtime use the below code for Formsenttoclient file

# import streamlit as st
# import re
# import mysql.connector
# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# import uuid
#
#
# # Function to validate field based on regular expression
# def validate_field(field_name, field_value):
#     validation_patterns = {
#         'name': r'^[a-zA-Z\s.,()-]+$',
#         'email': r'^[\w\.-]+@[\w\.-]+\.\w+$',
#         'company_name': r'^[a-zA-Z0-9\s.,()-]+$',
#         'country': r'^[a-zA-Z\s.,()-]+$',
#         'state': r'^[a-zA-Z\s.,()-]+$',
#         'city': r'^[a-zA-Z\s.,()-]+$',
#         'postal_code': r'^\d{6}$',
#         'street_address': r'^[a-zA-Z0-9\s.,/-]+$',
#         'phone_number': r'^\d{10}$',
#         'mobile_number': r'^\d{10}$',
#         'gst_number': r'^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$',
#         'pan_number': r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
#         'bank_name': r'^[a-zA-Z\s.,()-]+$',
#         'ifsc_code': r'^[A-Z0-9]{11}$',
#         'bank_account_number': r'^\d{9,18}$',
#         'bank_account_holder_name': r'^[a-zA-Z\s.,()-]+$'
#     }
#     pattern = validation_patterns.get(field_name)
#     if pattern:
#         return bool(re.match(pattern, field_value))
#     return False
#
#
# # Function to insert form data into the database
# def insert_into_database(data):
#     conn = mysql.connector.connect(
#         host="localhost",
#         user="root",
#         password="",
#         database="formsubmitteddetails"
#     )
#     cursor = conn.cursor()
#
#     # Generate a unique form number
#     form_number = str(uuid.uuid4())
#
#     # Insert data into the database along with the form number
#     query = """
#         INSERT INTO form_data (
#             name, email, company_name, country, state, city, street_address,
#             postal_code, phone_number, mobile_number, gst_number, pan_number,
#             bank_name, ifsc_code, bank_account_number, bank_account_holder_name,
#             form_number
#         ) VALUES (
#             %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
#         )
#     """
#     cursor.execute(query, (*data, form_number))
#     conn.commit()
#     cursor.close()
#     conn.close()
#
#     return form_number
#
#
# # Function to send email with the form number
# def send_email(recipient_email, form_number):
#     sender_email = ''  # Your email
#     sender_password = ''  # Your email password
#
#     subject = 'Form Submission Confirmation'
#     body = f'Hello,\n\nYour form submission was successful. Your form number is: {form_number}'
#
#     message = MIMEMultipart()
#     message['From'] = sender_email
#     message['To'] = recipient_email
#     message['Subject'] = subject
#     message.attach(MIMEText(body, 'plain'))
#
#     try:
#         server = smtplib.SMTP('smtp.gmail.com', 587)
#         server.starttls()
#         server.login(sender_email, sender_password)
#         server.sendmail(sender_email, recipient_email, message.as_string())
#         server.quit()
#         return True
#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         return False
#
#
# def main():
#     st.title('Please Fill The Below Details')
#
#     fields = {
#         'Name': 'name',
#         'Email ID': 'email',
#         'Company Name': 'company_name',
#         'Country': 'country',
#         'State': 'state',
#         'City': 'city',
#         'Street Address': 'street_address',
#         'Postal Code': 'postal_code',
#         'Phone Number': 'phone_number',
#         'Mobile Number': 'mobile_number',
#         'GST Number': 'gst_number',
#         'PAN Number': 'pan_number',
#         'Bank Name': 'bank_name',
#         'IFSC Code': 'ifsc_code',
#         'Bank Account Number': 'bank_account_number',
#         'Bank Account Holder Name': 'bank_account_holder_name'
#     }
#
#     form_data = {}
#     for label, field_name in fields.items():
#         form_data[field_name] = st.text_input(label)
#
#     if st.button('Submit'):
#         valid_submission = True
#         for label, field_name in fields.items():
#             if not validate_field(field_name, form_data[field_name]):
#                 st.error(f'Please enter a valid {label}.')
#                 valid_submission = False
#                 break
#
#         if valid_submission:
#             st.success('Form submitted successfully!')
#             # Convert form data to a tuple
#             data_tuple = tuple(form_data[field_name] for field_name in fields.values())
#             # Insert data into the database
#             form_number = insert_into_database(data_tuple)
#
#             # Send email with the generated form number
#             if send_email(form_data['email'], form_number):
#                 st.success('Email sent successfully!')
#             else:
#                 st.error('Failed to send email.')
#
#     # Close Streamlit connection
#     st.stop()
#
#
# if __name__ == "__main__":
#     main()



6. This code will print company name and email on the basis of requested number mentioned on the URL

# import streamlit as st
# import mysql.connector
#
# # Connect to your MySQL database
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="",
#     database="emailssenttocustomer"
# )
#
# # Define Streamlit app
# def main():
#     # Extract request_number from URL
#     params = st.query_params
#     request_number = params.get('request_number', '')
#
#     # Print the request_number
#     st.write("Request number:", request_number)
#
#     # Construct SQL query to fetch company_name and email for the given request_number
#     query = f"SELECT company_name, email FROM customerrequested WHERE request_number = '{request_number}'"
#
#     # Execute the query
#     cur = conn.cursor()
#     cur.execute(query)
#
#     # Fetch the results
#     result = cur.fetchone()
#
#     # If result is not None, extract company_name and email
#     if result:
#         company_name, email = result
#         # Print company_name and email
#         st.write("Company Name:", company_name)
#         st.write("Email:", email)
#     else:
#         st.write("No data found for the given request number.")
#
# if __name__ == '__main__':
#     main()


7. data fetching form sent to client

# import streamlit as st
# import re
# import mysql.connector
# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# import uuid
# from urllib.parse import urlparse, parse_qs
#
# # Function to validate field based on regular expression
# def validate_field(field_name, field_value):
#     validation_patterns = {
#         'name': r'^[a-zA-Z\s.,()-]+$',
#         'email': r'^[\w\.-]+@[\w\.-]+\.\w+$',
#         'company_name': r'^[a-zA-Z0-9\s.,()-]+$',
#         'country': r'^[a-zA-Z\s.,()-]+$',
#         'state': r'^[a-zA-Z\s.,()-]+$',
#         'city': r'^[a-zA-Z\s.,()-]+$',
#         'street_address': r'^[a-zA-Z0-9\s.,/-]+$',
#         'postal_code': r'^\d{6}$',
#         'phone_number': r'^\d{10}$',
#         'mobile_number': r'^\d{10}$',
#         'gst_number': r'^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$',
#         'pan_number': r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
#         'bank_name': r'^[a-zA-Z\s.,()-]+$',
#         'ifsc_code': r'^[A-Z0-9]{11}$',
#         'bank_account_number': r'^\d{9,18}$',
#         'bank_account_holder_name': r'^[a-zA-Z\s.,()-]+$'
#     }
#     pattern = validation_patterns.get(field_name)
#     if pattern:
#         return bool(re.match(pattern, field_value))
#     return False
#
# # Connect to MySQL database for inserting data
# def connect_to_insert_database():
#     conn = mysql.connector.connect(
#         host="localhost",
#         user="root",
#         password="",
#         database="formsubmitteddetails"
#     )
#     return conn
#
# # Connect to MySQL database for fetching data
# def connect_to_fetch_database():
#     conn = mysql.connector.connect(
#         host="localhost",
#         user="root",
#         password="",
#         database="emailssenttocustomer"
#     )
#     return conn
#
# # Function to fetch company name and email from the database
# def fetch_company_email(conn, request_number):
#     cursor = conn.cursor()
#     cursor.execute(f"SELECT company_name, email FROM customerrequested WHERE request_number = '{request_number}'")
#     result = cursor.fetchone()
#     cursor.close()
#     return result if result else None
#
# # Function to insert form data into the database
# def insert_into_database(conn, data, request_number):
#     cursor = conn.cursor()
#
#     # Generate a unique form number
#     form_number = str(uuid.uuid4())
#
#     # Insert data into the database along with the form number and request number
#     query = """
#         INSERT INTO form_data (
#             name, email, company_name, country, state, city, street_address,
#             postal_code, phone_number, mobile_number, gst_number, pan_number,
#             bank_name, ifsc_code, bank_account_number, bank_account_holder_name,
#             form_number, request_number
#         ) VALUES (
#             %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
#         )
#     """
#     cursor.execute(query, (*data, form_number, request_number))
#     conn.commit()
#     cursor.close()
#
#     return form_number
#
# # Function to send email with the form number
# def send_email(recipient_email, form_number):
#     sender_email = 'testit@sangamgroup.com'  # Your email
#     sender_password = 'Krishna@123'  # Your email password
#
#     subject = 'Form Submission Confirmation'
#     body = f'Hello,\n\nYour form submission was successful. Your form number is: {form_number}'
#
#     message = MIMEMultipart()
#     message['From'] = sender_email
#     message['To'] = recipient_email
#     message['Subject'] = subject
#     message.attach(MIMEText(body, 'plain'))
#
#     try:
#         server = smtplib.SMTP('mail.sangamgroup.com', 465)
#         server.starttls()
#         server.login(sender_email, sender_password)
#         server.sendmail(sender_email, recipient_email, message.as_string())
#         server.quit()
#         return True
#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         return False
#
# # Set up the Streamlit app layout
# st.set_page_config(layout="wide")
#
# # Define columns for logo and title
# logo_col, title_col = st.columns([1, 3])
#
# # Display the logo and title
# with logo_col:
#     st.image('sangam logo.png', width=100)
#
# with title_col:
#     st.markdown("<h1 style='text-align: left;'>Please Fill The Below Details</h1>", unsafe_allow_html=True)
#
# # Define columns for form fields
# col1, col2, col3 = st.columns(3)
#
# # Set up form fields
# fields = {
#     'Name': 'name',
#     'Email ID': 'email',
#     'Company Name': 'company_name',
#     'Country': 'country',
#     'State': 'state',
#     'City': 'city',
#     'Street Address': 'street_address',
#     'Postal Code': 'postal_code',
#     'Phone Number': 'phone_number',
#     'Mobile Number': 'mobile_number',
#     'GST Number': 'gst_number',
#     'PAN Number': 'pan_number',
#     'Bank Name': 'bank_name',
#     'IFSC Code': 'ifsc_code',
#     'Bank Account Number': 'bank_account_number',
#     'Bank Account Holder Name': 'bank_account_holder_name'
# }
#
# # Set up form data with retrieved values
# form_data = {}
#
# # Extract request_number from URL
# params = st.query_params
# request_number = params.get('request_number', '')
#
# # Connect to MySQL database for fetching data
# conn_fetch = connect_to_fetch_database()
#
# # Construct SQL query to fetch company_name and email for the given request_number
# query = f"SELECT company_name, email FROM customerrequested WHERE request_number = '{request_number}'"
#
# # Execute the query
# cur = conn_fetch.cursor()
# cur.execute(query)
#
# # Fetch the results
# result = cur.fetchone()
#
# # If result is not None, extract company_name and email
# if result:
#     company_name, email = result
#     # Set fetched company_name and email in the text input fields
#     form_data['email'] = email
#     form_data['company_name'] = company_name
#
# # Set up form fields in columns 1, 2, and 3
# with col1:
#     for label, field_name in list(fields.items())[:5]:
#         if field_name == 'company_name' or field_name == 'email':
#             st.text_input(label, key=field_name, value=form_data.get(field_name, ''), disabled=True)
#         else:
#             form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''))
#
# with col2:
#     for label, field_name in list(fields.items())[5:10]:
#         form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''))
#
# with col3:
#     for label, field_name in list(fields.items())[10:]:
#         form_data[field_name] = st.text_input(label, key=field_name, value=form_data.get(field_name, ''))
#
# # Submission button
# if st.button('Submit'):
#     valid_submission = True
#     for label, field_name in fields.items():
#         if not validate_field(field_name, form_data[field_name]):
#             st.error(f'Please enter a valid {label}.')
#             valid_submission = False
#             break
#
#     if valid_submission:
#         st.success('Form submitted successfully!')
#         insert_conn = connect_to_insert_database()
#         # Convert form data to a tuple
#         data_tuple = tuple(form_data[field_name] for field_name in fields.values())
#         # Insert data into the database and get the generated form number
#         form_number = insert_into_database(insert_conn, data_tuple, request_number)
#
#         # Send email with the generated form number
#         if send_email(form_data['email'], form_number):
#             st.success('Email sent successfully!')
#         else:
#             st.error('Failed to send email.')


8.Mail server requires authentication

# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# import ssl
#
#
# def send_email(sender_email, sender_password, recipient_email, subject, body):
#     # Set up the MIME
#     message = MIMEMultipart()
#     message['From'] = sender_email
#     message['To'] = recipient_email
#     message['Subject'] = subject
#
#     # Add body to email
#     message.attach(MIMEText(body, 'plain'))
#
#     # Connect to the SMTP server securely using SSL/TLS
#     smtp_server = 'your_smtp_server_address'
#     port = 465  # Default port for SSL/TLS
#     context = ssl.create_default_context()
#
#     try:
#         with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
#             # Login to the SMTP server using authentication
#             server.login(sender_email, sender_password)
#
#             # Send email
#             server.sendmail(sender_email, recipient_email, message.as_string())
#         return True
#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         return False
#
#
# # Usage example
# sender_email = 'your_email@example.com'
# sender_password = 'your_email_password'
# recipient_email = 'recipient@example.com'
# subject = 'Test Email'
# body = 'This is a test email.'
#
# # Send email
# send_email(sender_email, sender_password, recipient_email, subject, body)

9. when the email is not going it keeps on loading


# def send_email(sender_email, sender_password, recipient_email, subject, body):
#     # Set up the MIME
#     message = MIMEMultipart()
#     message['From'] = sender_email
#     message['To'] = recipient_email
#     message['Subject'] = subject
#
#     # Add body to email
#     message.attach(MIMEText(body, 'plain'))
#
#     # Connect to the SMTP server securely using SSL/TLS
#     smtp_server = 'mail.sangamgroup.com'  # Update SMTP server address
#     port = 465  # Default port for SSL/TLS
#     context = ssl.create_default_context()
#
#     try:
#         with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
#             # Login to the SMTP server using authentication
#             server.login(sender_email, sender_password)
#
#             # Send email
#             server.sendmail(sender_email, recipient_email, message.as_string())
#         return True
#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         import traceback
#         traceback.print_exc()  # Print full traceback
#         return False


10. login and logout functionality

# import streamlit as st
#
# # Function to authenticate user
# def authenticate(username, password):
#     # Replace this with your authentication logic
#     if username == "user" and password == "password":
#         return True
#     else:
#         return False
#
# # Function to check if user is logged in
# def is_logged_in():
#     return "username" in st.session_state
#
# # Login page
# def login_page():
#     st.title("Login")
#
#     username = st.text_input("Username")
#     password = st.text_input("Password", type="password")
#
#     if st.button("Login"):
#         if authenticate(username, password):
#             st.session_state.username = username
#             st.session_state.logged_in = True
#             st.success(f"Welcome, {username}!")
#             st.experimental_rerun()  # Rerun the app to reflect login changes
#
# # Logout page
# def logout_page():
#     st.title("Logout")
#     st.write(f"Goodbye, {st.session_state.username}!")
#     st.write("You are now logged out.")
#     # Clear session state variables related to login
#     st.session_state.pop("username", None)
#     st.session_state.pop("logged_in", None)
#     st.experimental_rerun()  # Rerun the app to reflect logout changes
#
# # Main function
# def main():
#     if is_logged_in():
#         st.title("Home")
#         st.write("Welcome to the home page!")
#         if st.button("Logout"):
#             logout_page()
#     else:
#         login_page()
#
# if __name__ == "__main__":
#     main()


# import streamlit as st
# import mysql.connector
#
#
# # Function to check for new form numbers in the MySQL database for a specific date range and company name
# def check_for_new_forms(start_date, end_date, company_name):
#     conn = mysql.connector.connect(
#         host="localhost",
#         user="root",
#         password="",
#         database="formsubmitteddetails"
#     )
#     cursor = conn.cursor()
#     cursor.execute("SELECT form_number FROM form_details WHERE date BETWEEN %s AND %s AND company_name = %s",
#                    (start_date, end_date, company_name))
#     form_numbers = cursor.fetchall()
#     conn.close()
#     return form_numbers
#
#
# # Main function to run the Streamlit app
# def main():
#     st.title('New Form Number Checker')
#
#     # Date range input
#     start_date = st.date_input("Start Date")
#     end_date = st.date_input("End Date")
#
#     # Company name input
#     company_name = st.text_input("Company Name")
#
#     # Check for new form numbers when the button is clicked
#     if st.button('Check for New Form Numbers'):
#         form_numbers = check_for_new_forms(start_date, end_date, company_name)
#         if form_numbers:
#             st.write("New form numbers detected for", company_name + ":")
#             for form_number in form_numbers:
#                 st.write(form_number[0])
#         else:
#             st.write("No new form numbers found for", company_name)
#
#
# if __name__ == "__main__":
#     main()
#