import streamlit as st
import mysql.connector
from datetime import datetime, timedelta

# Function to fetch the logged-in user's email from the database based on login number
def fetch_logged_in_user_email(conn, login_number):
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM logged_in_user WHERE login_number = %s", (login_number,))
    result = cursor.fetchone()
    cursor.close()
    return result[0] if result else None

# Function to fetch the form details from MySQL database based on date range and logged-in user's email
def fetch_form_details_by_date_range_and_email(conn, start_date, end_date):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT fd.company_name, fd.category, fd.form_number
        FROM formsubmitteddetails.form_details AS fd
        JOIN emailssenttocustomer.customerrequested AS cr ON fd.request_number = cr.request_number
        JOIN formsubmitteddetails.changes_required AS crq ON fd.form_number = crq.form_number
        WHERE fd.submission_date BETWEEN %s AND %s
        ORDER BY fd.submit_timestamp DESC
    """, (start_date, end_date))
    form_details = cursor.fetchall()
    cursor.close()
    return form_details

# Function to fetch the form details from MySQL database based on form number
def fetch_form_details_by_form_number_and_email(form_number):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="formsubmitteddetails"
    )
    cursor = conn.cursor()
    cursor.execute("""
        SELECT company_name, form_number, form_data
        FROM form_details
        WHERE form_number = %s
    """, (form_number,))
    form_details = cursor.fetchone()
    conn.close()
    return form_details

# Function to check if form number exists in account_final table
def form_number_exists_in_changesdoneby_ar(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM changesdoneby_ar done WHERE form_number = %s", (form_number,))
    result = cursor.fetchone()[0]
    cursor.close()
    return result > 0

# Function to check if form number exists in changes_required table and get details
def get_changes_requestedtoar_details(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("SELECT details FROM changes_requestedtoar WHERE form_number = %s", (form_number,))
    result = cursor.fetchone()
    cursor.close()
    return result[0] if result else None

def get_changesdoneby_ar_status(conn, form_number):
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM changesdoneby_ar WHERE form_number = %s", (form_number,))
    result = cursor.fetchone()[0]
    cursor.close()
    return "Changes done" if result > 0 else ""

def redirect_to_url(url):
    st.markdown(f'<meta http-equiv="refresh" content="0;URL={url}">', unsafe_allow_html=True)


# Streamlit app
def main():
    st.title('Changes Requested By IT Team')

    # Retrieve login number from URL
    query_params = st.query_params
    login_number = query_params.get('login_number', '')

    # Sidebar
    st.sidebar.title("Logged-in User")

    # Connect to the database for logged-in users
    conn_login = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="logindashboard"
    )

    # Fetch logged-in user's email
    logged_in_user_email = fetch_logged_in_user_email(conn_login, login_number)
    conn_login.close()

    if logged_in_user_email:
        st.sidebar.markdown(f"**{logged_in_user_email}**")

        # Logout button
        if st.sidebar.button("Logout"):
            conn_work_done = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="logindashboard"
            )
            cursor = conn_work_done.cursor()
            cursor.execute("DELETE FROM logged_in_user WHERE login_number = %s", (login_number,))
            conn_work_done.commit()
            cursor.close()
            conn_work_done.close()
            redirect_to_url("http://127.0.0.1:5000/")  # Redirect to the login page
    else:
        st.error("User not logged in. Please log in to view the dashboard.")
        st.stop()

    if st.sidebar.button("Back"):
        # Append login_number as a query parameter to the redirect URL
        redirect_to_url(
            f"http://localhost:8503/?login_number={login_number}")  # Redirect to the specified URL with login_number

    # Sidebar options
    st.sidebar.title("Options")
    start_date = st.sidebar.date_input("Start Date", datetime.now() - timedelta(days=2))
    end_date = st.sidebar.date_input("End Date", datetime.now())

    # Create an empty element to hold the table
    table_placeholder = st.empty()

    conn_form_details = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="formsubmitteddetails"
    )

    # Fetch the form details from the database based on date range and logged-in user's email
    form_details = fetch_form_details_by_date_range_and_email(conn_form_details, start_date, end_date)

    # Display the form details in a table
    if form_details:
        data = {
            "User": [],
            "Company Name": [],
            "Category": [],
            "Form Link": [],
            "Status/Details": [],
            "Market Changes": []  # New column
        }
        for detail in form_details:
            company_name, category, form_number = detail
            data["User"].append(logged_in_user_email)
            data["Company Name"].append(company_name)
            data["Category"].append(category)
            if form_number_exists_in_changesdoneby_ar(conn_form_details, form_number):
                status_details = "Changes Done"
            else:
                changes_requestedtoar_details = get_changes_requestedtoar_details(conn_form_details, form_number)
                status_details = changes_requestedtoar_details if changes_requestedtoar_details else "N/A"
            data["Status/Details"].append(status_details)

            # Generate form link based on category
            if category == "ZEXP":
                form_link = f'[View Form](http://localhost:8515/?form_number={form_number})'
            elif category in ["ZDOM", "ZDSH"]:
                form_link = f'[View Form](http://localhost:8514/?form_number={form_number})'
            else:
                form_link = "Wrong category selected"

            data["Form Link"].append(form_link)

            # Get market changes status
            if get_changesdoneby_ar_status(conn_form_details, form_number):
                ar_changes_status = "Changes done"
            elif get_changesdoneby_ar_status(conn_form_details, form_number):
                ar_changes_status = "Still pending"
            else:
                ar_changes_status = ""
            data["Market Changes"].append(ar_changes_status)

        table_markdown = "| User | Company Name | Category | Form Link | Status/Details | Market Changes |\n| --- | --- | --- | --- | --- | --- |\n"
        for i in range(len(data["User"])):
            table_markdown += f"| {data['User'][i]} | {data['Company Name'][i]} | {data['Category'][i]} | {data['Form Link'][i]} | {data['Status/Details'][i]} | {data['Market Changes'][i]} |\n"
        table_placeholder.markdown(table_markdown)



    conn_form_details.close()

if __name__ == "__main__":
    main()
