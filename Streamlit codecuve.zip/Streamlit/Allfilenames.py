import subprocess
import time
import os

processes = [
    ("checkfile.py", 8501),
    ("signup.py", 8502),
    ("autoemailsending.py", 8503),
    ("totalnewrowsinserted.py", 8504),
    ("changesrequestedbyar.py", 8505),
    ("changesrequestedbyitforM.py", 8506),
    ("formsenttoclientd.py", 8507),
    ("formsenttocliente.py", 8508),
    ("formsenttoclients.py", 8509),
    ("marketingteamds.py", 8510),
    ("marketingteame.py", 8511),
    ("marketingteamchangesDSforAR.py", 8512),
    ("marketingteamchangesEforAR.py", 8513),
    ("marketingteamchangesDSforIT.py", 8514),
    ("marketingteamchangesEforIT.py", 8515),
    ("marketcheckbyar.py", 8516),
    ("arteamformds.py", 8517),
    ("arteamforme.py", 8518),
    ("changesrequestedbyitforAR.py", 8519),
    ("archeckbyIT.py", 8520),
    ("itteamformds.py", 8521),
    ("itteamforme.py", 8522)
]

def kill_process_on_port(port):
    result = subprocess.run(f"netstat -ano | findstr :{port}", shell=True, capture_output=True, text=True)
    lines = result.stdout.strip().split('\n')
    for line in lines:
        if line:
            pid = int(line.strip().split()[-1])
            subprocess.run(f"taskkill /PID {pid} /F", shell=True)

procs = []

for script, port in processes:
    # Kill any existing process on the next port
    kill_process_on_port(port)
    time.sleep(1)  # Ensure the port is freed

    # Start the new process
    procs.append(subprocess.Popen(f"streamlit run {script} --server.port {port}", shell=True))
    time.sleep(2)

# Start the last Python script
procs.append(subprocess.Popen("python logindashboard.py", shell=True))

# Optionally, wait for all processes to complete
for proc in procs:
    proc.wait()
